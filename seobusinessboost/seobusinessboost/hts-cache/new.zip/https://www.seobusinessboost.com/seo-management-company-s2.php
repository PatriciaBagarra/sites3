<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Best SEO Marketing Company | SEO Business Boost</title>

<meta name="description" content="As a business, keeping your website relevant to your local community is very important. Having a local SEO is essential to help keep relevancy and boost your website’s local ranking. We support your online presence thoroughly, to know more about how we do that, get in touch with us." />
<meta name="keywords" content="best online seo company, best seo company for small business, best seo marketing company, ppc management services" />
<meta property="og:title" content="Best SEO Marketing Company | SEO Business Boost" />
<meta property="og:type" content="article" />
<meta property="og:url" content="https://www.seobusinessboost.com/seo-management-company-s2.php" />
<link rel="image_src" href="https://www.seobusinessboost.com/members/seobusinessboost/mypages/google-mobile-search--1---2-.jpg" />
<meta property="og:image" content="https://www.seobusinessboost.com/members/seobusinessboost/mypages/google-mobile-search--1---2-.jpg" />
<meta property="og:site_name" content="https://www.seobusinessboost.com" />
<meta property="og:description" content="As a business, keeping your website relevant to your local community is very important. Having a local SEO is essential to help keep relevancy and boost your website’s local ranking. We support your online presence thoroughly, to know more about how we do that, get in touch with us." />

<link rel="canonical" href="https://www.seobusinessboost.com/seo-management-company-s2.php" />
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">

<link rel="alternate" media="only screen and (max-width: 640px)" href="https://www.seobusinessboost.com/m/seo-management-company-s2.php" />
<!--[if IE]><link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" /><![endif]-->

<!-- Animation Effect -->
<link rel="stylesheet" type="text/css" href="visualize.css" />
<!-- Animation Effect ends here -->

<link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" />

<link href="css/main-layout-new.css?ver1.0" rel="stylesheet" type="text/css" />
<link href="css/main-theme-1.css?ver1.0" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/listcarousel.css" />
<link rel="stylesheet" type="text/css" href="css/quick-search.css" />
<script src="js/jquery-1.8.2.min.js"></script>
<style type="text/css">	
	.rightFormBlockDiv{float: right; margin-left: 20px; margin-bottom: 5px;}
	.leftFormBlockDiv{float: left; margin-right: 20px; margin-bottom: 5px;}
	.phoneTxtDiv1{width:25%;}
	.phoneTxtDiv2{width:37%;}

@media only screen and (max-width : 767px)
{
	.rightFormBlockDiv{float: none; margin-left: 0px; margin-bottom: 0px; padding:0px 5px !important;}
	.formBodyLeft{ box-sizing: border-box; padding: 0px 5px !important; margin:0px !important; }
	.phoneTxtDiv1{width:24%;}
	.phoneTxtDiv2{width:30%;}
}
</style>
</head>

<body>

<!--Page Container start-->
<div class="container"  >
	
     <!--Header page include start-->
	<link href="css/main-layout3-new.css" rel="stylesheet" type="text/css" />
<link href="css/main-layout5.0.1.min.css" rel="stylesheet" type="text/css" />

<link href="css/layout5-header.0.1.min.css" rel="stylesheet" type="text/css" />
<!--<link href="css/.css?ver1.0" rel="stylesheet" type="text/css">-->
<link href="css/svg-fonts-styles.css" rel="stylesheet" type="text/css" />
<style>
.menuOptIcnInnDiv{border: 1px solid #e3e3e3 !important; text-align: center; margin-top:6px; height: 50px;}
.menuOptIcnInnDiv a{ text-decoration:none !important;}
.logoMid {width:60%; position:relative;}
.menuMobNew {
	padding: 2px 4px;
}
.submenuPad .menuMobNew a span{
	width:auto !important;
}
.menuMobNew a span {
	width:auto;
	display:block;
	min-height:80px;
	float:none;
	height:auto !important;
}
.subMenuMain a div{
	min-height:70px;
	height:auto !important;
}
.logo{position:relative;}

.cartToolTip {
	right: -32px;
    position: absolute;
    bottom: 55px;
    z-index: 9;
    background: #dfca80;
    color: #000;
    padding: 13px 15px;
    border-radius: 5px;
    font-size: 20px;
    font-weight: 300;
}
.cartToolTip::after {
	content: "";
    width: 0;
    height: 0px;
    border-left: 12px solid transparent;
    border-right: 12px solid transparent;
    border-top: 15px solid #dfca80;
    position: absolute;
    margin: 36px 38px 18px -54px;
}
.phoneCallTrackNumber a:hover{ text-decoration: none !important; }
</style>

<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
	
	.logoSizeModule {max-width:150px !important; max-height:90px !important;}



}
</style>
<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
.editWebsiteBtn{ display:none !important;}
}
</style>
<style>
.freeEstimateBtn a {
	width:318px;
}
.freeEstimateBtn a:hover {
	width:318px;
}
.container .header {
	width:100%;
	margin:auto;
}
.container .headerOne {
	overflow:hidden;
	display:table;
	max-width:980px;
	margin:auto;
	color:#333333;
}
.containerWithBg .header {
	width:100%;
	margin:auto;
}
.containerWithBg .headerOne {
	overflow:hidden;
	display:table;
	width:980px;
	margin:auto;
	color:#ffffff;
}
.mainMenu {
	margin:auto;
	margin-bottom:5px;
}
.menuBlock {
	padding-right:0px;	
}
.menuBlock ul li {
	width:0%;
}
.menuStyle1 {
	background-color:#f6f6f6;	
}
.menuStyle1 .mainMenu {
	clear:both;
	width:980px;
	margin:auto;
	overflow:hidden;
}
.menuStyle1 .menuBlock {
	float:left;
	width:675px;
	padding-right:0px;
}
.menuStyle1 .menuBlock ul {
	border:none;
	background:none;
	margin:0;
	padding:0;
	border-radius:0;
	display:table;
	width:100%;
	list-style:none;
}
.menuStyle1 .menuBlock ul li {
	display:table-cell;
	list-style:none;
	text-align:center;
	font-family:"Open Sans",sans-serif;	
	font-weight:normal;
		font-size: 13px;
				width:auto !important;
	}
.menuStyle1 .menuBlock ul li a {
	line-height:60px;
	padding:0px;
	background:#f8f8f8;
	color:#666;
	display:block;
	text-decoration:none;
}
.menuStyle1 .menuBlock ul li a:hover {
	color:#666;
	background:#ededed;
	text-decoration:none;
}
.menuStyle1 .menuBlock > ul li:hover a {
	color:#666;
	background:#ededed;
	text-decoration:none;
}

.menuStyle1 .menuBlock ul li ul {
	display:none;
	background:#ffffff;
	border:0px;
	position:absolute;
	z-index:9999;
	margin-top:-0px;
	margin-left:0px;
	padding:0px;
	/* border:1px solid #ffffff; */
	 width:280px;
	-webkit-border-radius: 0px;
	-moz-border-radius: 0px;
	border-radius: 0px;
}
.menuStyle1 .menuBlock ul li:hover ul {
	display:block;
}
.menuStyle1 .menuBlock li ul li {
	display:block;
	border-bottom: 1px solid rgba(0,0,0,0.2);
	border-right:0px;
	float:none;
	margin:0px;
	padding:0px;
	width:280px;
	line-height:20px;
	text-align:left;
	/*word-break: break-all;*/
	word-wrap: break-word;
}
.menuStyle1 .menuBlock li ul li:last-child {
	border-bottom:0px;
}
.menuStyle1 .menuBlock li ul li a {
	border:0px;
	color:#666;
	text-decoration:none;
	background:none !important;
	cursor:pointer;
	border-radius:0px;
	padding:8px 10px;
	line-height:normal;
	text-align:left;
	font-weight:normal;
}
.menuStyle1 .menuBlock li ul li a:hover {
	background:#ededed !important;
}


.menuStyle1 .freeEstimateBtn a {
	width:280px;
	font-family:"Open Sans",sans-serif;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.menuStyle1 .freeEstimateBtn a:hover {
	width:280px;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.topStickyBarLine { border-bottom: 0px;}

.hidedesk{display:none;}
.headerbackgroung { background-image: url(members/seobusinessboost/index/Optimized-digital-marketing-agency-Gulf-Shores-Alabama.1--2-.jpg); background-size: cover; background-position: center top; height:170px; }
.contentInnerBody{box-shadow: none; padding: 5px 0px; border: 0px;}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.headerbackgroung { height:140px; background-size: initial;}




}
.sample_popup-layout{z-index:100;}
.footerModule{width: 100%;}
@media only screen and (max-width : 639px),
only screen and (max-device-width : 639px){
	.topStickyBarLine {height: 55px;}
}
/* Layout5 Styles */
@media only screen and (max-width : 1180px),
only screen and (max-device-width : 1180px){
	.headerPaddLayout5{width:98%;}
	.topleftLay5, .topRightLay5{ width:50%;}
	
}

@media only screen and (max-width : 1000px),
only screen and (max-device-width : 1000px){
.hideheaderTxtLay5{ display:none !important;}
.headerPaddLayout5{padding:10px;}
.logoDivLayout5{width:190px;}
.topleftLay5{ width:auto;}
.topRightLay5{width:auto; margin-right:8px;}
.showMobLay5Ph{ display:block;}
.menuIcnColorLay5{ font-size:30px !important; margin: 0px 4px; padding: 2px 5px; border: 1px solid #ffffff; width: 44px; text-align: center;}
}
@media only screen and (max-width : 985px),
only screen and (max-device-width : 985px){
	.hidedesk{display:block;}
	.menuTxtlayout5{width: 80%;padding: 8px 0px;}
	.accordion-drop{width: 48px;padding: 18px 0px;}
}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.accordionMenuLayout5 ul li a{padding: 16px 0 10px 0; border-top: 1px solid rgba(255,255,255,.1);}
.logoimageTag{max-height:75px;}
}
@media only screen and (max-width : 359px),
only screen and (max-device-width : 359px){
.topRightLay5{margin-right:4px;}
}



 .menustickystyle{   }
 .menustylelogo{margin-top: 42px !important;}
 @media only screen and (max-width: 768px)
{.menustylelogo{ margin-top: 0px !important; }}
 

@media only screen and (max-width: 768px)
{
	.menuStyle1{ display: none !important; }
	
	


.sample_popup-layout{ top: -42px !important; }
</style>

<!--Top Sticky header start-->
<div class="topStickyBar" id="stickyshowhide" style="display:none;position:relative; z-index:1000;">
    <div class="topStickyBarLine bgcolorTheme">
        <div class="topStickyBarBtn"><a class="" href="form-sticky-header.php">Sticky Header</a> 
		 <a href="form-sticky-header.php" >
		<img src= "members/seobusinessboost/avatar/thumbs/thumbnail_1334808645.png" title="Promo Logo" alt="Promo Logo" border="0" height="35" /></a></div>
    </div>
</div>
<!--Top Sticky header end-->


<div class="headerbackgroung">
<div class="headerlayout5">
<div class="headerPaddLayout5">
	<div class="topleftLay5">
    <a href="index.php" title="SEO Business Boost"><div class="logoDivLayout5" style="position: relative; padding-right: 20px;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" style="max-width:100%;" border="0" class="logoimageTag" alt="SEO Business Boost" /><span class="tradeMarkIcon" style="right:0px; color:#ffffff;"></span></div></a>
	
	<a href="javascript:void(0);" style="text-decoration: none; margin:15px 15px 0px 0px; border: 1px solid #dfca80;display:none;float:right;" onclick="editwebsite();" class="editWebsiteBtn">
        <div style="color: #000000; padding: 10px 24px; font-size: 20px; font-weight: 300; background:#faecbe;">
          <span style="vertical-align:middle; display:inline-block; margin-top: -6px;">
          <img src="images/control-panel-icon-footer-black.svg" alt="Control Panel" border="0" width="23" height="23">
          </span>
          Edit Website
        </div>
    </a>
	
    </div>
    <div class="topRightLay5">
    	<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()" title="Menu" ></span>
		<a href="tel:2514245682" title="Call:2514245682" style="">
        <span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
		</a>
        <div class="shoponlineTxt hideheaderTxtLay5 phoneFloatRight">
				<a href="get-free-quote-9.php"   style="" >
		Get Free Quote</a>
				</div>	
    	<div class="layout5Phnum hideheaderTxtLay5" style="">
        	
            <div style="width:36px; overflow:hidden; float:left;">
            	<span class="icon-phone phoneIcnLayout5"></span> 
            </div>
            <div style="float:left; width:auto; padding:5px 0px 0px 3px;" class="phoneCallTrackNumber"><a href="javascript:void(0);">251-424-5682</a></div>
           
        </div>
    </div>
</div>
</div>
<!--mobile menu option left and right Icons-->
<div style="position: absolute; padding-top:10px; display:none;z-index: 9;width: 100%;" class="headerSecLayout5">
<div style="cursor:pointer; padding:2px; position:absolute; top:10px; left:3px; z-index: 1;">
<a href="tel:2514245682" title="Call:2514245682" style="text-decoration:none;">
<span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
</a>
</div>
<div class="logo" style="text-align:center; display:inherit; margin:auto;">
    <a href="index.php" title="SEO Business Boost" style="position: relative;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" alt="SEO Business Boost" class="logoSizeModule" border="0">
    <span class="tradeMarkIcon" style="color:#ffffff;"></span>
    </a>
</div>
<div  style="cursor:pointer; padding:2px; position:absolute; top:10px; right:3px;">
<a href="javascript:void();" onclick="showMenu();" style="text-decoration:none;">
<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()"></span>
</a></div>
</div>
<!-- end-->

</div>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <!-- Layout5 Menu  Starts here -->
<div id="accordionmenulayout5">
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="home-10.php"  ><span class="menuTxtlayout5">Home</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="about-us-8.php"  ><span class="menuTxtlayout5">About Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="email-us-your-request-9.php"  ><span class="menuTxtlayout5">Contact Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="website-builder-design-s1.php"  ><div class="menuTxtlayout5">Web Design</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="free-website-special-offer-s18.php"    >Free Website Special Offer</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="seo-management-company-s2.php"  ><div class="menuTxtlayout5">SEO Management</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="website-seo-company-s6.php"    >Website SEO Company</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="google-adwords-s3.php"  ><div class="menuTxtlayout5">Google Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="facebook-ads-s4.php"  ><div class="menuTxtlayout5">Facebook Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="youtube-ads-s5.php"  ><div class="menuTxtlayout5">YouTube Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="digital-marketing-services-s17.php"  ><div class="menuTxtlayout5">Digital Marketing</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5 hidedesk">
		<div class="accordion-toggle">
		<a href="marketing-blog-26.php"  title="Marketing Blog" ><span class="menuTxtlayout5">Marketing Blog</span></a>
		</div>
	</div>
</div>
<!-- Layout5 Menu  Ends here -->
<script type="text/javascript">
$(document).ready(function($) {
	$('#accordionmenulayout5').find('.accordion-drop').click(function(){
		var span=$(this).find('span');
		var othrspan=$(".accordion-drop > span").not(span);
		//Expand or collapse this panel
		$(this).parent().next().slideToggle('fast');
		//Hide the other panels
		$(".accordion-content").not($(this).parent().next()).slideUp('fast');
		$(".accordion-drop").not($(this)).attr("data-display","1");
		othrspan.removeClass('accordion-close');
		othrspan.addClass('accordion-open');
		othrspan.html('');
		var visible = $(this).attr("data-display");
		if(visible=='1'){
			span.removeClass('accordion-open');
			span.addClass('accordion-close');
			span.html('x');
			$(this).attr("data-display","0");
		}else{
			span.removeClass('accordion-close');
			span.addClass('accordion-open');
			span.html('');
			$(this).attr("data-display","1");
		}
	});	
});
</script>
</div>

<script>window.jQuery || document.write('<script src="js/zepto.js"><\/script>')</script>
<script src="jquery.waterfall.js"></script>
<script type="text/javascript">
function showMenu(){
	var showStatus=$('#menuList').attr('show-status');
	if(showStatus==0){
		$('#menuList').css('top','auto');
		$('#menuList').attr('show-status','1');
		$('#menuList').css('opacity','1');
		$("#menuIcn").attr('class', 'icon-close iconSizeDiv themeColor');
	} else if(showStatus==1){
		$('#menuList').css('top','-1000px');
		$('#menuList').css('opacity','0');
		$('#menuList').attr('show-status','0');
		$("#menuIcn").attr('class', 'icon-menu iconSizeDiv themeColor');
	}	
	// var src = $("#menuIcn").attr('class') == "menucloseIcnBg-menuOpt" ? "menuIcnBg-menuOpt" : "menucloseIcnBg-menuOpt";
	//  $("#menuIcn").attr('class', src);
	/* var src = $("#menuIcn").attr('src') == "images/close-icn-empty-thin.png" ? "images/menu-icn-empty-thin.png" : "images/close-icn-empty-thin.png";
	$("#menuIcn").attr('src', src); */
	
	return false;
		
}
function showSubMenu(id){ 
	if($('#subMenu_'+id).css('display') == 'none'){
		var body = document.body,
		html = document.documentElement;
		var height = Math.max( body.scrollHeight, body.offsetHeight,
		html.clientHeight, html.scrollHeight, html.offsetHeight );
		document.getElementById('subMenu_'+id).style.height=height+'px';
		$('#subMenu_'+id).show();
				$('html, body').animate({scrollTop:0}, 'slow');
	}else{
		$('#subMenu_'+id).hide();
	}
}
function stickyheadershowhidefun(){
var stickydeskStatus= '2';
var stickymobStatus = '1';
var stickyparentdiv= 'container';
if($(window).width() >= 960){
if(stickydeskStatus==2)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
}
else
{
if(stickymobStatus==1)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}

}
}
$(document).ready(function(){
stickyheadershowhidefun();
});
$(window).resize(function () {
stickyheadershowhidefun();
});

function editwebsite(){
	/* var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('controlPanel').style.height=height+'px';
	$('#controlPanel').focus(); */
	$('html, body').animate({
		scrollTop: $("#controlPanel").offset().top
	},1000);
	$("#controlPanel").focus();
	$("#cartToolTip").show();
}
var stickydeskStatus= '2';
var stickymobStatus = '1';
if(stickydeskStatus!=2 || stickymobStatus!=1 )
{
$(document).on( 'scroll', function(){
	if ($(window).scrollTop() > 2) {
		$("#stickyshowhide").css('position','fixed');
		if($(window).width() >= 960){
		//$(".headerbackgroung").css('margin-top','44px');
		}
	} else {	
				$("#stickyshowhide").css('position','relative');
			}
});
}
$(document).ready(function($) {closeNav();});

/* Set the width of the side navigation to 250px */
function openNav() {
   $("#mySidenav").css({'width':"320px",'overflow':''});$('body').css('overflow','hidden');
}
/* Set the width of the side navigation to 0 */
function closeNav() {
    {$("#mySidenav").css({'width':"0",'overflow':'hidden'});$('body').css('overflow','');}
}
</script>
<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<link rel="stylesheet" type="text/css" href="css/listcarousel-botbox-v1.css" />
     <!--Header page include end-->

  <!--Body Content Start-->	 
	<div class="contentBody">
	 
	 <!--Page Heading Start-->
	   <div class="contentHead">
					<div class="headingText">
				<h1>Does SEO Work for Small Business?</h1>				<div class="shareButtons" style="text-align: right; vertical-align: middle; float: right; position: relative; margin-top: -30px;">
                <!--Social Network buttons (Likes & shares etc...)-->
                                    <!--Social Network buttons (Likes & shares etc...) End-->
			    </div>
			</div>
				</div>
     <!--Page Heading End-->
	 
	 <!--Inner Body Content Start-->	
	 
    <div class="contentInnerBody">
    	 	<!-- Temaplate 1 Start-->
                <div class="contentInsertBlock" >
            <div class="innerImgRight animation-element slide-right in-view">
                <img src="members/seobusinessboost/mypages/google-mobile-search--1---2-.jpg" alt="" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2 style="font-size: 22px; padding-top: 10px; padding-bottom: 10px; color: rgb(102, 102, 102);">Get More Website Traffic With Fully Managed, Advanced SEO Services</h2><div style="color: rgb(102, 102, 102);">There’s some SEO in everything you do online. But that doesn’t mean everyone needs the same SEO services. Build your search engine optimization foundation with the trusted experts. We offer the right plans and strategies match your exact needs.</div><div style="color: rgb(102, 102, 102);"><br></div><div style="color: rgb(102, 102, 102);"><h2 style="font-size: 22px; padding-top: 10px; padding-bottom: 10px;">Here’s What You Get with Our Professional SEO Management Services</h2><div>You can get an edge on the competition with a strong, integrated strategy that combines content marketing, research, technical SEO, <a href="https://www.seobusinessboost.com/facebook-ads-s4.php" title="" target="">social media</a>, paid strategies, and other elements of online marketing.</div><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style><div style="max-width: 470px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div></div>            </div>
        </div>
    	        <div class="contentInsertBlock" >
            <div class="innerImgLeft animation-element slide-left in-view">
                <img src="members/seobusinessboost/mypages/seo-management-company-gulf-shores-al-36542.1.1.jpg" alt="SEO  management company gulf shores, AL" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2>We Provide SEO Services For All Businesses&nbsp;</h2><div><b>Our SEO services come with a team of diligent and highly experienced individuals in the field of SEO</b>. We stop at nothing to bring you the best results. We work with keyword research, comprehensive keyword development, and content creation to give you a highly optimized site that will always bring you results throughout your time in business.&nbsp;</div><div><br></div><h2>An SEO Company That You Can Trust</h2><div>Trust is a huge word. And going by the number of clients we have serviced in the industry, we can firmly say that you can count on us. Working with businesses who offer different kinds of products or services on a large spectrum and helped us understand the importance of investing time to understand your businesses goals so that we can help you achieve the same.</div><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div>            </div>
        </div>
                <div class="contentInsertBlock" >
            <div class="innerImgRight animation-element slide-right in-view">
                <img src="members/seobusinessboost/mypages/seo-management-company.jpg" alt="Local SEO Services" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2>Make Use Of Our Local SEO Services&nbsp;</h2><div>As a business, keeping your website relevant to your local community is very important. <b>Having a local SEO is extremely essential to help keep relevancy and boost your website’s local ranking</b>. We support your online presence thoroughly, to know more about how we do that, get in touch with us.&nbsp;</div><div style="max-width: 470px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div>            </div>
        </div>
    	        <div class="contentInsertBlock" >
            <div class="innerImgLeft animation-element slide-left in-view">
                <img src="members/seobusinessboost/mypages/seo-management-company-img.jpg" alt="SEO management company" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2>Get Professional SEO Marketing For Your Business</h2><div>Every day sees the rising need for <a href="https://www.seobusinessboost.com/email-us-your-request-9.php" title="" target="">SEO for every growing business</a>. And why is that? Because every day there is a new business or brand entering the market, each with it’s own pressure to fight to stay on top. It is our job to make sure your business maintains it’s rankings by staying on top, using professional SEO marketing.&nbsp;</div><div><br></div><h2>Your Go-To SEO Agency&nbsp;</h2><div>Developing effective SEO requires expertise and our agency has all the right tools and techniques to give your business the results you are looking for. <b>Our SEO agency will work with you to make sure all the relevant needs of your business</b> will be taken care of with the help of our team of expert developers. Feel free to get in touch with us to learn more.</div><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><style>.columns{display:flex;flex-flow:row wrap;justify-content:center;margin:5px 0}.column{flex:1;align-self:center}.column h3{margin:0}.column img{width:150px;vertical-align:middle;margin:10px 0}.filter-grey{filter:grayscale(1)}.text-center{text-align:center}.trust-logos-mob{display:none}@media screen and (max-width: 680px){.columns .column{flex-basis:50%;margin:0 0 5px 0}.column img{width:110px !important}.trust-logos-mob{display:block}.trust-logos{display:none}}</style>
<br>
<div class="text-center trust-logos"><h2>WE ARE ACCREDITED, TRUSTED &amp; 5 STAR RECOMMENDED.</h2> <section class="columns"><div class="column"><a href="https://www.bbb.org/us/al/gulf-shores/profile/pay-per-click-advertising/seo-business-boost-0463-90208283" target="_blank"><img src="../../members/seobusinessboost/mypages/better-business-bureau.jpg" alt="better-business-bureau"></a></div><div class="column"><img src="../../members/seobusinessboost/index/google-5s.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/yelp-5s.jpg" alt=""></div><div class="column"><a target="_blank" href="https://business.mygulfcoastchamber.com/list/member/seo-business-boost-8459"><img style="width: 145px !important;" src="../../members/seobusinessboost/index/chamber_logo.png" alt="chamber_logo"></a></div></section><section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/top-pro-badge-18.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/trustpilot.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/seo-certified-1.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/best-od-small-business.png" alt=""></div></section></div><div style="clear:both;" class="text-center trust-logos-mob"><h2>WE ARE ACCREDITED, TRUSTED &amp; 5 STAR RECOMMENDED.</h2><section class="columns"><div class="column"><a href="https://www.bbb.org/us/al/gulf-shores/profile/seo-services/seo-business-boost-0463-90208283"><img src="../../members/seobusinessboost/mypages/better-business-bureau.jpg" alt="better-business-bureau"></a></div><div class="column"><img src="../../members/seobusinessboost/index/google-5s.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/yelp-5s.jpg" alt=""></div><div class="column"><a target="_blank" href="https://business.mygulfcoastchamber.com/list/member/seo-business-boost-8459"><img style="width: 145px !important;" src="../../members/seobusinessboost/index/chamber_logo.png" alt="chamber_logo"></a></div><div class="column"><img src="../../members/seobusinessboost/index/top-pro-badge-18.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/trustpilot.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/seo-certified-1.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/best-od-small-business.png" alt=""></div></section></div><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><section class="columns text-center"><div class="column"><img src="../../members/seobusinessboost/index/moz.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/google-search-console.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/hubshout.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/google-analytics.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/semrush.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/g-trends.jpg" alt=""></div> </section><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div>            </div>
        </div>
                <div class="contentInsertBlock" >
            <div class="innerImgRight animation-element slide-right in-view">
                <img src="members/seobusinessboost/mypages/best-online-seo-company.1.jpg" alt="best online seo company" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2 style="margin-bottom: 0cm">Does SEO Work For Small Business?</h2><div><p style="margin-bottom: 0cm">As the <font color="#000080"><span lang="zxx"><a href="https://www.seobusinessboost.com/" title="" target="" style="">best online SEO company</a></span></font>, we use search engine optimization to uplift small businesses. Whether you own a large or small business, SEO is a profitable investment.</p><p style="margin-bottom: 0cm"><br></p><p style="margin-bottom: 0cm">We will help you dominate your local market through result-driven SEO campaigns. <b>As the best SEO company for small businesses, we bring you closer to your target customers.</b></p><p style="margin-bottom: 0cm"><b><br></b></p><p style="margin-bottom: 0cm">Unlike traditional SEO, local SEO works differently. <b>We capture local searches and use them for your business’ advantage.</b></p><p style="margin-bottom: 0cm"><b><br></b></p><p style="margin-bottom: 0cm">Location is very critical when performing local SEO. From there, we will identify your competitors and what we can do to outperform their SEO campaigns.</p><p style="margin-bottom: 0cm"><br></p><p style="margin-bottom: 0cm">We employ <font color="#000080"><span lang="zxx"><a href="https://www.seobusinessboost.com/website-seo-company-s6.php" title="" target="" style="">specialized
strategies</a></span></font> to connect you to your specific search area. Do you own a local business? We will ensure that you’re the top listing on the web! We deal with the technical aspect of SEO so you can focus on other things that matter.</p><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div></div>            </div>
        </div>
    	        <div class="contentInsertBlock" >
            <div class="innerImgLeft animation-element slide-left in-view">
                <img src="members/seobusinessboost/mypages/best-seo-company-for-small-business--1-.jpg" alt="best seo company for small business" width="100%" class="boxImgBorderShade"  onclick="window.open('https://www.seobusinessboost.com/get-free-quote-9.php','_blank')" style="cursor:pointer;" />
            </div>
            <div>
            <h2 style="margin-bottom: 0cm">Why Should You Invest In SEO To Improve Your Business?</h2><div><div style="margin-bottom: 0cm">Most businesses we have worked with don’t consider SEO as a worthy investment until they start reaping the benefits. <b>As the best SEO marketing company, we’ve seen hundreds of local businesses become successful with the help of proper optimization.</b></div><div style="margin-bottom: 0cm"><b><br></b></div><div style="margin-bottom: 0cm">Here at <font color="#000080"><span lang="zxx"><a href="https://www.seobusinessboost.com/about-us-8.php" style="">SEO Business Boost</a></span></font>, we want the same to happen to your business. We will help you generate more leads and increase your conversion rates beyond what you can imagine. The results of SEO are more cost-effective than PPC management services alone.<p></p><p style="margin-bottom: 0cm"><br></p></div><div style="margin-bottom: 0cm">In this digital era, businesses with a strong online presence are always the winners. Don’t let yours be left behind.</div><div style="margin-bottom: 0cm"><br></div><div style="margin-bottom: 0cm"></div><div style="margin-bottom: 0cm"><b>As the best online SEO company, SEO Business Boost is your go-to expert.</b> Let us transform your business into a highly profitable venture for a reasonable cost.</div><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div></div>            </div>
        </div>
        	 	<!-- Temaplate1 End-->
        
	   
	 	<!-- Template 17 End-->
		
    </div>
	 <!--Inner Body Content Endt-->
	 
 	</div>
 <!--Body Content End-->
	<!--Footer Page include page start-->
	<style>
@media only screen and (max-width: 768px) {
		.hideIndex{display:none !important;}
}
</style>
<input type="hidden" id="promotionaltoolText" value="">
<input type="hidden" id="promotionaltoolText1" value="">
<input type="hidden" id="promotionaltoolText2" value="">
<input type="hidden" id="promotionaltoolText3" value="MA==">
<input type="hidden" id="promotionaltoolText4" value="MA==">
<input type="hidden" id="promotionaltoolText5" value="MA==">

<!--Bottom Boxes start-->
<!-- Box Bottom Starts Here new div -->
<!-- Box Bottom Ends Here -->

<!-- Social Media -->
<!--End Social Media -->



<!--Footer start -->
<div class="footerModule" >
    <div class="footerBox" style="position:relative;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td class="footerMenuHeading" align="left" valign="middle">
        <span id="recordSitename"  >SEO Business Boost. SEO, PPC, Social Media and Website Design. </span> 
        
        </td>
        </tr>
        <tr>
        <td><table cellpadding="0" cellspacing="0" align="center" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="top">
          <ul class="footerMenuLinks">
              <li>			<a href="home-10.php"   >
			Home</a>
			</li>
            							<li><a href="website-builder-design-s1.php"   title="Web Design" >Web Design</a>
						</li>
																<li><a href="seo-management-company-s2.php"   title="SEO Management" >SEO Management</a>
						</li>
																<li><a href="google-adwords-s3.php"   title="Google Ads" >Google Ads</a>
						</li>
																<li><a href="facebook-ads-s4.php"   title="Facebook Ads" >Facebook Ads</a>
						</li>
																<li><a href="youtube-ads-s5.php"   title="YouTube Ads" >YouTube Ads</a>
						</li>
																<li><a href="digital-marketing-services-s17.php"   title="Digital Marketing" >Digital Marketing</a>
						</li>
																<li><a href="about-us-8.php"   title="About Us" >About Us</a>
						</li>
																<li><a href="email-us-your-request-9.php"   title="Contact Us" >Contact Us</a>
						</li>
																<li><a href="sitemap-18.php"   title="Sitemap" >Sitemap</a>
						</li>
																<li><a href="marketing-blog-26.php"   title="Marketing Blog" >Marketing Blog</a>
						</li>
																		
									
							

			        </ul>
        </td>
        
        
        <td class="footerPhoneNumber" id="footerphonetd" style="display:;" align="center" height="100" width="400">
        <table cellpadding="5" cellspacing="0" align="center" border="0">
        <tbody><tr>
        <td valign="middle"><img src="images/phone-icon-footer.png" height="50" width="50" alt="call"></td>
        <td valign="middle">251-424-5682</td>
        </tr>
        </tbody></table></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        <tr>
        <td class="footerTopLine">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="middle" width="55%" id="allrights_received" >
        <span id="rocID" >1545 Gulf Shores Parkway #146, Gulf Shores, AL 36542</span>
		 <br/>         <span id="AllRReserved" >Powered By <a href="https://www.cloudlgs.com/en/" target="_blank">www.CloudLGS.com</a></span></td>
        <td align="right" valign="top" width="45%">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="right">
				
		</td>
        <td align="right" valign="middle" width="25"  onClick="return sendmailfn()" id="controlPanel" style="cursor:pointer;"><a title="Control Panel" href="javascript:void(0)"><img src="images/control-panel-icon-footer.svg" alt="Control Panel" border="0"></a> <div class="cartToolTip" id="cartToolTip" style="display:none;">Click Here</div></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>
        
        </td>
        </tr>
        </tbody></table>
    </div>
</div>
<!--End Footer -->

<!-- Mobile Footer start-->
<div class="stickyFooterPad"></div><div class="footerModuleMobile" id="footerMenu" style="">
    <div>
        <div class="icn-mnu-stp-div">
            <div class="hme-strip-blk1 icnstrp-txt">
            <a href="home-10.php"><img src="images/hme-icn-v2.png" border="0" height="26" width="26" alt="Home"></a><br>
            <a href="home-10.php"   >Home</a>
            </div> 
              
            <div class="hme-strip-blk2 icnstrp-txt">
            <a href="about-us-8.php"><img src="images/abt-us-icn-v2.png" border="0" height="26" width="26" alt="About Us"></a><br>
            <a href="about-us-8.php"   >About Us</a>
            </div> 
             
             
            <div class="hme-strip-blk3 icnstrp-txt">
            <a href="email-us-your-request-9.php"><img src="images/cnt-us-icn-v2.png" border="0" height="26" width="26" alt="Contact Us"></a><br>
            <a href="email-us-your-request-9.php"   >Contact Us</a>
            </div> 
          			<div class="hme-strip-blk4 icnstrp-txt">
	<a href="directions.php"><img src="images/dirt-icn-v2.png" height="26" width="26" border="0" alt="Directions" /></a><br />
			<a href="directions.php">Directions</a>
			</div>  
			          </div>
    </div>

</div>
<!-- Mobile Footer end -->

<!--Login Pop Up Div Start-->
<div class="sample_popup-layout" id="logInDiv" style="display:none;" >
<div class="loginPopUpBlock">
<form  method="post" name="loginform" onSubmit="return validate_form(this);" >
<div class="loginTitleBlock" style="border-bottom:1px solid #ddd;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><div id="logintext">Login</div><div id="forgottext" style="display:none;">Forgot Login Details</div></td>
    <td align="right" valign="middle"><a href="javascript:void(0);" onclick="closeLog();"><img src="images/loginbox-close.png" alt="Close" width="31" height="31" border="0" /></a></td>
  </tr>
</table>
</div>
<div class="loginBodyBlock">
<div id="forgotloading" align="center" class="loginBoxHeadingTxt" style="font-size:12px;"></div>
<div id="loading" align="center"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="45" align="left" valign="middle">
    <div id="usernametr">
	<input name="password" class="loginTxtFldNew" id="username" value="Username" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="text" style="width:96%;">
    </div>
	<div id="forgotusernametr" style="display:none;">
    
    
    <div id="TabbedPanels1" class="TabbedPanels">
  <ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(1)" style="outline:0;" >User</li>
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(2)" style="outline:0;" >Admin</li>
  </ul>
  
  <div class="TabbedPanelsContentGroup" style="background-color: #ededed;">
  
    <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsusername" class="textBoxloginNew" id="lmsusername" value="Enter Your Registered Email" onfocus="if(this.value==this.defaultValue)this.value='';this.style.borderColor='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runPasswordScript(event)" style="width: 96%; " type="text">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
                
   <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsadminname" class="textBoxloginNew" id="lmsadminname" value="seo****@gmail.com    " onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" style="width: 96%;" type="text" disabled="disabled">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
  </div>
</div>   
	</div>
	</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="passwordtr">
		<div style="width:229px; float:left;">
		<input name="password" class="loginTxtFldNew" id="password" value="Password" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="password" style="width:217px;">
        </div>
        <div class="passwordDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <input type="checkbox" name="passwordChk" id="passwordChk" class="css-checkboxshowpass"/>
                <label for="passwordChk"  class="css-labelshowpass" style="float:left;">Show</label>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="captchatr" style="display:none;">
		<div style="width:185px; float:left;">
		<input type="text" name="login_captcha" id="login_captcha" class="loginTxtFldNew" value="Security Code" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" style="width:170px;">
		<input type="hidden" name="logincount" id="logincount" value="0" />
        </div>
        <div class="securityDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <img border="0" id="logincaptcha" src="captcha/image-login.php" alt="captcha" /></td>
			  <td width="50%" align="left" valign="middle"><a href="javaScript:new_logincaptcha();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr >
    <td align="left">
	<div id="checktr" style="font-size:12px; font-family:Arial, Helvetica, sans-serif;" ><input name="loginremembercheck[]" id="loginremembercheck" value="1" onclick="if(this.checked==true) this.value=1; else this.value=0;" class="css-checkboxrememberpass" checked="checked" type="checkbox">
     <label for="loginremembercheck" class="css-labelrememberpass" style="float:left;"></label><span style="padding: 5px 0px; display: block; float:left; font-family: 'Open Sans', sans-serif !important; font-size:14px; ">Remember me</span></div>	</td>
  </tr>
</table>
</div>
<div class="loginTitleBlock" style="border-top:1px solid #ddd;">
<div id="submitbtntr">
<input type="hidden" name="mid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="Submit" class="loginBoxBtnNew" value="Login" type="button" onclick="return logIn()"  style="cursor:pointer;"><input name="clickstatus" type="hidden" value="0" id="clickstatus"></td>
    <td align="right" valign="middle"><input name="forgotpass" id="forgotpass" class="loginBoxBtnNew" value="Need Help?" onclick="return showusertype();" style="cursor:pointer;" type="button"></td>
  </tr>
</table>
</div>
<div id="forgotsubmitbtntr" style="display:none;">
 <input type="hidden" name="forgotmid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="ForgotSubmit" class="loginBoxBtnNew" value="Submit" type="button" onClick="return LmsUserforgot();"  style="cursor:pointer;"> 
    <input type="hidden" value="1" id="hiddenactiveval"/>
    <input name="ForgotCancel" id="ForgotCancel" class="loginBoxBtnNew" value="Back" onClick="forgotCancel();" style="cursor:pointer;" type="button"></td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
</table>
</div>
</div>
</form>
</div>
</div>

<!--Login Pop Up Div End-->

<!--Dashboard options-->
<div id="dashboardPopup" class="sample_popup-layout" align="center"  style="display:none;"> 

<div class="newdashboardPopUp">
	<!-- Header Starts Here -->
    <div class="dashboardnew-row-1">
    	<table width="98%" border="0" cellspacing="0" cellpadding="5" align="center">
        <tbody>
            <tr>
            <td width="32%" align="left" valign="middle" class="dashboardhdngtxt"><span class="themeColor">Dashboard Options</span></td>
            <td width="60%" align="left" valign="middle"><a href="cms/logout.php?logout=1" >
			<img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out" />
			</a></td>
            <td width="21%" align="right" valign="middle"><a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
        <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
        </a></td>
          </tr>
        </tbody>
        </table>

    </div>
    <!-- Ends here -->
    
    <div class="dashboardnew-row-2">
    
    <div class="dashboardinnDivNew">
    	<div class="dashboardmndiv">
    <ul>
    	<li id="list1" ><a href="cms/" id="InsiteCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="cms">
             Manage your website content and images with inline edit feature             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/edit-website-flat.png" alt="Edit Website" width="110" height="96" border="0" /></div>
               <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Edit Website</span><br />
                    <span class="dashboardblksmllxt">Insite CMS</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list2"><a  href="admin/setting.php" id="displayCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="controlpanel">
              Web pages management, Images, SEO, E-Commerce and all other "Under the Hood" Settings
            </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/admin-panel-icon-flat.png" alt="Admin" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Admin</span><br />
                    <span class="dashboardblksmllxt">Website Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list3"><a  href="javascript:void(0);" onclick="submitAdminLoginForm();" id="adminControlPanelLink" style="  " >
        	<div class="icnblkdivmnovr" style="display:none;" id="lms">
             CloudLGS account settings like custom domain, payments and account renewals.
             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/control-panel-flat.png" alt="Control Panel" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Control Panel</span><br />
                    <span class="dashboardblksmllxt">Account Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
    </ul>
</div>
</div>
    
    
    </div>
    
    
    <div class="dashboardnew-row-3">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td height="40" align="right" valign="middle">
	      <div id="load_icon" align="center" style="display:none;"><img src="../images/loading.gif" alt="Loading...." /></div>
	      <a href="javascript:void(0);" class="buttonNewdash iconNewdash" id="see_more" onClick="openDashBoardMore();">See More Features</a>
      </td>
    </tr>
</table>
<input type="hidden" name="email" id="adminUserEmail" value="" />
<input type="hidden" name="user_pwd" id="adminUserPwd" value="" />
<input type="hidden" name="chg_pwd" id="adminUserChgPwd" value="" />
<input type="hidden" name="adminSessionId" id="adminSessionId" value="" />
    </div>
    
    
</div>
</div>
<!--Dashboard option block end-->


<!-- Dashboard More Features pop up -->
<div id="dashboardMorePopup" class="sample_popup-layout" align="center"  style="display:none;">  
<div style="margin:auto; max-width:768px;">
    <!-- Header Starts here -->
    <div class="headerPopDiv">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="94%" height="38" align="left" valign="middle" class="dashboardhdngtxt" style="font-size:22px; font-weight:normal;">
    <table border="0" cellspacing="0" cellpadding="2">
      <tr>
       <td align="left" valign="middle" class="themeColor">Dashboard Options</td>
        <td align="left" valign="middle">
        <a href="cms/logout.php?logout=1" >
        <img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out"/>
        </a>
    </td>
      </tr>
    </table>

    </td>
    <td width="6%" height="30" align="right" valign="middle">
    <a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
    <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
    </a>
    </td>
  </tr>
</table>
    </div>
    <!-- Header Ends here -->
    <!-- popupContentDiv -->
<div class="popContentDivFeatures">
<div class="featuerDivPopupICN" id="dashboard_options">
</div>  
</div>
<!-- popupContent Ends here -->

<!-- Footer Starts here -->
<div class="bottomDivPopUpfooter">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="355" height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td width="258" height="40" align="right" valign="middle">
      <a href="javascript:void(0);" class="buttonNewdash iconNewdashback" onClick="hideDashBoardMore();">Back</a>
      </td>
    </tr>
</table>
</div>
<!-- Footer Ends here -->
</div>
</div>
<!--Dashboard option block end-->
<!-- Social media script -->
<script src="/SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="/SpryAssets/SpryTabbedPanels2.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.screwdefaultbuttonsV2.min.js" ></script>
<script type="text/javascript">
$(function(){
	$('input:radio').screwDefaultButtons({
		image: 'url("images/radio-btn.png")',
		width: 26,
		height: 26
	});
});

function radiobtnactive(id){
	if(id==2){
		$("#hiddenactiveval").val('2');
	}	
	if(id==1){
		$("#hiddenactiveval").val('1');	}
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$('#list1').mouseenter(function() {
		$('#cms').fadeIn();
	});
	$('#list1').mouseleave(function() {
		$('#cms').fadeOut();
	});
	$('#list2').mouseenter(function() {
		$('#controlpanel').fadeIn();
	});
	$('#list2').mouseleave(function() {
		$('#controlpanel').fadeOut();
	});
	$('#list3').mouseenter(function() {
		$('#lms').fadeIn();
	});
	$('#list3').mouseleave(function() {
		$('#lms').fadeOut();
	});
});
function sendmailfn() 
{
$('body, html').animate({ scrollTop:0 }, 'slow');
$('body').css("margin-top","0px");
 var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );
document.getElementById('logInDiv').style.height=height+'px';
document.getElementById('logInDiv').style.display='block';
document.getElementById('clickstatus').value=1;
}

function closeLog(){
   document.getElementById('logInDiv').style.display='none';
   document.getElementById('loading').innerHTML='';
   document.getElementById('username').value="Username";
   document.getElementById('password').value="Password";
   forgotCancel();
}
function showusertype(){
	document.getElementById('usernametr').style.display='none';
	document.getElementById('forgottext').style.display='block';
	document.getElementById('logintext').style.display='none';  
	document.getElementById('passwordtr').style.display='none';
	document.getElementById('checktr').style.display='none';
	$('#captchatr').hide();
	
	document.getElementById('forgotusernametr').style.display='block';
	document.getElementById('submitbtntr').style.display='none';
	document.getElementById('forgotsubmitbtntr').style.display='block'; 
	document.getElementById('lmsusername').style.borderColor='';
}
function  forgotCancel(){
	document.getElementById('usernametr').style.display='block';
	document.getElementById('forgottext').style.display='none';
	document.getElementById('logintext').style.display='block';  
	document.getElementById('passwordtr').style.display='block';
	document.getElementById('checktr').style.display='block';
	if($('#logincount').val()==1){$('#captchatr').show();}
	document.getElementById('forgotusernametr').style.display='none';
	document.getElementById('submitbtntr').style.display='block';
	document.getElementById('forgotsubmitbtntr').style.display='none';
	document.getElementById('lmsusername').style.borderColor='';
}
					
function LmsUserforgot(){
	var username=$("#lmsusername").val();
	var activetab=$("#hiddenactiveval").val();
	if(activetab==1){
		sendUserMail();
	} else {
		sendAdminMail();
	}
}

function sendUserMail(){
	var username=$("#lmsusername").val();
	if(username!="" &&  username=="Enter Your Registered Email"){
		$("#lmsusername").css('border-color', '#CC0000'); return false;
	} else if(validateEmail(username)===false){
		$("#lmsusername").css('border-color', '#CC0000');
		var text="<span style='color:#CC0000'>Please enter valid email.</span>";
		$('#forgotloading').show();
		$('#forgotloading').html(text);
		setTimeout(function(){$('#forgotloading').hide();},4000);
		return false;
	} else {
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "../lms/forgotpasswordlmsuser.php",
			data: {username:username,source:'site'},
			cache: false,
			success: function(val){
				document.getElementById('loading').innerHTML='';
				if(val==1) {
					var text="<span style='color:green'>Details has been sent to mail successfully</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
						setTimeout(function(){$('#forgotloading').hide();},4000);
				} else {
					$("#lmsusername").css('border-color', '#CC0000');
					var text="<span style='color:#CC0000'>No user exists with this email.</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
					setTimeout(function(){$('#forgotloading').hide();},4000);
				}
				document.getElementById('lmsusername').value='Enter Your Registered Email';
			}
		});
	}
}

function sendAdminMail(){
	document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
	var username="admin";
	$.ajax({
	type: "POST",
	url: "../lms/forgotpasswordlmsuser.php",
	data: {username:username,source:'site'},
	cache: false,
	success: function(val){
		document.getElementById('loading').innerHTML='';
		if(val==1) {
			var text="<span style='color:green'>Details has been sent to mail successfully</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
			setTimeout(function(){$('#forgotloading').hide();},4000);
		} else {
			var text="<span style='color:#CC0000'>No user exists with this email.</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
		}
		document.getElementById('lmsusername').value='Enter Your Registered Email';
	}
	});	
}

function validateEmail(elementValue){        
    var emailPattern = /^[a-zA-Z0-9._]+[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,4}$/;  
    return emailPattern.test(elementValue);   
  }
  
function logIn(){
	var username= $('#username').val();
	var password = $('#password').val();
	var clickstatus=$('#clickstatus').val();
	var loginremembercheck = $('#loginremembercheck').val();
	var logincount=$('#logincount').val();
	var login_captcha=$('#login_captcha').val();
	var validLogForm=true;
	if(logincount==1){
		$('#captchatr').show();
		if(login_captcha==''||login_captcha=='Security Code'){
			$('#login_captcha').css('border-color','red');
			validLogForm=false;
		}else{
			$('#login_captcha').css('border-color','');
		}
	}else{
		$('#captchatr').hide();
		$('#login_captcha').css('border-color','');
	}
	if(username==''||username=='Username'){
		$('#username').css('border-color','red');
		validLogForm=false;
	}else{
		$('#username').css('border-color','');
	}
	if(password==''||password=='Password'){
		$('#password').css('border-color','red');
		validLogForm=false;
	}else{
		$('#password').css('border-color','');
	}
	if(clickstatus==1&&validLogForm==true){
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "login.php",
			data:{username:username,password:password,loginremembercheck:loginremembercheck,login_captcha:login_captcha},
			dataType: "json",
			cache: false,
			success: function(data){
				if(data.message==1){
					document.getElementById('logInDiv').style.display='none';
					document.getElementById('loading').innerHTML='';
					$('#controlPanel').attr('onclick','openDashboard();');
					$('#logInSessionReload').attr('onclick','dashboardPopupClose2();');
					if(data.admin=='Yes'){
						$('#adminUserEmail').val(data.adminUserEmail);
						$('#adminUserPwd').val(data.adminUserPwd);
						$('#adminUserChgPwd').val(data.adminUserChgPwd);
						$('#adminControlPanelLink').css('display','block');
						$('#adminSessionId').val(data.adminSessionId);
					} else {
						$('#adminControlPanelLink').css('display','none');
						$('#adminControlPanelLinkText').css('display','none');
					}
					if(data.editsite=='2'){
						$('#displayCmsLink').css('display','block');
					} else {
						$('#displayCmsLink').css('display','none');
						$('#displayCmsLinkText').css('display','none');
					}
					openDashboard();
				} else if(data.message==2){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Invalid username and password </div>";
					document.getElementById('loading').innerHTML=error;
					if(data.lgsattempt>5){$('#captchatr').show();$('#logincount').val(1);}
				} else if(data.message==3){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User has no permissions to Edit</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==4) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User account is suspended.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==5) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Not authorized from this system.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==6) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Please enter security code.</div>";
					document.getElementById('loading').innerHTML=error;
				}
			}
		});
	}
}

function runPasswordScript(e){
	if (e.keyCode == 13) {
        LmsUserforgot();
        return false;
    }
	return true;
}
function runScript(e) {
    if (e.keyCode == 13) {
        logIn();
        return false;
    }
	return true;
}

function openDashboard(){
$('body, html').animate({ scrollTop: 0 }, 'slow');
$('body').css("margin-top","0px");
var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );

document.getElementById('dashboardPopup').style.height=height-75+'px';
$('#dashboardPopup').show();
$("#cartToolTip").hide();
}
function dashboardPopupClose()
{
	$('#load_icon').hide();
	$('#see_more').show();
	$('#dashboardPopup').hide();
	$('#dashboardMorePopup').hide();	
}
function dashboardPopupClose2()
{
	$('#dashboardPopup').hide();
}
function openDashBoardMore() {
	$('#load_icon').show();
	$('#see_more').hide();

	var dataString = {id:1};
	$.ajax({
		type: "POST",
		url: "includes/dashboard-options.php",
		cache: false,
		data: dataString,
		success: function(val)
		{
			$('#dashboard_options').html(val);
			$('body, html').animate({ scrollTop: 0 }, 'slow');
			$('body').css("margin-top","0px");
			var body = document.body,
			html = document.documentElement;
			var height = Math.max( body.scrollHeight, body.offsetHeight,
			html.clientHeight, html.scrollHeight, html.offsetHeight );
			document.getElementById('dashboardMorePopup').style.height=height-75+'px';
			$('#dashboardPopup').hide();
			$('#dashboardMorePopup').show();
		}
	});
	
}
function hideDashBoardMore() {
	$('#load_icon').hide();
	$('#see_more').show();
	$('body').css("margin-top","0px");
	$('body, html').animate({ scrollTop: 0 }, 'slow');
	var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('dashboardPopup').style.height=height-75+'px';
	$('#dashboardPopup').show();
	$('#dashboardMorePopup').hide();
}
function submitAdminLoginForm(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function submitchangeurl(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site2.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function trailpayment(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site3.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function CancelAccount(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/sign-in-canceltest.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function new_logincaptcha(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('logincaptcha').src = '/captcha/image-login.php?x='+ c_miliseconds;
}
</script>
<!-- End Social media script -->
<style>
.loginpopinndiv{width:326px; margin:auto;}
.radioBtnLogin{font-family: "Lucida Sans Unicode","Lucida Grande",sans-serif; font-size:16px; color:#333333;}
.inncntBlkLoginDiv{background:#ffffff; padding:10px; }
.textBoxloginNew{border: 1px solid #D7D7D7; padding: 8px 5px; color: #666; font-size: 14px;}
.inncntBlkLoginDiv span{color:#666666; font-size:12px; font-family:Helvetica, Arial, sans-serif; padding:10px 5px; display:block;
background:#f5f5f5; margin:5px 0px 0px 0px;}

#AllRReserved a{
	text-decoration:underline;
}

.loginPopUpBlock {
	max-width:350px;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
	overflow:hidden;
	margin:auto;
	margin-top:60px;
	background-color:#FFF;
	-webkit-box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	-moz-box-shadow:    0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	box-shadow:         0px 0px 15px 0px rgba(0, 0, 0, 0.75);
}
.loginTitleBlock { background:#f7f7f7; padding:10px 25px; font-size:18px; font-weight:normal !important; overflow:hidden; }
.loginBodyBlock { padding:10px 16px; }
.loginBoxHeadingTxt {font-size:20px; color:#555555; }

input[type=checkbox].css-checkboxrememberpass { display:none; }
input[type=checkbox].css-checkboxrememberpass + label.css-labelrememberpass {
padding-left:40px; height:31px; display:inline-block; line-height:31px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }
input[type=checkbox].css-checkboxrememberpass:checked + label.css-labelrememberpass { background-position: 0% -31px; }
.css-labelrememberpass { background-image:url(../images/websetting-checkbox-flat.png);}

input[type=checkbox].css-checkboxshowpass { display:none; }

input[type=checkbox].css-checkboxshowpass + label.css-labelshowpass { padding-left:30px; height:25px; display:inline-block; line-height:25px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }

input[type=checkbox].css-checkboxshowpass:checked + label.css-labelshowpass {
background-position: 0% -25px;
}
.css-labelshowpass { background-image:url(../images/checkbox-shwpwd.png);}

.passwordDiv{background:#617284; height:33px; border:1px solid #4a5f72; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.securityDiv{ height:33px; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.member-top-inner {position: fixed; text-align: center; z-index: 99999999; width: 45px; height: 42px; line-height: 35px; right: 30px; bottom: 90px; padding-top: 2px; border-radius: 50%; transition: all 0.5s ease-in-out; background: url(../images/members-area-sticky-icon.png) #258fea no-repeat center !important; cursor:pointer;}

/* The hint to Hide and Show */

.hint { position: absolute; width: 133px; margin-top: 3px; margin-left:-162px;
border: 1px solid #edd5a6; padding: 0px 8px; color:#333; z-index:2; display:none;
background: #ffffda no-repeat -10px 5px; font-weight:normal; font-size: 12px;
font-family: Arial, Helvetica, sans-serif; border-radius:4px; }

/* The pointer image is hadded by using another span */
.hint-pointer { position: absolute; left: 149px; top: 9px; width: 8px;
height: 19px; background: url(cms/images/right-pointer.gif) right top no-repeat; }
.loginBoxBtnNew{font-family: 'Open Sans', sans-serif; font-size:14px !important; background-image:none !important;}

.newdashboardPopUp{margin:auto; max-width:650px; background:#ffffff; overflow:hidden; border-radius:10px;}
.dashboardnew-row-1{background:#ececec; overflow:hidden; padding:5px; font-size:20px; font-weight:normal;}
.dashboardnew-row-2{padding:15px; overflow:hidden; clear:both;}
.dashboardnew-row-3{background:#ececec; overflow:hidden; padding:15px; clear:both;}

@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.member-top-inner {right: 12px;bottom: 205px;  }
}

</style>

<link href='https://fonts.googleapis.com/css?family=Open+Sans|Pontano+Sans' rel='stylesheet' type='text/css'>


<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>

<script type="text/javascript">
var callFooterEfffects=function footerEffects()
{
if($(window).width() > 320){
    $("input:text").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:password").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("textarea").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:button").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );	
	$("input:submit").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:text").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("input:password").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("textarea").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
}
};
$(document).ready(callFooterEfffects);
$(window).resize(callFooterEfffects);

$(function(){
	$(document).on( 'scroll', function(){
		if ($(window).scrollTop() > 100) {
			$('.scroll-top-wrapper').addClass('show');
		} else {
			$('.scroll-top-wrapper').removeClass('show');
		}
	});
	$('.scroll-top-wrapper').on('click', scrollToTop);
});
	
function scrollToTop() {
	verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
	element = $('body');
	offset = element.offset();
	offsetTop = offset.top;
	if((/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i).test(navigator.userAgent || navigator.vendor || window.opera)==true){
		$('html, body').css('overflow-y', 'hidden');
		$('html, body').scrollTop(0);
		$('html, body').css('overflow-y', '');
		//$('html, body').animate({scrollTop: 0}, 500, 'linear');
	}else{
		$('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
	}
}
	
	$("#leftImage").hover(	
	function() {
	$("#leftImagetitle").show();
	}, function() {
	$("#leftImagetitle").hide();
	}
	);
	
	$("#rightImage").hover(	
	function() {
	$("#rightImagetitle").show();
	}, function() {
	$("#rightImagetitle").hide();
	}
	);
	
$( ".member-top-inner" ).click(function() {
 		window.location.href ="members-home.php";
 		//window.location.href ="members-home_id47_v1.php";

});
function fieldhint(id){
	document.getElementById(id+"_hint").style.display = "block";
}
function fieldhint1(id){
	document.getElementById(id+"_hint").style.display = "none";
}	
</script>
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-176053839-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-176053839-1');
</script>

<script type="text/javascript">
$(document).ready(function(){
$('input[name="passwordChk"]').click(function(){
if($(this).is(':checked')== true)
{document.getElementById("password").setAttribute('type', 'text');} 
if($(this).is(':checked')== false)
{document.getElementById("password").setAttribute('type', 'password');}
});
});
</script>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>




<script type="text/javascript" src="//cdn.calltrk.com/companies/566306024/0dc36fd4a782002e285c/12/swap.js"></script> 
<!-- Global site tag (gtag.js) - Google Ads: 600261187 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-600261187"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-600261187');
</script>
<!-- CANDDi https://www.canddi.com/privacy -->
<script async type="text/javascript" src="//cdns.canddi.com/p/44b13b5eeaf66ba606408a64c4ea8e14.js"></script>
<noscript style="display:none;visibility:hidden;"><img src='https://i.canddi.com/i.gif?A=44b13b5eeaf66ba606408a64c4ea8e14'/></noscript>
<!-- /END CANDDi -->
<!-- Clickcease.com tracking-->
<script type='text/javascript'>var script = document.createElement('script');
script.async = true; script.type = 'text/javascript';
var target = 'https://www.clickcease.com/monitor/stat.js';
script.src = target;var elem = document.head;elem.appendChild(script);
</script>
<noscript>
<a href='https://www.clickcease.com' rel='nofollow'><img src='https://monitor.clickcease.com/stats/stats.aspx' alt='ClickCease'/></a>
</noscript>
<!-- Clickcease.com tracking-->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '535512043295157'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=535512043295157&ev=PageView&noscript=1" alt="Facebook Pixel" /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
<script src="../js/jquery.exitintent.js"></script>
<script>
$(function() {
	var user=getCookie("exitintent_popup");
	if (user == "") {
		$.exitIntent('enable');
		$(document).bind('exitintent', function() {
			$("#ballonseffects").show();
		});
	}
	$(document).bind('exitintent', function() {
		var countbutton='';
		if(countbutton=="40506" || countbutton=="405" || countbutton=="506" || countbutton=="406"){
			setTimeout(function() {$("#ballonseffects").remove();}, 13500);
			setCookie("exitintent_popup","test", 1);
			return false;
		  }else{
			setTimeout(function() {$("#ballonseffects").remove();}, 9000);
			setCookie("exitintent_popup","test", 1);
			return false;
		}  
	});
});

function setCookie(cname,cvalue,exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays*60*5000));
	var expires = "expires=" + d.toGMTString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}



</script>
    <!--Footer Page include page end-->
	
</div>

<!-- Animation Effetct -->
<script src="visualize.js" type="text/javascript" ></script>
<!-- Animation Effetct Ends here -->

<!--Page Container end-->
<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>
<!-- Live Chat Styles Starts Here -->
<style>
.chatCircle{width:58px; height:58px; border-radius:50%; position:fixed; cursor:pointer;z-index:99;top:75%}
.chatCircleIcon{width:58px; height:58px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.chatCircleMob{width:58px; height:58px; border-radius:50%; position:fixed; left:10px; bottom:90px; display:none; z-index:99;}

.chatCircle-v2{width:53px; height:53px; border-radius:50%;  position:fixed; bottom:88px; right:30px; z-index:99;cursor:pointer;}
.chatCircleIcon-v2{width:53px; height:53px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.arrow-downIcn {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #1c80d5;
margin: -5px 0px 0px 26px;cursor:pointer;}
.closeIcnChat{float:right; cursor:pointer; padding:7px; border-radius:50%;}

.liveChatMain { max-width: 390px; width: 100%; position: fixed; background: #ffffff; font-family: 'Open Sans', sans-serif; color: #000000;
font-size: 20px; font-weight: normal; -webkit-border-radius: 4px; -moz-border-radius: 4px;}
.livechatMainRight{right: 53px;bottom: 158px;}
.livechatMainLeft{left: 89px; bottom: 40px;}

.liveChatInn{padding:18px;position:relative;}
.liveChatbox{background:#ececec; font-family:'Open Sans', sans-serif; color:#333; font-size:18px; font-weight:normal; border-radius:4px; 
-webkit-border-radius:4px; -moz-border-radius:4px; text-align:left; border:0; resize:none; padding: 10px; width: 100%; margin:10px auto; 
border: 1px solid #ECECEC; box-sizing: border-box;}
.nextBtn{font-family:'Open Sans', sans-serif; color:#fff; font-size:16px; font-weight:normal; text-align:left; border:0; 
padding: 6px 22px; width: 100%; cursor:pointer;}
.arrow-down {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #ffffff; position:absolute;right:15px;}
.successTxt{font-family:'Open Sans', sans-serif; color:#1E99EE; font-size:24px; font-weight:normal;background:#fff;
text-align:center;clear: both;border-radius: 4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;padding:15px 0px;
margin: 10% auto 10% auto;width: 320px;}
.arrow-left {width: 0; height: 0; border-left: 10px solid transparent; border-right: 11px solid transparent;
border-top: 54px solid #ffffff; -moz-transform: rotate(45deg); -webkit-transform: rotate(45deg); -o-transform: rotate(45deg);
-ms-transform: rotate(45deg); margin: 21px 0px 0px 0px; right: 389px !important; z-index: 9 !important; position:absolute !important;}
.leftShadow{-webkit-box-shadow: -5px -1px 44px 0px rgba(129, 129, 129, 0.5);}

@media only screen and (max-width:767px),
only screen and (max-device-width:767px){
.chatCircle-v2{bottom:130px;right:12px;}

.livechatMainRight, .livechatMainLeft{right: 0px; bottom: 150px; left:0px;}
.liveChatMain { width:98%; margin:auto;}
.arrow-down, .arrow-left{ display:none;}
.successTxt{padding:15px 0px; width:100%;}
}
@media only screen and (max-width:760px),
only screen and (max-device-width:760px){
	.nextBtn{padding:10px 22px !important;}
}
</style>
<!-- Ends here -->
<!-- Social Media Icons -->
 <div style="top:80%; ">
 <div class="chatCircle bgcolorTheme" id="desktop_left" onClick="livechatpopup(1);" style="display:none;cursor:pointer">	
		<div class="chatCircleIcon" ><img src="images/chat-icn-v1.svg"  height="32" width="32" border="0" alt="Live Chat" /></div>
 </div>
</div>
<!-- Ends here -->
<!-- Live Chat Icon Mobile Option v1 -->
<div class="chatCircleMob bgcolorTheme" id="mobile_left"  onClick="livechatpopup(1);" style="display:none;">	
	<div class="chatCircleIcon"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
</div>
<!-- Ends here -->

<!-- Live Chat Icon Option 2 -->
<div class="chatCircle-v2 bgcolorTheme" id="desk_mob_right"  onClick="livechatpopup(1);" style="display:none;cursor:pointer">
	<div class="chatCircleIcon-v2"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
    
</div>
<!-- Ends here -->

<!-- Live Chat Pop Up Starts Here -->
<div class="liveChatMain livechatMainRight" id="livemsg" style="z-index:9999999;display:none;"  role="" >
		<div class="arrow-left" style="display:none;" ></div>
		<div class="liveChatInn" id="livechatdiv" style="display:;  box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -moz-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -webkit-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); display: block;">
			<div class="liveChathead" id="messageme">
				<span>Chat with us now</span>
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(2)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
                </span>
				<textarea name="chatmessage" id="chatmessage" class="liveChatbox" placeholder="Send us a message for a fast response" rows="3" onfocus="this.style.border='';" maxlength="1000" ></textarea>	
				<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" onclick="return livechat_next(1);"  name="next" id="next" value="Next" /></div>
				</div>
			</div>
			<div class="liveChathead" id="liveemail" style="display:none;">
			<span style="display:">Additional details</span> 
			<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(3)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
            </span>
				<input type="text" name="chatemail" id="chatemail" class="liveChatbox" placeholder="Your email address" onfocus="this.style.border='';" style="margin-bottom:5%;" maxlength="80"/>
				<div style="overflow: hidden;margin-bottom: 8%;">
					<div style="float:right;">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="left" valign="middle"><img border="0" id="security_code_capcha" src="captcha/image-livechat.php" alt="captcha" /></td>
							<td align="left" valign="middle"><a href="JavaScript: new_captcha_live();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a></td>
						</tr>
					</table>
					</div>
					<div  style="float:left;width:62%">
					<input name="security_code_lc"  maxlength="5" type="text" id="security_code_lc"  value=""  placeholder="Security Code"class="textboxlogin" onFocus="document.getElementById('security_code_lc').style.borderColor=''" style="background: #ececec; font-family: 'Open Sans', sans-serif; color: #333; font-size: 14.5px; font-weight: normal;width:100%" />	
					</div>					
				</div>
				<div style="display: none;color:red;font-size: 14px;text-align: center;" id="live_secure_issue">Invalid Security Code</div>
				
				
				<div style="font-size:12px;float:left;display:;cursor:pointer;"><a href="javascript:livechat_next(2);" style="text-decoration:none;color:#4B4C4E;"><img src="/images/left-arrow-new.png" style="vertical-align:middle;" border="0" height="15" width="18" alt="Live Chat Back"> <span> Edit message</span></a></div>
			<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" name="savechat" id="savechat" value="Submit" onclick="return submit_livechat();"/>
				<input type="hidden" name="verifyHuman_livechat" id="verifyHuman_livechat" value="shift!&XYZ" />
				<input type="hidden" name="spamRestrict1_livechat" id="spamRestrict1_livechat" value="a5d7cca987e3ae48f5e460157272b9a5" />
				<input type="hidden" name="spamRestrict2_livechat" id="spamRestrict2_livechat" value="5a9b272751064e5f84ea3e789acc7d5a" />
				<input type="hidden" name="spamRestrict3_livechat" id="spamRestrict3_livechat" value="" />
				</div>
			</div>
			</div>
			
	<div style="display:none;" id="livethankyou">
		<div class="liveChatInn" style="background:#ededed;">
			<div class="liveChathead">
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(4)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" alt="Live Chat Close" /></a>
                </span>
			</div>
			<div class="successTxt"><span>Message sent successfully.</span><br><span style="font-size:18px;color:#000000;">We'll be in touch.</span></div>
		</div>
	</div>
	</div>
<div class="arrow-down" id="arrow" style=""></div>    
</div>
<!-- Ends here -->
<script type="text/javascript">
//////live chat popup ///////////
function livechatpopup(val){
	if(val==1){
	$("#livemsg").toggle();
	}else{
		$("#livemsg").hide();
	}
}
function livechatpopupclose(){
	$("#livemsg").hide();
}

function livechat_next(id){
	if(id==1) {
		var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
		if(chatmessage==""){
			$('#chatmessage').css('border','1px solid #cc0000');
			return false;
		} else {
			$('#messageme').hide();
			$('#liveemail').show();
		}
	}
	if(id==2) {
		$('#messageme').show();
		$('#liveemail').hide();
	}
} 
function submit_livechat(){
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
	var chatemail = $('#chatemail').val().replace(/^\s+|\s+$/g,'');
	var security_code_lc=$('#security_code_lc').val().replace(/ /g,'');
	var source="Chat Box";
	if(chatemail=="" || reg.test(chatemail)==false || security_code_lc==''||security_code_lc=='Security Code'){
		if(chatemail=="" || reg.test(chatemail)==false){$('#chatemail').css('border','1px solid #cc0000')};
		if( security_code_lc==''||security_code_lc=='Security Code'){$('#security_code_lc').css('border','1px solid #cc0000')};
		return false;
	} else {
		$("#verifyHuman_livechat").val("shift$%123");
		
		var verifyHuman=document.getElementById("verifyHuman_livechat").value;
		var spamRestrict1=document.getElementById("spamRestrict1_livechat").value;
		var spamRestrict2=document.getElementById("spamRestrict2_livechat").value;
		var spamRestrict3=document.getElementById("spamRestrict3_livechat").value;
		
		$.ajax({
			type: "POST",
			url: "livechat-submit.php",
			data:{chatmessage:chatmessage,chatemail:chatemail,source:source,verifyHuman:verifyHuman,spamRestrict1:spamRestrict1,spamRestrict2:spamRestrict2,spamRestrict3:spamRestrict3,security_code_lc:security_code_lc},
			cache: false,
			success: function(html) {
				if(html==1){
                    $('#liveemail').hide();
					$('#livethankyou').show();
				}else{
					$('#live_secure_issue').show();
					setTimeout(function(){ $('#live_secure_issue').hide(); }, 3000);
				}
			}
			
		});
	}	
}
function new_captcha_live(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('security_code_capcha').src = 'captcha/image-livechat.php?x='+ c_miliseconds;
}
</script>
</body>
</html>