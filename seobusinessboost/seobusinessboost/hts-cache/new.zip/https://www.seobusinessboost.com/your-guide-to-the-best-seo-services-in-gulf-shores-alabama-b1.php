<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Your Guide To The Best SEO Services in Gulf Shores, Alabama</title>

<meta name="description" content="SEO can maintain your website&rsquo;s rankings online so you can always stay ahead of your competitors." />
<meta name="keywords" content="SEO, Search Engine Optimization, SEO in Alabama, Alabama" />
<meta property="og:title" content="Your Guide To The Best SEO Services in Gulf Shores, Alabama" />
<meta property="og:type" content="article" />
<meta property="og:url" content="https://www.seobusinessboost.com/your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php" />
<link rel="image_src" href="https://www.seobusinessboost.com/members/seobusinessboost/blog/seo-1.jpg" />
<meta property="og:image" content="https://www.seobusinessboost.com/members/seobusinessboost/blog/seo-1.jpg" />
<meta property="og:site_name" content="https://www.seobusinessboost.com" />
<meta property="og:description" content="SEO can maintain your website&rsquo;s rankings online so you can always stay ahead of your competitors." />
<meta property="og:image:width" content="450"/>
<meta property="og:image:height" content="298"/>
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">
<link rel="canonical" href="https://www.seobusinessboost.com/your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php" />
<link rel="alternate" media="only screen and (max-width: 640px)" href="https://www.seobusinessboost.com/m/your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php" />
<!--[if IE]><link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" /><![endif]-->
<link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" /> 

<link href="css/main-layout-new.css" rel="stylesheet" type="text/css" />
<link href="css/main-theme-1.css" rel="stylesheet" type="text/css" />
<link href="css/listcarousel.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script>

</script>

<style type="text/css">
<!--#blogSideScroll {
	overflow: auto;
	height: 460px;
}-->
</style>
<style type="text/css">
#charLeft { color:#F00; }
#emailid { display:none; }
.mywebsiteurl{display:none;}
.spamRestrict1{display:none;}
.spamRestrict2{display:none;}
.blogContentImg img {max-width:299px; max-height:299px;}
.blogMainBody {width:685px; overflow:hidden; float:left;}
.blogMainBody ul {list-style:none; margin:0px; padding:0px;}
.blogMainBody ul li {list-style:none; margin:0px; padding:10px 0px;}
.contentPadd5{ padding:8px 0px; overflow:hidden;}
.blogPostedDate {height: 16px; font-size: 11px; float: left; margin-right: 20px; padding-bottom: 10px; 
background: url(../images/time-icn.png) left center no-repeat;}
.blogCommentsCount { height: 16px; font-size: 11px; float: left; margin-right: 20px; padding-bottom: 10px;
    background: url(../images/comment-icn.png) left center no-repeat;}
.blogImgDivNew{width:100%;}
.setSizesVideo{ width:100%; height:350px;}
.blogImgCls{max-width:685px;}
.srchSugDiv ul {margin:0px;padding:8px;list-style:none;}
.srchSugDiv ul li {padding:6px 0px;color: #777; font-size: 16px;}
.srchSugDiv ul li b {color: #333;}
.srchSugDiv {
    z-index:999;
    width: auto;
    padding: 5px;
    overflow: hidden;
    font-family: 'Open Sans', sans-serif;
    font-size: 14px;
    color: #333333;
    background: #FFF;
    -webkit-border-radius: 8px;
    -moz-border-radius: 8px;
    border-radius: 0px;
    clear: both;
    margin-bottom: 10px;
    cursor: pointer;
    position: absolute;
		right: 1px;
    top: 77px;
	    width: 237px;
	box-shadow:0px 2px 7px 2px rgba(153,153,153,1);
	-ms-box-shadow:0px 2px 7px 2px rgba(153,153,153,1);
    -webkit-box-shadow: 0px 2px 7px 2px rgba(153,153,153,1);
    -moz-box-shadow: 0px 2px 7px 2px rgba(153,153,153,1);
  
}
.shareBtnsDiv{float: right; margin: -20px 0px 0px 0px;}
@media only screen and (max-width: 760px), only screen and (max-device-width: 760px)
{
.blogMainBody {width: auto; float: none;}
.contentPadd5 { padding:10px 20px; font-weight: 300;}
.blogImgDivNew{max-width:100%;}
.setSizesVideo{width:100%; height:350px;}
.shareBtnsDiv{float: none; margin: 0px; clear: both; display: block; padding: 10px 0px 0px 0px;}
}
.blogsearchTXT {border: 1px solid #cccccc;border-radius:0px;}
.srchRecDiv {width: auto;padding: 15px 10px;overflow: hidden;font-family: 'Open Sans', sans-serif;font-size: 14px;color: #333333;background: #F5F5F5;-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;clear: both;margin-bottom:10px;}
.srchRecDiv ul {margin:0px;padding:0px 10px;list-style:none;}
.srchRecDiv ul li {margin:0px 0px 5px 0px;padding:0px;}

@media only screen and (max-width:639px),
only screen and (max-device-width:639px){
	.blogContentImg img {max-width:100%; max-height:100%;}
	.srchRecDiv {font-size:18px;}
	.srchSugDiv {
	    width: auto !important;
        left: 11px;
        max-width: 90%;
        padding: 0px !important;
        position: relative !important;
        top: -21px !important;
	}
	.contentPadd5 h2{ font-size:24px;}
	.contentPadd5 h3{ font-size:22px;}
	.contentPadd5 h4{ font-size:20px;}
	.contentPadd5 h5{ font-size:20px;}
}
@media only screen and (max-width:584px),
only screen and (max-device-width:584px){
	.srchSugDiv {
       right: 61px !important;
      
	}
}
@media only screen and (max-width:480px),
only screen and (max-device-width:480px){
	.blogImgCls{width:100%;}
	.srchSugDiv {
       right: 43px !important;
      
	}
}
@media only screen and (max-width:418px),
only screen and (max-device-width:418px){
	.srchSugDiv {
       right: 33px !important;
      
	}
}
@media only screen and (max-width:380px),
only screen and (max-device-width:380px){
	.srchSugDiv {
       right: 26px !important;
	    max-width: 92%;
      
	}
}
@media only screen and (max-width:360px),
only screen and (max-device-width:360px){
	.srchSugDiv {
       right: 22px !important;
      
	}
}
@media only screen and (max-width:320px),
only screen and (max-device-width:320px){
	.srchSugDiv {
       right: 22px !important;
      
	}
}
</style>
<script type="text/javascript" >
function shareOnFB(){
	window.open('https://www.facebook.com/sharer/sharer.php?u=https://www.seobusinessboost.com/your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php', 'facebookwindow', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
function shareTwitter(){
	window.open('https://twitter.com/share?url=https://www.seobusinessboost.com/your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php', 'twitterwindow', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
</script>
<script>
function goBack() {
    window.history.back();
}
</script>
</head>

<body>
<div class="container" >
<link href="css/main-layout3-new.css" rel="stylesheet" type="text/css" />
<link href="css/main-layout5.0.1.min.css" rel="stylesheet" type="text/css" />

<link href="css/layout5-header.0.1.min.css" rel="stylesheet" type="text/css" />
<!--<link href="css/.css?ver1.0" rel="stylesheet" type="text/css">-->
<link href="css/svg-fonts-styles.css" rel="stylesheet" type="text/css" />
<style>
.menuOptIcnInnDiv{border: 1px solid #e3e3e3 !important; text-align: center; margin-top:6px; height: 50px;}
.menuOptIcnInnDiv a{ text-decoration:none !important;}
.logoMid {width:60%; position:relative;}
.menuMobNew {
	padding: 2px 4px;
}
.submenuPad .menuMobNew a span{
	width:auto !important;
}
.menuMobNew a span {
	width:auto;
	display:block;
	min-height:80px;
	float:none;
	height:auto !important;
}
.subMenuMain a div{
	min-height:70px;
	height:auto !important;
}
.logo{position:relative;}

.cartToolTip {
	right: -32px;
    position: absolute;
    bottom: 55px;
    z-index: 9;
    background: #dfca80;
    color: #000;
    padding: 13px 15px;
    border-radius: 5px;
    font-size: 20px;
    font-weight: 300;
}
.cartToolTip::after {
	content: "";
    width: 0;
    height: 0px;
    border-left: 12px solid transparent;
    border-right: 12px solid transparent;
    border-top: 15px solid #dfca80;
    position: absolute;
    margin: 36px 38px 18px -54px;
}
.phoneCallTrackNumber a:hover{ text-decoration: none !important; }
</style>

<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
	
	.logoSizeModule {max-width:150px !important; max-height:90px !important;}



}
</style>
<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
.editWebsiteBtn{ display:none !important;}
}
</style>
<style>
.freeEstimateBtn a {
	width:318px;
}
.freeEstimateBtn a:hover {
	width:318px;
}
.container .header {
	width:100%;
	margin:auto;
}
.container .headerOne {
	overflow:hidden;
	display:table;
	max-width:980px;
	margin:auto;
	color:#333333;
}
.containerWithBg .header {
	width:100%;
	margin:auto;
}
.containerWithBg .headerOne {
	overflow:hidden;
	display:table;
	width:980px;
	margin:auto;
	color:#ffffff;
}
.mainMenu {
	margin:auto;
	margin-bottom:5px;
}
.menuBlock {
	padding-right:0px;	
}
.menuBlock ul li {
	width:0%;
}
.menuStyle1 {
	background-color:#f6f6f6;	
}
.menuStyle1 .mainMenu {
	clear:both;
	width:980px;
	margin:auto;
	overflow:hidden;
}
.menuStyle1 .menuBlock {
	float:left;
	width:675px;
	padding-right:0px;
}
.menuStyle1 .menuBlock ul {
	border:none;
	background:none;
	margin:0;
	padding:0;
	border-radius:0;
	display:table;
	width:100%;
	list-style:none;
}
.menuStyle1 .menuBlock ul li {
	display:table-cell;
	list-style:none;
	text-align:center;
	font-family:"Open Sans",sans-serif;	
	font-weight:normal;
		font-size: 13px;
				width:auto !important;
	}
.menuStyle1 .menuBlock ul li a {
	line-height:60px;
	padding:0px;
	background:#f8f8f8;
	color:#666;
	display:block;
	text-decoration:none;
}
.menuStyle1 .menuBlock ul li a:hover {
	color:#666;
	background:#ededed;
	text-decoration:none;
}
.menuStyle1 .menuBlock > ul li:hover a {
	color:#666;
	background:#ededed;
	text-decoration:none;
}

.menuStyle1 .menuBlock ul li ul {
	display:none;
	background:#ffffff;
	border:0px;
	position:absolute;
	z-index:9999;
	margin-top:-0px;
	margin-left:0px;
	padding:0px;
	/* border:1px solid #ffffff; */
	 width:280px;
	-webkit-border-radius: 0px;
	-moz-border-radius: 0px;
	border-radius: 0px;
}
.menuStyle1 .menuBlock ul li:hover ul {
	display:block;
}
.menuStyle1 .menuBlock li ul li {
	display:block;
	border-bottom: 1px solid rgba(0,0,0,0.2);
	border-right:0px;
	float:none;
	margin:0px;
	padding:0px;
	width:280px;
	line-height:20px;
	text-align:left;
	/*word-break: break-all;*/
	word-wrap: break-word;
}
.menuStyle1 .menuBlock li ul li:last-child {
	border-bottom:0px;
}
.menuStyle1 .menuBlock li ul li a {
	border:0px;
	color:#666;
	text-decoration:none;
	background:none !important;
	cursor:pointer;
	border-radius:0px;
	padding:8px 10px;
	line-height:normal;
	text-align:left;
	font-weight:normal;
}
.menuStyle1 .menuBlock li ul li a:hover {
	background:#ededed !important;
}


.menuStyle1 .freeEstimateBtn a {
	width:280px;
	font-family:"Open Sans",sans-serif;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.menuStyle1 .freeEstimateBtn a:hover {
	width:280px;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.topStickyBarLine { border-bottom: 0px;}

.hidedesk{display:none;}
.headerbackgroung { background-image: url(members/seobusinessboost/index/Optimized-digital-marketing-agency-Gulf-Shores-Alabama.1--2-.jpg); background-size: cover; background-position: center top; height:170px; }
.contentInnerBody{box-shadow: none; padding: 5px 0px; border: 0px;}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.headerbackgroung { height:140px; background-size: initial;}




}
.sample_popup-layout{z-index:100;}
.footerModule{width: 100%;}
@media only screen and (max-width : 639px),
only screen and (max-device-width : 639px){
	.topStickyBarLine {height: 55px;}
}
/* Layout5 Styles */
@media only screen and (max-width : 1180px),
only screen and (max-device-width : 1180px){
	.headerPaddLayout5{width:98%;}
	.topleftLay5, .topRightLay5{ width:50%;}
	
}

@media only screen and (max-width : 1000px),
only screen and (max-device-width : 1000px){
.hideheaderTxtLay5{ display:none !important;}
.headerPaddLayout5{padding:10px;}
.logoDivLayout5{width:190px;}
.topleftLay5{ width:auto;}
.topRightLay5{width:auto; margin-right:8px;}
.showMobLay5Ph{ display:block;}
.menuIcnColorLay5{ font-size:30px !important; margin: 0px 4px; padding: 2px 5px; border: 1px solid #ffffff; width: 44px; text-align: center;}
}
@media only screen and (max-width : 985px),
only screen and (max-device-width : 985px){
	.hidedesk{display:block;}
	.menuTxtlayout5{width: 80%;padding: 8px 0px;}
	.accordion-drop{width: 48px;padding: 18px 0px;}
}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.accordionMenuLayout5 ul li a{padding: 16px 0 10px 0; border-top: 1px solid rgba(255,255,255,.1);}
.logoimageTag{max-height:75px;}
}
@media only screen and (max-width : 359px),
only screen and (max-device-width : 359px){
.topRightLay5{margin-right:4px;}
}



 .menustickystyle{   }
 .menustylelogo{margin-top: 42px !important;}
 @media only screen and (max-width: 768px)
{.menustylelogo{ margin-top: 0px !important; }}
 

@media only screen and (max-width: 768px)
{
	.menuStyle1{ display: none !important; }
	
	


.sample_popup-layout{ top: -42px !important; }
</style>

<!--Top Sticky header start-->
<div class="topStickyBar" id="stickyshowhide" style="display:none;position:relative; z-index:1000;">
    <div class="topStickyBarLine bgcolorTheme">
        <div class="topStickyBarBtn"><a class="" href="form-sticky-header.php">Sticky Header</a> 
		 <a href="form-sticky-header.php" >
		<img src= "members/seobusinessboost/avatar/thumbs/thumbnail_1334808645.png" title="Promo Logo" alt="Promo Logo" border="0" height="35" /></a></div>
    </div>
</div>
<!--Top Sticky header end-->


<div class="headerbackgroung">
<div class="headerlayout5">
<div class="headerPaddLayout5">
	<div class="topleftLay5">
    <a href="index.php" title="SEO Business Boost"><div class="logoDivLayout5" style="position: relative; padding-right: 20px;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" style="max-width:100%;" border="0" class="logoimageTag" alt="SEO Business Boost" /><span class="tradeMarkIcon" style="right:0px; color:#ffffff;"></span></div></a>
	
	<a href="javascript:void(0);" style="text-decoration: none; margin:15px 15px 0px 0px; border: 1px solid #dfca80;display:none;float:right;" onclick="editwebsite();" class="editWebsiteBtn">
        <div style="color: #000000; padding: 10px 24px; font-size: 20px; font-weight: 300; background:#faecbe;">
          <span style="vertical-align:middle; display:inline-block; margin-top: -6px;">
          <img src="images/control-panel-icon-footer-black.svg" alt="Control Panel" border="0" width="23" height="23">
          </span>
          Edit Website
        </div>
    </a>
	
    </div>
    <div class="topRightLay5">
    	<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()" title="Menu" ></span>
		<a href="tel:2514245682" title="Call:2514245682" style="">
        <span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
		</a>
        <div class="shoponlineTxt hideheaderTxtLay5 phoneFloatRight">
				<a href="get-free-quote-9.php"   style="" >
		Get Free Quote</a>
				</div>	
    	<div class="layout5Phnum hideheaderTxtLay5" style="">
        	
            <div style="width:36px; overflow:hidden; float:left;">
            	<span class="icon-phone phoneIcnLayout5"></span> 
            </div>
            <div style="float:left; width:auto; padding:5px 0px 0px 3px;" class="phoneCallTrackNumber"><a href="javascript:void(0);">251-424-5682</a></div>
           
        </div>
    </div>
</div>
</div>
<!--mobile menu option left and right Icons-->
<div style="position: absolute; padding-top:10px; display:none;z-index: 9;width: 100%;" class="headerSecLayout5">
<div style="cursor:pointer; padding:2px; position:absolute; top:10px; left:3px; z-index: 1;">
<a href="tel:2514245682" title="Call:2514245682" style="text-decoration:none;">
<span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
</a>
</div>
<div class="logo" style="text-align:center; display:inherit; margin:auto;">
    <a href="index.php" title="SEO Business Boost" style="position: relative;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" alt="SEO Business Boost" class="logoSizeModule" border="0">
    <span class="tradeMarkIcon" style="color:#ffffff;"></span>
    </a>
</div>
<div  style="cursor:pointer; padding:2px; position:absolute; top:10px; right:3px;">
<a href="javascript:void();" onclick="showMenu();" style="text-decoration:none;">
<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()"></span>
</a></div>
</div>
<!-- end-->

</div>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <!-- Layout5 Menu  Starts here -->
<div id="accordionmenulayout5">
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="home-10.php"  ><span class="menuTxtlayout5">Home</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="about-us-8.php"  ><span class="menuTxtlayout5">About Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="email-us-your-request-9.php"  ><span class="menuTxtlayout5">Contact Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="website-builder-design-s1.php"  ><div class="menuTxtlayout5">Web Design</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="free-website-special-offer-s18.php"    >Free Website Special Offer</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="seo-management-company-s2.php"  ><div class="menuTxtlayout5">SEO Management</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="website-seo-company-s6.php"    >Website SEO Company</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="google-adwords-s3.php"  ><div class="menuTxtlayout5">Google Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="facebook-ads-s4.php"  ><div class="menuTxtlayout5">Facebook Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="youtube-ads-s5.php"  ><div class="menuTxtlayout5">YouTube Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="digital-marketing-services-s17.php"  ><div class="menuTxtlayout5">Digital Marketing</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5 hidedesk">
		<div class="accordion-toggle">
		<a href="marketing-blog-26.php"  title="Marketing Blog" ><span class="menuTxtlayout5">Marketing Blog</span></a>
		</div>
	</div>
</div>
<!-- Layout5 Menu  Ends here -->
<script type="text/javascript">
$(document).ready(function($) {
	$('#accordionmenulayout5').find('.accordion-drop').click(function(){
		var span=$(this).find('span');
		var othrspan=$(".accordion-drop > span").not(span);
		//Expand or collapse this panel
		$(this).parent().next().slideToggle('fast');
		//Hide the other panels
		$(".accordion-content").not($(this).parent().next()).slideUp('fast');
		$(".accordion-drop").not($(this)).attr("data-display","1");
		othrspan.removeClass('accordion-close');
		othrspan.addClass('accordion-open');
		othrspan.html('');
		var visible = $(this).attr("data-display");
		if(visible=='1'){
			span.removeClass('accordion-open');
			span.addClass('accordion-close');
			span.html('x');
			$(this).attr("data-display","0");
		}else{
			span.removeClass('accordion-close');
			span.addClass('accordion-open');
			span.html('');
			$(this).attr("data-display","1");
		}
	});	
});
</script>
</div>

<script>window.jQuery || document.write('<script src="js/zepto.js"><\/script>')</script>
<script src="jquery.waterfall.js"></script>
<script type="text/javascript">
function showMenu(){
	var showStatus=$('#menuList').attr('show-status');
	if(showStatus==0){
		$('#menuList').css('top','auto');
		$('#menuList').attr('show-status','1');
		$('#menuList').css('opacity','1');
		$("#menuIcn").attr('class', 'icon-close iconSizeDiv themeColor');
	} else if(showStatus==1){
		$('#menuList').css('top','-1000px');
		$('#menuList').css('opacity','0');
		$('#menuList').attr('show-status','0');
		$("#menuIcn").attr('class', 'icon-menu iconSizeDiv themeColor');
	}	
	// var src = $("#menuIcn").attr('class') == "menucloseIcnBg-menuOpt" ? "menuIcnBg-menuOpt" : "menucloseIcnBg-menuOpt";
	//  $("#menuIcn").attr('class', src);
	/* var src = $("#menuIcn").attr('src') == "images/close-icn-empty-thin.png" ? "images/menu-icn-empty-thin.png" : "images/close-icn-empty-thin.png";
	$("#menuIcn").attr('src', src); */
	
	return false;
		
}
function showSubMenu(id){ 
	if($('#subMenu_'+id).css('display') == 'none'){
		var body = document.body,
		html = document.documentElement;
		var height = Math.max( body.scrollHeight, body.offsetHeight,
		html.clientHeight, html.scrollHeight, html.offsetHeight );
		document.getElementById('subMenu_'+id).style.height=height+'px';
		$('#subMenu_'+id).show();
				$('html, body').animate({scrollTop:0}, 'slow');
	}else{
		$('#subMenu_'+id).hide();
	}
}
function stickyheadershowhidefun(){
var stickydeskStatus= '2';
var stickymobStatus = '1';
var stickyparentdiv= 'container';
if($(window).width() >= 960){
if(stickydeskStatus==2)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
}
else
{
if(stickymobStatus==1)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}

}
}
$(document).ready(function(){
stickyheadershowhidefun();
});
$(window).resize(function () {
stickyheadershowhidefun();
});

function editwebsite(){
	/* var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('controlPanel').style.height=height+'px';
	$('#controlPanel').focus(); */
	$('html, body').animate({
		scrollTop: $("#controlPanel").offset().top
	},1000);
	$("#controlPanel").focus();
	$("#cartToolTip").show();
}
var stickydeskStatus= '2';
var stickymobStatus = '1';
if(stickydeskStatus!=2 || stickymobStatus!=1 )
{
$(document).on( 'scroll', function(){
	if ($(window).scrollTop() > 2) {
		$("#stickyshowhide").css('position','fixed');
		if($(window).width() >= 960){
		//$(".headerbackgroung").css('margin-top','44px');
		}
	} else {	
				$("#stickyshowhide").css('position','relative');
			}
});
}
$(document).ready(function($) {closeNav();});

/* Set the width of the side navigation to 250px */
function openNav() {
   $("#mySidenav").css({'width':"320px",'overflow':''});$('body').css('overflow','hidden');
}
/* Set the width of the side navigation to 0 */
function closeNav() {
    {$("#mySidenav").css({'width':"0",'overflow':'hidden'});$('body').css('overflow','');}
}
</script>
<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<link rel="stylesheet" type="text/css" href="css/listcarousel-botbox-v1.css" />
    
    <div class="contentBody">
    
        <div class="contentHead">
            <div class="headingText">
                <h2 style="float:left;font-size: 26px;">Marketing Blog</h2>
                            </div>
            
            <div class="shareButtons">
                <!--Social Network buttons (Likes & shares etc...)-->
                                <!--Social Network buttons (Likes & shares etc...) End-->
            </div>
        </div>
    
        <div class="contentInnerBody"  style="position:relative;">
    		            
            <!-- Blog Block -->
            <div class="blogMainBody">
            	<div id="blogMainBlock">
                
                <ul>
    <li>
      <div>
      	
        <div class="contentPadd5"><h1 class="headingTextSmall BlogTitileNew" style="width:80%;display:inline-block;float:left;">Your Guide To The Best SEO Services In Gulf Shores, Alabama</h1>
		 <a href="javascript:void(0)" onclick="goBack()" class="defaultBtn" style="float:right; border-radius:0px;">Back</a>
		</div>
		       	       <div style="max-width:685px; text-align:center; background:#f4f4f4;">
   			    <img src="members/seobusinessboost/blog/seo-1.jpg" alt="Best SEO Services" style="" border="0" class="blogImgCls">
              </div>
               
         
        <div class="contentPadd5"><style>.points{padding-inline-start: 18px !important;}.points li{list-style:disc !important; padding:6px 0 !important}</style><div><ul class="points"><li><a href="#SEO">What is SEO?</a></li><li><a href="#SEO_Company">Grow Your Business with Our SEO Company</a></li><li><a href="#Local_SEO">Learn About How We do Local SEO for Your Business</a></li><li><a href="#Approaches">The Different Approaches to SEO</a></li><li><a href="#Benefits">5 Top Benefits of Expert SEO Services</a></li></ul></div><div><br><div></div></div><h2 style="margin: 0;" id="SEO">What is SEO?</h2><div>SEO is short for Search Engine Optimization. This involves increasing a website’s ranking on online search engine platforms and driving users to the website to increase web traffic and bring in results. <b>We have a great SEO team of experienced specialists who never fail to bring in results with their high end SEO</b>. Call us to today to have your SEO queries answered.</div><div><br></div><h2>SEO is all About Keywords and Keyword Optimization</h2><div><b>We know all about SEO and where and how to use keywords in your website’s content for great, maximum searchability</b>. We work to optimize your site on-page as well as through the back end of your site, and we are constantly at it so you stay on top on the search listings, keeping your competitors at bay.</div><div><br></div><h2>Is SEO Important for my Business?</h2><div>Yes, it absolutely is! Users are constantly searching for various things online and when they’re looking for products or services that your brand offers, it is important that they find you first. If you’re at the top of the search engine, your business identity is automatically boosted for the customer and your credibility increases.</div><div><br></div><h2>We Work with Strong Content Organization</h2><div>We organize content on your site logically, and make it readable and attractive to your customers. SEO content shouldn’t have to be boring and disorganized just because people may not see it. Content organization is great for <a href=" https://www.seobusinessboost.com/website-seo-company-s6.php">SEO and it also helps customers</a> who are on your site find other related content easily. The more attractive your content is, the more they’ll keep browsing. And the longer they’re browsing on your site, the better it is!</div><div><br></div><h2>We Create Great Content Promotion for Your Business</h2><div>We increase visibility to the content on your website by sharing it on social networks and ultimately building links to your content. We do this internally, as well as externally from other sites as well.</div><div><br></div><div>We create the right kind of SEO, fit for your brand</div><div><br></div><h2>What does SEO do for Me?</h2><div>SEO can give your business a big amount of visibility as well as credibility. The internet is constantly changing and evolving, and with that, there are always new businesses emerging that can offer the same products or services that your business offers. <b>SEO can maintain your website’s rankings online so you can always stay ahead of your competitors.</b></div><div><br></div><h2>Get the Most out of Search Engine Traffic</h2><div>While considering SEO, the main goal for most businesses is search engine traffic and just that. However, what most people don’t realize is that SEO aimed at just web traffic alone can make your site suffer. You will have to work your SEO for the search engines point of view because it is an investment that will work its way up on the rankings over time, and you will have to also work your SEO for customers by offering quality content on your website.</div><div><br></div><h2>Say ‘No’ to Weak, Low-Value Content</h2><div>We do not provide thin content just for the sake of search engine rankings, clicks, and web traffic. After all, what good is a website that ranks top of the search engines, <b>if visitors can find any useful information or content after they click and enter the site</b>? The website not only has to make a great first impression to the customer, it also has to provide valuable content. Websites that have low value content usually stand at risk for being penalized by Google. These sites would also have high bounce rates and low conversions.</div><div><br></div><div><div><img src="../members/seobusinessboost/blog/resize_1606737513.jpg" alt="best seo company for small business" style="" border="0" class="blogImgCls"></div></div><h2>What are Keywords?</h2><div>Keywords are short ideas, phrases, or topics that are centered around your content or themes in sync with your content. In SEO, the keywords are primarily what a user would enter into search engines when searching for your business or products and services similar to what your business offers. <a href=" https://www.seobusinessboost.com/about-us-8.php">Our team of experts create the best keywords</a> for your business or brand based on what is most relevant to you - in order to boost your website’s rankings with quality SEO.</div><div><br></div><h2>What's better - SEO or PPC?</h2><div>We believe that both SEO and PPC have its own share of benefits. SEO can give your business consistent results and maintain website rankings online, thereby increasing value of your business’s website. PPC, however, can give you some immediate results due to highly targeted ads that hit a specific audience within a short or fixed time period even when your website isn’t optimized for SEO.</div><div><br></div><div>Types of SEO content that we work with for your website:</div><div><br></div><h2>Product&nbsp; Pages</h2><div><b>Product pages are most important for retail and e-commerce websites.</b> A great product page can work as an SEO page, as well as a landing page organically or through paid advertising. Blog Posts</div><div>Blog posts are one of the easiest ways to create great SEO content that would usually rank based on relevance and topic. Many websites employ the technique of using blog posts to boost their web rankings and SEO. This is because blog posts are engaging and can attract readers based on relatability or topic trends, making it a great way to increase prominence on your site.</div><div><br></div><h2>Articles</h2><div>Articles written for SEO can include news articles such as breaking news or a trending topic which is hot on search engines at the moment, interviews of prominent people or debatable topics that people want to read about, or a feature piece. <b>Online newspapers and online magazines usually feature this type of content.</b></div><div><br></div><h2>Lists</h2><div>A list is essentially an article formatted as a list of sorts with content pieces following each item on the list. These articles are usually titled something like this, “10 Ways To Lose Weight”, or “25 Trends of 2020”, and the likes. These lists are used for SEO content as they are attractive and clickable, making it great for <a href="https://www.seobusinessboost.com/facebook-ads-s4.php">social media</a><a>.</a></div><div><br></div><h2>Guides</h2><div>A guide is a long piece of content that would usually be used to explain something. Think of it as a long, written tutorial of sorts. Some businesses post guides on their website or an incomplete version of it, leaving the user with an option to sign up to read the complete piece. While adding sign up forms can reduce the SEO power of the page, it is a great tool for generating leads from your website.</div><div><br></div><h2>Infographics</h2><div><b>Infographics are large-format images that have a lot of content and data along with icons and graphs inside of the image sometimes.</b> This is a great way to increase shares of the website link. Its important to remember that the page carrying the infographic must be optimized well, since majority of the content and text is on the image and not on the webpage itself.</div><div><br></div><h2>Slideshows</h2><div>Many websites use the slideshow format for their web content. This is done especially when pictures are also an equally important part of the content. <b>For example, an article talking about engagement ring designs will require images more than content so people can look at the pictures and understand the captions that explain each picture.</b> It would not make sense to have content explaining various engagement rings if one couldn’t see any images of them. With this piece of written content, the title of your article, the captions, and the image file names are important since that’s what the search engines will be “reading”, as opposed to the page content which your visitors will be reading.</div><div><br></div><div><img src="../members/seobusinessboost/blog/seo-3.jpg" alt="best online seo company" style="" border="0" class="blogImgCls"></div><div><h2 id="SEO_Company">Grow Your Business with Our SEO Company in Alabama</h2></div><a href="https://www.seobusinessboost.com/seo-management-company-s2.php" title="" target="">Search Engine Optimization</a> (SEO) has never been this active ever before. Since, more number of companies are taking their presence online, it is self-explanatory. Every company on the web is up for the race to dominate the SERPs (Search Engine Results Pages). As people are more aware of what they get themselves into, they research the brand before trusting them. How do they do it? By asking Google.&nbsp;<div><br><h2>Work Your Way into Google by Indexing Creatively</h2></div><div>If you think Google has got all the answers for you, you are probably mistaken. <b>Google consolidates the answers for user queries and presents the best results to the searcher</b>. This brings us to the next challenge. How Google ranks all those results amidst a tight competition?</div><div><br></div><h2>We are Experts at Crawling Through Google</h2><div>Like these, any first time visitor will have countless questions that require concrete answers. Get in touch with our SEO Company in Alabama to hear how we answer your doubts. SEO Business Boost is one such state-of-the-art SEO company in Alabama that provides comprehensive SEO solutions to its clients.</div><div><br></div><h2>SEO Gives You a Jump-Start for Your Unseen Business</h2><div>For years together now, your business may have operated in the offline space. Having built your network through offline connections and driving sales for your businesses would have worked for you. <b>As the digital age is progressing rapidly, simple tools like SEO for your unseen business website can bring a few more leads to your successful business</b>.</div><div><br></div><h2>Let Our Experts Work on Your SEO</h2><div>Our SEO company in Alabama houses the best industry experts who have seen the evolution of SEO to what it is today. By analyzing and determining the correct keywords for your site and optimizing the same for the web, our SEO company can enhance the visibility for your business.</div><div><br></div><h2>Make Your Content Speak with our SEO Company in Alabama</h2><div>You may have realized by now that <b>SEO is about optimizing sites for better rankings and visibility</b>. While that’s true in some ways, what you did not know is that SEO works effectively with the right content. If you think about it, people visit websites in search of answers in the form of relevant content. The format of content doesn’t matter.</div><div><br></div><h2>We take Quality SEO very Seriously</h2><div>What matters is the quality that comes with it. <a href="https://www.seobusinessboost.com/" title="" target="">SEO Business Boost</a> sets its obsessive focus on creating and marketing quality content that are results-oriented. By assessing the online behavior of customers, creating authentic content with us helps you gain the desired results.</div><div><br></div><div><img src="../members/seobusinessboost/blog/seo-4.jpg" alt="best seo marketing company" style="" border="0" class="blogImgCls"></div><h2>Fulfill Your Digital Marketing Needs with our SEO Company in Alabama</h2><div>We believe that being the jack of all trades is crucial to one specific domain. <b>Digital marketing is already on its way to become the next big thing is what we want to leverage at</b>. As more businesses are built daily, catering to the digital marketing needs of every one of them seems impossible.&nbsp;</div><div><br></div><h2>Only a Handful of Organizations are Successful in Digital Marketing</h2><div>This gives us the biggest reason to extend our help to small and medium scale businesses. Our services range from SEO, Google Ads, <a href="https://www.seobusinessboost.com/website-builder-design-s1.php" title="" target="">Website Building</a>, Facebook ads and much more. We claim ourselves to be the best in our services as our past customer experience speaks for us.</div><div><br></div><h2>Our SEO Company in Alabama Helps You Boost Your Local SEO</h2><div>The aim of using SEO for your site is to enhance the visibility and improve ranking for your site. At the same time, it is highly unlikely that every visitor to your site will become a conversion for your business. This is also dependent on the geography of the operating business.</div><div><br></div><h2>Improve Local Visibility Through SEO</h2><div>Businesses that have a location based ranking and visibility for what online users are looking for are the easy picks in search engine listings. <b>A buyer from Florida is going to be least bothered about any business listings in Arizona</b>. The only things that bother the buyer are convenience and accessibility.</div><div><br>Websites that focus on improving their <a href="https://www.seobusinessboost.com/upgrade-your-online-presence-with-expert-seo-tips-in-gulf-shores-b5.php" title="" target="">local visibility through Local SEO</a> can easily reach the top of SERPs. Our SEO experts in the company help you boost your Local SEO by updating your business profile with relevant internal linking and related.</div><div><br></div><h2>The Only SEO Company in Alabama with a Host of Digital Marketing Services</h2><div>Digital marketing is about the effective and strategic use of digital channels to market something to a target group. Since the Internet population is alarmingly growing, it is hard to imagine your online presence limited to a website or <a href="https://www.seobusinessboost.com/youtube-ads-s5.php" title="" target="">social media profile</a>. Digital marketing helps people to market their content with a structured approach in social channels aiding with the visibility and reach.</div><div><br></div><h2>All Tools are Essential to Grow with SEO</h2><div>Almost any digital marketing tools are extremely useful for the growth of small businesses. The prime motive of our SEO company in Alabama is to help you leverage the online competition with our resources at disposal.</div><div><br></div><h2>Expand Your Business Reach with SEO Business Boost</h2><div>It is no surprise that business owners still haven’t upgraded to the necessity of having an online presence. <b>Even the ones who have an online presence consider it the last resort for anything meaningful to happen</b>. It is agreeable that today’s digital arena is populated than ever before. It is still continuing to be on the rise. Since everything is scattered and unstructured, it's time that we make the best use of resources that are present forth to grow and expand your business.</div><div><br></div><div><img src="../members/seobusinessboost/blog/img-1--1-.jpg" alt="Local SEO" style="" border="0" class="blogImgCls"></div><h2 id="Local_SEO">Learn About How We do Local SEO for Your Business</h2><div>SEO is all about ranking organically in the web. Your website needs the eyes it deserves for keep your business running. How you do it is through understanding audience behavior and targeting them for the keywords they use. But rarely do we take <a href="https://moz.com/learn/seo/local" title="" target="">local SEO</a> into consideration. In fact, we even forget that local SEO is a significant lead generator for businesses.</div><div><br></div><div><b>Almost 50% of the searches happening in Google and other search engines are local</b>. How many times have you reached Google for a search that ended with “near me.” That is the potential of local SEO. Ranking and indexing sites that are available in the nearest location to help the customers with what they are looking for. So, it is hard to imagine the plight of your business if there is no local SEO in play.</div><div><br></div><h2>What is Local SEO and How Important is it?</h2>    <div>Local SEO is the process of making your site rank higher and make it visible among the local search results for your business. It differs slightly from normal SEO where in, you add a location element to your site.</div><div><br></div><div><b>Local SEO is helpful for business that are relying on local audience</b>. This particularly goes well with restaurants, boutique stores or any business where local accessibility is the deciding factor.</div><div><br></div><div>When a site has performed local SEO, it will rank in the Search Engine Results pages like a featured snippet where the top results will be shown.</div><div><br></div><div>These top results are more likely to have a click-through-rate than results that are ranked below.</div><div><br></div><h2>Our Holistic Approach Toward Local SEO for Your Business</h2><div>We understand the vitality of local SEO for growing business, particularly small businesses. Their success is a direct measure of how their local audience engage with them.</div><div><br></div><div><b>The following list contains the 5 ways we do local SEO for your businesses</b>. As experienced professionals, we have seen results by incorporating these five ways for our clients’ businesses.</div><div><br></div><div><img src="../members/seobusinessboost/blog/img-2--1-.jpg" alt="Search Engine Optimization" style="" border="0" class="blogImgCls"></div><h2>Get Website Optimization for Better Audience Engagement</h2><div>Your business will definitely have a website for convenience. But we know that most websites targeted at local audience lack the essentials in their website. In fact, one of the biggest reasons why business don’t get the traffic is because they miss the details. Most websites commit a mistake of cramming all their details in their home page. At the worst, those details will hardly be functional.</div><div><br></div><div>We have seen a host of clients who come with an underperforming website. We help them by creating a concise contact page with business address, contact info, and location information. At the same time, we optimize our clients’ websites for better functionality across mobile devices. The “on-the-go” culture is more prone to use mobile phones for local searches than laptops and desktops.</div>
<div><br></div><h2>Google My Business Listings Give Free Advertising for Your Business</h2><div>There’s a saying that goes something like “there’s no such thing as a free lunch.” Well, in the case of <a href="https://www.searchenginejournal.com/local-seo/optimize-google-my-business/" title="" target="">Google My Business listing</a>, you can beg to differ. Using your Google account, your business can get a free GMB profile listing for free.</div><div><br></div><div>GMB helps businesses create and manage their online presence by updating website and contact information and also enabling maps for the convenience of customers. As you also get a free spot in the Google Maps to locate your business, it counts as a form of free advertising citing that you exist.</div><div><br></div><h2>Create Content that Resonates with the Local Audience</h2><div>There has to be something that reels your audience towards your business. Let’s take an example. You own a unisex salon as your business. Having optimized your website and claiming your GMB listing isn’t going to be enough.</div><div><br></div><div>Do your customers know why they should come to a salon besides a normal haircut or a massage? Do they know the benefits of manicuring? Educating your customers through a blog or free resources can help your business gain the traction it needs eventually. Your customers will become more active if they are made aware of things they hardly knew in the form of content.</div><div><br></div><div><img src="../members/seobusinessboost/blog/img-3--1-.jpg" alt="Content Optimization" style="" border="0" class="blogImgCls"></div><h2>Leverage the Power of Online Reviews</h2><div>Today, as we are all tech-savvy, most of us know how to research a brand and make decisions based on that. If we look deeper what makes us decide better is the reviews that the brand gets. If you think about it, most of the reviews are first-hand experiences of users. Encouraging your users to review or rate your business is as important as giving the best customer experience.</div>
<div><br></div><div>There’s also another issue at hand to tackle with getting reviews - making your customers review your business. <b>We help our clients with creative techniques to make their customers leave reviews or give ratings about the brand through shareable links or point-of-purchase interactions</b>.</div><div><br></div><div><h2>Make Your Details Stand Out on Listings</h2></div><div>Many people know where to search for information regarding local attractions like events, restaurants, etc. <b>Google My Business, Yelp, Foursquare are a few to name</b>. These platforms give the concise information about a business to its customers. This information includes - contact details, location information, website address, operating timings, customer reviews, etc.</div><div><br></div><div>The catch to win in all these listings without being too promotional and boasting about the business. Your concise details should captivate your customer to do business with you.</div><div><br></div><div><h2>Contact us for SEO Services for Your Business</h2></div><div>While there are many other ways to do local SEO depending on geography and demographic trends, the above listed ways of doing local SEO is followed by many. At <a href="https://www.seobusinessboost.com/email-us-your-request-9.php" title="" target="">SEO Business Boost</a>, we help our clients reach their business goals by fortifying their local SEO needs. For more info on who we are and the services we provide, reach us at www.seobusinessboost.com</div><div><br></div><h2>Get the Best SEO Services in Gulf Shores</h2><div>Marketing has hugely turned sides in its time of course. It is only logical and practical to adopt digital marketing for your business now, as more than 59 percent of the world’s population is already on the Internet, looking for new information time to time. <b>One of the most undeniable digital marketing strategies to increase your ROI is Search Engine Optimization (SEO).</b> At SEO Business Boost, we offer the best SEO and Local SEO services to our clients, that we are known for our impeccable service among the gulf shores SEO agencies.</div><div><br></div><h2>SEO is a Real Game Changer for any Business</h2><div>We cannot stress enough on the fact that SEO is a real game-changer when it comes down to laying your business on the digital market. By the term Search Engine Optimization, it is clear that SEO means optimizing your web pages enough for the search engine to find our page quickly and display it on the SERP (Search Engine Result Page).&nbsp;</div><div><br></div><h2>Leave it to the Experts at SEO Business Boost</h2><div>As easy as it sounds, SEO actually takes a lot of work to achieve the result. SEO, in fact, is a slow and steady process which rather reflects on the result slowly. Before that, the process includes keyword research, content and links optimization that is included in the website. Because of this optimization, you set a strong foundation for your business on the digital market and you increase the chances of people being aware about your brand on a larger scale while they search for products or services that your business might be offering.</div><div><br></div><h2 id="Approaches">The Different Approaches to SEO</h2><div>On-page SEO is the strategy where all the optimization measures are taken within the website such as improving the content with relevance and clarity, designing user-friendly websites for mobiles and other devices, technical optimization like server speed etc. <b>Off-page SEO refers to the measures that can be taken outside of the website to increase the reach to the page.</b> This wholesome organic approach of SEO makes it easy for advertisers to increase their brand awareness within their budget as SEO is the form of unpaid digital marketing strategy in contrast to the PPC method of marketing.</div><div><br></div><div><img src="../members/seobusinessboost/blog/Services-in-Gulf-Shores.jpg" alt="SEO Services in Gulf Shores" style="" border="0" class="blogImgCls"></div><h2>Local SEO - A Strong Ally for Local Businesses</h2><div>Local SEO is a derivative under SEO which has the ability to support local businesses tremendously on the digital platform like no other. Competition is less when it comes to local business and when people search for it, by default, it is easy for your business to be displayed in the SERP but the real challenge is to channelize most of the crowd to your website and that is possible to be achieved through local SEO.</div><div><br></div><h2>Local SEO Helps in Increasing Your Website’s Visibility on the Internet</h2><div>Local SEO goes one step ahead and helps you to capture the local crowd by connecting with searchers in your area. Google, for one, provides a Snack Box result on the top of the SERP when people search for local businesses. The Snack Box consists of the top three local business websites related to the query. <b>It is estimated that 80 percent of browsers in the US are using Google to search for local businesses.</b> Local SEO focuses particularly on this opportunity and serves as a real boon for small and local businesses.</div><div><br></div><h2>Why do You Need a Third Party SEO Agency?</h2><div>As you can see now SEO is a complicated project to undertake for an entrepreneur who is also trying to focus on his main business. SEO is, after all, a long and tedious process that has to be done right to maximize the potential of it. You will need an expert team of SEO professionals who are specially cut out for this job to pull the work. An SEO agency will put consistent effort to maintain your site optimization for the search engine.&nbsp;</div><div><br></div><h2>Get the Best SEO for Your Business with Us!</h2><div>The Internet world is a space of constant change and the algorithms on which it works also changes likewise. <b>Hence to succeed in digital marketing, it is crucial to be aware of the new tricks and trades of the work with the change of algorithms.</b> An SEO agency can help you handle this challenge as they continuously keep up with the updated regulations of the platform and are capable of inventing new techniques to match the demands of the search engine.&nbsp;</div><div><br></div><h2>We are Built by a Team of Experts</h2><div>An SEO agency is far more experienced and skilled than an individual person when it comes to SEO optimization. While SEO is an unpaid marketing strategy, it requires a strong investment to load your page with high-quality content if you want your page to continue picking on revenue for a longer time.</div><div><br></div><h2>Our Gulf Shores SEO Services</h2><div>Our company at the Gulf shores SEO services, SEO Business Boost is a dedicated SEO agency housing the expert SEO professionals as our SEO team. We are accredited, trusted and five star recommended by many organizations like Google, Yelp, TrustPilot and so on. We are experienced and skilled after years of dealing with different customers from various different fields of work. We believe in a good clientele relationship for the on-going mutual success of the business and hence we follow a completely transparent approach with our clients.&nbsp;</div><div><br></div><h2>Why SEO Business Boost is the Perfect Agency for You</h2><div>We follow thorough testing of our methods to determine the success of our campaign and generate periodic reports to keep our customers updated about their campaign’s progress and success. By this, we are always aware of the things we should improve on and we correct our course in due time ensuring the success of the brand’s reach. <b>Our services are budget-friendly and trustworthy. Contact us today for any queries for the best gulf shores SEO service in the vicinity.</b> We would love to guide your business through SEO that gives long-lasting results!</div><div><br></div><div><img src="../members/seobusinessboost/blog/seo-5.jpg" alt="Best SEO Services In Gulf Shores, Alabama" style="" border="0" class="blogImgCls"></div><h2 id="Benefits">5 Top Benefits of Expert SEO Services</h2>Online companies are gaining a strong reputation and are becoming more well-known by the day. The truth is that almost every company today recognizes the value of creating a consistent online presence in terms of reaching over to a large number of future and existing customers. The very first step in building an online presence is to make a <a href="https://www.seobusinessboost.com/website-builder-design-s1.php" title="" target="">website</a> that is very well designed, has valuable content, and is very well optimized.&nbsp;<div><br></div><h2>Allow a Professional to Manage Your SEO</h2><div><b>Many people assume that SEO is a simple task that they can accomplish on their own. However, there are several other elements of SEO that could only be handled by a professional</b>. There are many companies that provide SEO services to their customers based on customer needs, such as SEO Business Boost, which offers the best SEO services in Gulf Shores.&nbsp;<div><div><br></div><h2>Getting Professional Assistance Based on SEO</h2><div>No matter how familiar a person is with the internet, SEO requires a number of resources and methods that the average person might not be aware of. He or she may not be able to correctly apply and implement SEO techniques in order to produce the best performance. This is when the services of an <a href="https://www.seobusinessboost.com/seo-management-company-s2.php" title="" target="">SEO company</a> are needed. The SEO experts have in-depth experience based on tried-and-true methods that must be applied in order to achieve excellent results. Here are 5 proven benefits of SEO.</div><div><br></div><h2>1. Stay on Top of the Competitive Industry with SEO Tactics</h2><div>The SEO industry is highly competitive, with formulas and ranking parameters constantly evolving. The algorithms of the major search engines change frequently, and your SEO strategy should be adjusted accordingly. The improvements would be well-known to a professional SEO consultant. That is where <a href="https://www.seobusinessboost.com/" title="" target="">SEO Business Boost</a>, which offers the best SEO services in Gulf Shores, comes into the scene.</div><div><br></div><h2>2. Your Website will Witness Great Traffic</h2><div>It's a wise decision to recruit a creative agency to look after the site's SEO requirements. <b>Your site would be placed among the top google search results rankings if you use sufficient SEO</b>. SEO aids in providing the site with the necessary publicity so that it would attract a broader amount of customers and establish itself as a product.&nbsp;</div><div><br></div><h2>3. Use the Best Marketing Strategies with Help from the Experts</h2><div>The platform will be able to target the most important hashtags, load quicker, and successfully compete with other competitors in the industry thanks to search engine optimization. Other marketing strategies can be reduced if the site's SEO is managed properly, and you'll need a specialist like SEO Business Boost, which provides the best SEO services in Gulf Shores.</div><div><br></div><h2>4. You Can Focus More on the Primary Business</h2><div>SEO consumes a lot of effort, commitment, and stamina. As a business person or woman, spending time on SEO jobs is not attractive because it interferes with other tasks. As previously mentioned, there are various tasks that must be performed in SEO, each of which necessitates a considerable amount of time and energy. Outsourcing this task to a reputable SEO firm would free up your time so you can concentrate on your main business.&nbsp;</div><div><br></div><h2>5. SEO Assists in Boosting Sales</h2><div>Websites are the sole source of income for online companies. <b>A very well-optimized website can help a company generate more revenue. With far more clients browsing the website and better keyword search, a successful trade can be achieved and more money gained</b>. Overall, SEO has been shown to increase business in every way possible, and with our digital marketing agency SEO Business Boost, which provides the best SEO services in Gulf Shores.</div><div><br></div><h2>Enlist the Support of an SEO Firm for Additional Services</h2><div>If you are fortunate enough to find the best SEO firm, consider yourself fortunate. This is because such a company would not only assist with SEO services but will also provide a wide variety of other services. Get the best agency that can provide high-quality <a href="https://www.seobusinessboost.com/email-us-your-request-9.php" title="" target="">SEO services</a> at the most affordable prices. Make an investment that counts in your business today with SEO Business Boost, which provides the best SEO services in Gulf Shores.<br></div></div></div></div>
		
         <div class="contentPadd5">
        	<img src="members/seobusinessboost/avatar/thumbs/1597517837.jpg" style="vertical-align: middle;float: left;margin-right: 5px; width:40px; height:40px;">
        	<div style="text-align:left; text-transform:capitalize; font-weight:normal; line-height: 1em;" class="themeColor">
               Jonathan         </div>
        	<div style="font-size: 14px; padding:5px 0px 0px 0px;">
            	<div class="blogPostedDate" style="display:none;"><span>Sep 30, 2020</span></div>
            	<div class="blogCommentsCount"><span>0 Comments</span></div>
            </div>  
			<div class="shareBtnsDiv">
		<a href="javascript:void(0);" onclick="shareTwitter()"><img src="/images/twitter-share-btn-flat.svg" alt="Share on Twitter" width="110" border="0" height="36"></a>
		<a href="javascript:void(0);" onclick="shareOnFB()"><img src="/images/fb-share-btn-flat.svg" alt="Share on Facebook" width="110" border="0" height="36"></a>
		</div>	
        </div>

		
      </div>
    </li> 
 
  </ul>
                
    
                <div class="blogCommentsBlock" style="margin: 0 10px;">
                <div class="deskHide" align="center" style="padding-bottom:5px;"><a href="#writeCommentMobi" class="formBtn responsiveBtn" style="border-radius:0px;">Write Comment</a></div>
                    <ul>
                    	                    </ul>
                </div>
   				
                </div>
                
                <div class="writeTestimonialsMobi" id="writeCommentMobi">
                <form action="" name="send_testimonial" method="post" onsubmit="return validateComment();">
                    <div class="blogCommentsBox">
                        <div class="headingTextSmall" style="margin-bottom: 15px;">Write a Comment</div>
                        <div class="blogComments-table-row">
                            <label class="blogComments-row-label">*Name :</label>
                            <div class="blogComments-row-text"><input type="text" name="name" id="name" class="form-shade-txt-fld" maxlength="50" value="" style="width:290px;"></div>
                        </div>
                        <div class="blogComments-table-row">
                            <label class="blogComments-row-label">*Email :</label>
                            <div class="blogComments-row-text"><input type="text" name="email" id="email" class="form-shade-txt-fld" maxlength="50" value="" style="width:290px;"></div>
                        </div>
                        <div class="blogComments-table-row">
                            <label class="blogComments-row-label">*Comment :</label>
                            <div class="blogComments-row-text"><textarea name="comments" id="comments" maxlength="1000" rows="4" class="form-shade-txt-fld" style="width:290px;"onKeyDown="textCounter('comments','remLen',1000);" onKeyUp="textCounter('comments','remLen',1000);" onPaste="textCounter('comments','remLen',1000);"></textarea><br>
	                      	<input type="hidden" name="remLen" id="remLen" value="1000"  />
                            <span class="hidePad">(Max 1000 characters - You have <span id="charLeft">1000</span> characters remaining)</span></div>
                        </div>
                        <div class="blogComments-table-row">
                            <label class="blogComments-row-label">*Security Code :</label>
                            <div class="blogComments-row-text"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                              <tbody>
                                <tr>
                                  <td width="1" valign="middle"><input type="text" name="security_code" id="security_code" value="" maxlength="5" style="width: 100px !important;"></td>
                                  <td width="90" align="center" valign="middle"><img src="captcha/image.php" alt="captcha" width="70" height="30" border="0" id="captcha"></td>
                                  <td valign="middle"><a href="JavaScript: new_captcha();"><img alt="Refresh" src="captcha/refresh.png" align="bottom" border="0" height="24" width="24"></a></td>
                                </tr>
                              </tbody>
                            </table>
                            </div>
                        </div>
                        
                        <div class="blogComments-table-row">
                        	<label class="blogComments-row-label"></label>
                            <div class="blogComments-row-text"><span style="padding:10px 0px;">
                            	<input type="hidden" name="article_id" id="article_id" value="1" />
                                <input type="hidden" name="uploadedImageName" id="uploadedImageName" value="" />
                                <input type="text" name="emailid" id="emailid" value="shift!&XYZ" />
                                <input type="text" name="spamRestrict1" class="spamRestrict1" value="44cf150470cedff1b21bbc70577b4ee0">
                                <input type="text" name="spamRestrict2" class="spamRestrict2" value="0ee4b77507cbb12b1ffdec074051fc44">
                                <input type="text" name="mywebsiteurl" class="mywebsiteurl" value="" />
                                <input type="submit" name="submit_comment" class="formBtn responsiveBtn" style="border-radius:0px;" value="Add Comment">  
                                <!--<span class="deskHide"><input type="button" name="close_wrt_cmt" id="closeWrtCmt" class="defaultBtn responsiveBtn" value="Close"></span>
-->                            </span></div>
                        </div>
                        
                    </div>
                </form>
                </div>
            
            	
            </div>
            <!-- End Blog Block -->
    
            <!-- Sidebar -->
            <div class="formSidebarRight" >
			<!--  Search bar -->
			<div>
				<div style="overflow:hidden; margin-bottom:10px;">
				<div class="themeColor" style="font-size:20px;">Search</div>
                <form name="search_article" method="post" onsubmit="return searchArticle(1);">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td>
                        <div class="blogsearchTXT" >
                        <input id="searchblogname1" onclick="this.style.border='0';" name="" type="text"  style="padding: 10px;border: 0px;width: 100%;font-size: 18px;box-sizing: border-box;height: 46px;" autocomplete="off" />
                        </div>
                    </td>
                    <td>
                    <button type="submit" class="formBtn"  style="padding:8px; border-radius:0px; cursor:pointer;"><img src="images/search-blog-icon.svg" height="32" width="32" border="0" /></button>
                    </td>
                  </tr>
                </table>
				</form>
				</div>
				<div class="srchSugDiv" id="srchSugDiv1" style="display:none; clear:both;">
					<ul id="srchSugLst1">
						<li id="srchSugLoad1" style="display:none; text-align:center;"><img src="/images/blogsearch-loading.gif"></li>
					</ul>
				</div>
				<div class="srchRecDiv" id="srchRecDiv1" style="display:none; clear:both;">
					<ul id="srchLst1">
						<li id="srchLoad1" style="display:none; text-align:center;"><img src="/images/blogsearch-loading.gif"></li>
					</ul>
				</div>
			</div>
			<!--  End Search bar -->
               
				
				
				<div id="floatDiv" style="width:250px;">
                <div class="themeColor" style="font-size:20px;">Recent Articles</div>			
                <div class="sideBarContent" style="border:none;padding:0px;">
                    <ul class="blogMenuSideBar" id="blogSideScroll">
                                         
                    <li><a href="expert-digital-marketing-strategies-and-benefits-b6.php">Expert Digital Marketing Strategies and Benefits					</a></li>
                     
                    <li><a href="upgrade-your-online-presence-with-expert-seo-tips-in-gulf-shores-b5.php">Upgrade Your Online Presence with Expert SEO Tips in Gulf Shores					</a></li>
                     
                    <li><a href="why-you-need-an-agency-to-build-your-website-b4.php">Why You Need An Agency To Build Your Website					</a></li>
                     
                    <li><a href="get-the-best-facebook-marketing-agency-in-alabama-b3.php">Get The Best Facebook Marketing Agency In Alabama					</a></li>
                     
                    <li><a href="the-incredible-power-of-google-adwords-for-your-business-b2.php">The Incredible Power Of Google AdWords For Your Business					</a></li>
                     
                    <li><a href="your-guide-to-the-best-seo-services-in-gulf-shores-alabama-b1.php">Your Guide To The Best SEO Services In Gulf Shores, Alabama					</a></li>
                                        </ul>
                </div>
              </div>
            </div>
            <!-- End Sidebar -->
    
        </div>
    </div>

<style>
@media only screen and (max-width: 768px) {
		.hideIndex{display:none !important;}
}
</style>
<input type="hidden" id="promotionaltoolText" value="">
<input type="hidden" id="promotionaltoolText1" value="">
<input type="hidden" id="promotionaltoolText2" value="">
<input type="hidden" id="promotionaltoolText3" value="MA==">
<input type="hidden" id="promotionaltoolText4" value="MA==">
<input type="hidden" id="promotionaltoolText5" value="MA==">

<!--Bottom Boxes start-->
<!-- Box Bottom Starts Here new div -->
<!-- Box Bottom Ends Here -->

<!-- Social Media -->
<!--End Social Media -->



<!--Footer start -->
<div class="footerModule" >
    <div class="footerBox" style="position:relative;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td class="footerMenuHeading" align="left" valign="middle">
        <span id="recordSitename"  >SEO Business Boost. SEO, PPC, Social Media and Website Design. </span> 
        
        </td>
        </tr>
        <tr>
        <td><table cellpadding="0" cellspacing="0" align="center" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="top">
          <ul class="footerMenuLinks">
              <li>			<a href="home-10.php"   >
			Home</a>
			</li>
            							<li><a href="website-builder-design-s1.php"   title="Web Design" >Web Design</a>
						</li>
																<li><a href="seo-management-company-s2.php"   title="SEO Management" >SEO Management</a>
						</li>
																<li><a href="google-adwords-s3.php"   title="Google Ads" >Google Ads</a>
						</li>
																<li><a href="facebook-ads-s4.php"   title="Facebook Ads" >Facebook Ads</a>
						</li>
																<li><a href="youtube-ads-s5.php"   title="YouTube Ads" >YouTube Ads</a>
						</li>
																<li><a href="digital-marketing-services-s17.php"   title="Digital Marketing" >Digital Marketing</a>
						</li>
																<li><a href="about-us-8.php"   title="About Us" >About Us</a>
						</li>
																<li><a href="email-us-your-request-9.php"   title="Contact Us" >Contact Us</a>
						</li>
																<li><a href="sitemap-18.php"   title="Sitemap" >Sitemap</a>
						</li>
																<li><a href="marketing-blog-26.php"   title="Marketing Blog" >Marketing Blog</a>
						</li>
																		
									
							

			        </ul>
        </td>
        
        
        <td class="footerPhoneNumber" id="footerphonetd" style="display:;" align="center" height="100" width="400">
        <table cellpadding="5" cellspacing="0" align="center" border="0">
        <tbody><tr>
        <td valign="middle"><img src="images/phone-icon-footer.png" height="50" width="50" alt="call"></td>
        <td valign="middle">251-424-5682</td>
        </tr>
        </tbody></table></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        <tr>
        <td class="footerTopLine">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="middle" width="55%" id="allrights_received" >
        <span id="rocID" >1545 Gulf Shores Parkway #146, Gulf Shores, AL 36542</span>
		 <br/>         <span id="AllRReserved" >Powered By <a href="https://www.cloudlgs.com/en/" target="_blank">www.CloudLGS.com</a></span></td>
        <td align="right" valign="top" width="45%">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="right">
				
		</td>
        <td align="right" valign="middle" width="25"  onClick="return sendmailfn()" id="controlPanel" style="cursor:pointer;"><a title="Control Panel" href="javascript:void(0)"><img src="images/control-panel-icon-footer.svg" alt="Control Panel" border="0"></a> <div class="cartToolTip" id="cartToolTip" style="display:none;">Click Here</div></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>
        
        </td>
        </tr>
        </tbody></table>
    </div>
</div>
<!--End Footer -->

<!-- Mobile Footer start-->
<div class="stickyFooterPad"></div><div class="footerModuleMobile" id="footerMenu" style="">
    <div>
        <div class="icn-mnu-stp-div">
            <div class="hme-strip-blk1 icnstrp-txt">
            <a href="home-10.php"><img src="images/hme-icn-v2.png" border="0" height="26" width="26" alt="Home"></a><br>
            <a href="home-10.php"   >Home</a>
            </div> 
              
            <div class="hme-strip-blk2 icnstrp-txt">
            <a href="about-us-8.php"><img src="images/abt-us-icn-v2.png" border="0" height="26" width="26" alt="About Us"></a><br>
            <a href="about-us-8.php"   >About Us</a>
            </div> 
             
             
            <div class="hme-strip-blk3 icnstrp-txt">
            <a href="email-us-your-request-9.php"><img src="images/cnt-us-icn-v2.png" border="0" height="26" width="26" alt="Contact Us"></a><br>
            <a href="email-us-your-request-9.php"   >Contact Us</a>
            </div> 
          			<div class="hme-strip-blk4 icnstrp-txt">
	<a href="directions.php"><img src="images/dirt-icn-v2.png" height="26" width="26" border="0" alt="Directions" /></a><br />
			<a href="directions.php">Directions</a>
			</div>  
			          </div>
    </div>

</div>
<!-- Mobile Footer end -->

<!--Login Pop Up Div Start-->
<div class="sample_popup-layout" id="logInDiv" style="display:none;" >
<div class="loginPopUpBlock">
<form  method="post" name="loginform" onSubmit="return validate_form(this);" >
<div class="loginTitleBlock" style="border-bottom:1px solid #ddd;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><div id="logintext">Login</div><div id="forgottext" style="display:none;">Forgot Login Details</div></td>
    <td align="right" valign="middle"><a href="javascript:void(0);" onclick="closeLog();"><img src="images/loginbox-close.png" alt="Close" width="31" height="31" border="0" /></a></td>
  </tr>
</table>
</div>
<div class="loginBodyBlock">
<div id="forgotloading" align="center" class="loginBoxHeadingTxt" style="font-size:12px;"></div>
<div id="loading" align="center"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="45" align="left" valign="middle">
    <div id="usernametr">
	<input name="password" class="loginTxtFldNew" id="username" value="Username" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="text" style="width:96%;">
    </div>
	<div id="forgotusernametr" style="display:none;">
    
    
    <div id="TabbedPanels1" class="TabbedPanels">
  <ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(1)" style="outline:0;" >User</li>
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(2)" style="outline:0;" >Admin</li>
  </ul>
  
  <div class="TabbedPanelsContentGroup" style="background-color: #ededed;">
  
    <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsusername" class="textBoxloginNew" id="lmsusername" value="Enter Your Registered Email" onfocus="if(this.value==this.defaultValue)this.value='';this.style.borderColor='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runPasswordScript(event)" style="width: 96%; " type="text">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
                
   <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsadminname" class="textBoxloginNew" id="lmsadminname" value="seo****@gmail.com    " onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" style="width: 96%;" type="text" disabled="disabled">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
  </div>
</div>   
	</div>
	</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="passwordtr">
		<div style="width:229px; float:left;">
		<input name="password" class="loginTxtFldNew" id="password" value="Password" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="password" style="width:217px;">
        </div>
        <div class="passwordDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <input type="checkbox" name="passwordChk" id="passwordChk" class="css-checkboxshowpass"/>
                <label for="passwordChk"  class="css-labelshowpass" style="float:left;">Show</label>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="captchatr" style="display:none;">
		<div style="width:185px; float:left;">
		<input type="text" name="login_captcha" id="login_captcha" class="loginTxtFldNew" value="Security Code" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" style="width:170px;">
		<input type="hidden" name="logincount" id="logincount" value="0" />
        </div>
        <div class="securityDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <img border="0" id="logincaptcha" src="captcha/image-login.php" alt="captcha" /></td>
			  <td width="50%" align="left" valign="middle"><a href="javaScript:new_logincaptcha();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr >
    <td align="left">
	<div id="checktr" style="font-size:12px; font-family:Arial, Helvetica, sans-serif;" ><input name="loginremembercheck[]" id="loginremembercheck" value="1" onclick="if(this.checked==true) this.value=1; else this.value=0;" class="css-checkboxrememberpass" checked="checked" type="checkbox">
     <label for="loginremembercheck" class="css-labelrememberpass" style="float:left;"></label><span style="padding: 5px 0px; display: block; float:left; font-family: 'Open Sans', sans-serif !important; font-size:14px; ">Remember me</span></div>	</td>
  </tr>
</table>
</div>
<div class="loginTitleBlock" style="border-top:1px solid #ddd;">
<div id="submitbtntr">
<input type="hidden" name="mid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="Submit" class="loginBoxBtnNew" value="Login" type="button" onclick="return logIn()"  style="cursor:pointer;"><input name="clickstatus" type="hidden" value="0" id="clickstatus"></td>
    <td align="right" valign="middle"><input name="forgotpass" id="forgotpass" class="loginBoxBtnNew" value="Need Help?" onclick="return showusertype();" style="cursor:pointer;" type="button"></td>
  </tr>
</table>
</div>
<div id="forgotsubmitbtntr" style="display:none;">
 <input type="hidden" name="forgotmid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="ForgotSubmit" class="loginBoxBtnNew" value="Submit" type="button" onClick="return LmsUserforgot();"  style="cursor:pointer;"> 
    <input type="hidden" value="1" id="hiddenactiveval"/>
    <input name="ForgotCancel" id="ForgotCancel" class="loginBoxBtnNew" value="Back" onClick="forgotCancel();" style="cursor:pointer;" type="button"></td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
</table>
</div>
</div>
</form>
</div>
</div>

<!--Login Pop Up Div End-->

<!--Dashboard options-->
<div id="dashboardPopup" class="sample_popup-layout" align="center"  style="display:none;"> 

<div class="newdashboardPopUp">
	<!-- Header Starts Here -->
    <div class="dashboardnew-row-1">
    	<table width="98%" border="0" cellspacing="0" cellpadding="5" align="center">
        <tbody>
            <tr>
            <td width="32%" align="left" valign="middle" class="dashboardhdngtxt"><span class="themeColor">Dashboard Options</span></td>
            <td width="60%" align="left" valign="middle"><a href="cms/logout.php?logout=1" >
			<img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out" />
			</a></td>
            <td width="21%" align="right" valign="middle"><a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
        <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
        </a></td>
          </tr>
        </tbody>
        </table>

    </div>
    <!-- Ends here -->
    
    <div class="dashboardnew-row-2">
    
    <div class="dashboardinnDivNew">
    	<div class="dashboardmndiv">
    <ul>
    	<li id="list1" ><a href="cms/" id="InsiteCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="cms">
             Manage your website content and images with inline edit feature             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/edit-website-flat.png" alt="Edit Website" width="110" height="96" border="0" /></div>
               <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Edit Website</span><br />
                    <span class="dashboardblksmllxt">Insite CMS</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list2"><a  href="admin/setting.php" id="displayCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="controlpanel">
              Web pages management, Images, SEO, E-Commerce and all other "Under the Hood" Settings
            </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/admin-panel-icon-flat.png" alt="Admin" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Admin</span><br />
                    <span class="dashboardblksmllxt">Website Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list3"><a  href="javascript:void(0);" onclick="submitAdminLoginForm();" id="adminControlPanelLink" style="  " >
        	<div class="icnblkdivmnovr" style="display:none;" id="lms">
             CloudLGS account settings like custom domain, payments and account renewals.
             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/control-panel-flat.png" alt="Control Panel" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Control Panel</span><br />
                    <span class="dashboardblksmllxt">Account Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
    </ul>
</div>
</div>
    
    
    </div>
    
    
    <div class="dashboardnew-row-3">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td height="40" align="right" valign="middle">
	      <div id="load_icon" align="center" style="display:none;"><img src="../images/loading.gif" alt="Loading...." /></div>
	      <a href="javascript:void(0);" class="buttonNewdash iconNewdash" id="see_more" onClick="openDashBoardMore();">See More Features</a>
      </td>
    </tr>
</table>
<input type="hidden" name="email" id="adminUserEmail" value="" />
<input type="hidden" name="user_pwd" id="adminUserPwd" value="" />
<input type="hidden" name="chg_pwd" id="adminUserChgPwd" value="" />
<input type="hidden" name="adminSessionId" id="adminSessionId" value="" />
    </div>
    
    
</div>
</div>
<!--Dashboard option block end-->


<!-- Dashboard More Features pop up -->
<div id="dashboardMorePopup" class="sample_popup-layout" align="center"  style="display:none;">  
<div style="margin:auto; max-width:768px;">
    <!-- Header Starts here -->
    <div class="headerPopDiv">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="94%" height="38" align="left" valign="middle" class="dashboardhdngtxt" style="font-size:22px; font-weight:normal;">
    <table border="0" cellspacing="0" cellpadding="2">
      <tr>
       <td align="left" valign="middle" class="themeColor">Dashboard Options</td>
        <td align="left" valign="middle">
        <a href="cms/logout.php?logout=1" >
        <img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out"/>
        </a>
    </td>
      </tr>
    </table>

    </td>
    <td width="6%" height="30" align="right" valign="middle">
    <a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
    <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
    </a>
    </td>
  </tr>
</table>
    </div>
    <!-- Header Ends here -->
    <!-- popupContentDiv -->
<div class="popContentDivFeatures">
<div class="featuerDivPopupICN" id="dashboard_options">
</div>  
</div>
<!-- popupContent Ends here -->

<!-- Footer Starts here -->
<div class="bottomDivPopUpfooter">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="355" height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td width="258" height="40" align="right" valign="middle">
      <a href="javascript:void(0);" class="buttonNewdash iconNewdashback" onClick="hideDashBoardMore();">Back</a>
      </td>
    </tr>
</table>
</div>
<!-- Footer Ends here -->
</div>
</div>
<!--Dashboard option block end-->
<!-- Social media script -->
<script src="/SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="/SpryAssets/SpryTabbedPanels2.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.screwdefaultbuttonsV2.min.js" ></script>
<script type="text/javascript">
$(function(){
	$('input:radio').screwDefaultButtons({
		image: 'url("images/radio-btn.png")',
		width: 26,
		height: 26
	});
});

function radiobtnactive(id){
	if(id==2){
		$("#hiddenactiveval").val('2');
	}	
	if(id==1){
		$("#hiddenactiveval").val('1');	}
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$('#list1').mouseenter(function() {
		$('#cms').fadeIn();
	});
	$('#list1').mouseleave(function() {
		$('#cms').fadeOut();
	});
	$('#list2').mouseenter(function() {
		$('#controlpanel').fadeIn();
	});
	$('#list2').mouseleave(function() {
		$('#controlpanel').fadeOut();
	});
	$('#list3').mouseenter(function() {
		$('#lms').fadeIn();
	});
	$('#list3').mouseleave(function() {
		$('#lms').fadeOut();
	});
});
function sendmailfn() 
{
$('body, html').animate({ scrollTop:0 }, 'slow');
$('body').css("margin-top","0px");
 var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );
document.getElementById('logInDiv').style.height=height+'px';
document.getElementById('logInDiv').style.display='block';
document.getElementById('clickstatus').value=1;
}

function closeLog(){
   document.getElementById('logInDiv').style.display='none';
   document.getElementById('loading').innerHTML='';
   document.getElementById('username').value="Username";
   document.getElementById('password').value="Password";
   forgotCancel();
}
function showusertype(){
	document.getElementById('usernametr').style.display='none';
	document.getElementById('forgottext').style.display='block';
	document.getElementById('logintext').style.display='none';  
	document.getElementById('passwordtr').style.display='none';
	document.getElementById('checktr').style.display='none';
	$('#captchatr').hide();
	
	document.getElementById('forgotusernametr').style.display='block';
	document.getElementById('submitbtntr').style.display='none';
	document.getElementById('forgotsubmitbtntr').style.display='block'; 
	document.getElementById('lmsusername').style.borderColor='';
}
function  forgotCancel(){
	document.getElementById('usernametr').style.display='block';
	document.getElementById('forgottext').style.display='none';
	document.getElementById('logintext').style.display='block';  
	document.getElementById('passwordtr').style.display='block';
	document.getElementById('checktr').style.display='block';
	if($('#logincount').val()==1){$('#captchatr').show();}
	document.getElementById('forgotusernametr').style.display='none';
	document.getElementById('submitbtntr').style.display='block';
	document.getElementById('forgotsubmitbtntr').style.display='none';
	document.getElementById('lmsusername').style.borderColor='';
}
					
function LmsUserforgot(){
	var username=$("#lmsusername").val();
	var activetab=$("#hiddenactiveval").val();
	if(activetab==1){
		sendUserMail();
	} else {
		sendAdminMail();
	}
}

function sendUserMail(){
	var username=$("#lmsusername").val();
	if(username!="" &&  username=="Enter Your Registered Email"){
		$("#lmsusername").css('border-color', '#CC0000'); return false;
	} else if(validateEmail(username)===false){
		$("#lmsusername").css('border-color', '#CC0000');
		var text="<span style='color:#CC0000'>Please enter valid email.</span>";
		$('#forgotloading').show();
		$('#forgotloading').html(text);
		setTimeout(function(){$('#forgotloading').hide();},4000);
		return false;
	} else {
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "../lms/forgotpasswordlmsuser.php",
			data: {username:username,source:'site'},
			cache: false,
			success: function(val){
				document.getElementById('loading').innerHTML='';
				if(val==1) {
					var text="<span style='color:green'>Details has been sent to mail successfully</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
						setTimeout(function(){$('#forgotloading').hide();},4000);
				} else {
					$("#lmsusername").css('border-color', '#CC0000');
					var text="<span style='color:#CC0000'>No user exists with this email.</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
					setTimeout(function(){$('#forgotloading').hide();},4000);
				}
				document.getElementById('lmsusername').value='Enter Your Registered Email';
			}
		});
	}
}

function sendAdminMail(){
	document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
	var username="admin";
	$.ajax({
	type: "POST",
	url: "../lms/forgotpasswordlmsuser.php",
	data: {username:username,source:'site'},
	cache: false,
	success: function(val){
		document.getElementById('loading').innerHTML='';
		if(val==1) {
			var text="<span style='color:green'>Details has been sent to mail successfully</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
			setTimeout(function(){$('#forgotloading').hide();},4000);
		} else {
			var text="<span style='color:#CC0000'>No user exists with this email.</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
		}
		document.getElementById('lmsusername').value='Enter Your Registered Email';
	}
	});	
}

function validateEmail(elementValue){        
    var emailPattern = /^[a-zA-Z0-9._]+[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,4}$/;  
    return emailPattern.test(elementValue);   
  }
  
function logIn(){
	var username= $('#username').val();
	var password = $('#password').val();
	var clickstatus=$('#clickstatus').val();
	var loginremembercheck = $('#loginremembercheck').val();
	var logincount=$('#logincount').val();
	var login_captcha=$('#login_captcha').val();
	var validLogForm=true;
	if(logincount==1){
		$('#captchatr').show();
		if(login_captcha==''||login_captcha=='Security Code'){
			$('#login_captcha').css('border-color','red');
			validLogForm=false;
		}else{
			$('#login_captcha').css('border-color','');
		}
	}else{
		$('#captchatr').hide();
		$('#login_captcha').css('border-color','');
	}
	if(username==''||username=='Username'){
		$('#username').css('border-color','red');
		validLogForm=false;
	}else{
		$('#username').css('border-color','');
	}
	if(password==''||password=='Password'){
		$('#password').css('border-color','red');
		validLogForm=false;
	}else{
		$('#password').css('border-color','');
	}
	if(clickstatus==1&&validLogForm==true){
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "login.php",
			data:{username:username,password:password,loginremembercheck:loginremembercheck,login_captcha:login_captcha},
			dataType: "json",
			cache: false,
			success: function(data){
				if(data.message==1){
					document.getElementById('logInDiv').style.display='none';
					document.getElementById('loading').innerHTML='';
					$('#controlPanel').attr('onclick','openDashboard();');
					$('#logInSessionReload').attr('onclick','dashboardPopupClose2();');
					if(data.admin=='Yes'){
						$('#adminUserEmail').val(data.adminUserEmail);
						$('#adminUserPwd').val(data.adminUserPwd);
						$('#adminUserChgPwd').val(data.adminUserChgPwd);
						$('#adminControlPanelLink').css('display','block');
						$('#adminSessionId').val(data.adminSessionId);
					} else {
						$('#adminControlPanelLink').css('display','none');
						$('#adminControlPanelLinkText').css('display','none');
					}
					if(data.editsite=='2'){
						$('#displayCmsLink').css('display','block');
					} else {
						$('#displayCmsLink').css('display','none');
						$('#displayCmsLinkText').css('display','none');
					}
					openDashboard();
				} else if(data.message==2){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Invalid username and password </div>";
					document.getElementById('loading').innerHTML=error;
					if(data.lgsattempt>5){$('#captchatr').show();$('#logincount').val(1);}
				} else if(data.message==3){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User has no permissions to Edit</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==4) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User account is suspended.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==5) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Not authorized from this system.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==6) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Please enter security code.</div>";
					document.getElementById('loading').innerHTML=error;
				}
			}
		});
	}
}

function runPasswordScript(e){
	if (e.keyCode == 13) {
        LmsUserforgot();
        return false;
    }
	return true;
}
function runScript(e) {
    if (e.keyCode == 13) {
        logIn();
        return false;
    }
	return true;
}

function openDashboard(){
$('body, html').animate({ scrollTop: 0 }, 'slow');
$('body').css("margin-top","0px");
var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );

document.getElementById('dashboardPopup').style.height=height-75+'px';
$('#dashboardPopup').show();
$("#cartToolTip").hide();
}
function dashboardPopupClose()
{
	$('#load_icon').hide();
	$('#see_more').show();
	$('#dashboardPopup').hide();
	$('#dashboardMorePopup').hide();	
}
function dashboardPopupClose2()
{
	$('#dashboardPopup').hide();
}
function openDashBoardMore() {
	$('#load_icon').show();
	$('#see_more').hide();

	var dataString = {id:1};
	$.ajax({
		type: "POST",
		url: "includes/dashboard-options.php",
		cache: false,
		data: dataString,
		success: function(val)
		{
			$('#dashboard_options').html(val);
			$('body, html').animate({ scrollTop: 0 }, 'slow');
			$('body').css("margin-top","0px");
			var body = document.body,
			html = document.documentElement;
			var height = Math.max( body.scrollHeight, body.offsetHeight,
			html.clientHeight, html.scrollHeight, html.offsetHeight );
			document.getElementById('dashboardMorePopup').style.height=height-75+'px';
			$('#dashboardPopup').hide();
			$('#dashboardMorePopup').show();
		}
	});
	
}
function hideDashBoardMore() {
	$('#load_icon').hide();
	$('#see_more').show();
	$('body').css("margin-top","0px");
	$('body, html').animate({ scrollTop: 0 }, 'slow');
	var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('dashboardPopup').style.height=height-75+'px';
	$('#dashboardPopup').show();
	$('#dashboardMorePopup').hide();
}
function submitAdminLoginForm(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function submitchangeurl(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site2.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function trailpayment(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site3.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function CancelAccount(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/sign-in-canceltest.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function new_logincaptcha(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('logincaptcha').src = '/captcha/image-login.php?x='+ c_miliseconds;
}
</script>
<!-- End Social media script -->
<style>
.loginpopinndiv{width:326px; margin:auto;}
.radioBtnLogin{font-family: "Lucida Sans Unicode","Lucida Grande",sans-serif; font-size:16px; color:#333333;}
.inncntBlkLoginDiv{background:#ffffff; padding:10px; }
.textBoxloginNew{border: 1px solid #D7D7D7; padding: 8px 5px; color: #666; font-size: 14px;}
.inncntBlkLoginDiv span{color:#666666; font-size:12px; font-family:Helvetica, Arial, sans-serif; padding:10px 5px; display:block;
background:#f5f5f5; margin:5px 0px 0px 0px;}

#AllRReserved a{
	text-decoration:underline;
}

.loginPopUpBlock {
	max-width:350px;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
	overflow:hidden;
	margin:auto;
	margin-top:60px;
	background-color:#FFF;
	-webkit-box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	-moz-box-shadow:    0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	box-shadow:         0px 0px 15px 0px rgba(0, 0, 0, 0.75);
}
.loginTitleBlock { background:#f7f7f7; padding:10px 25px; font-size:18px; font-weight:normal !important; overflow:hidden; }
.loginBodyBlock { padding:10px 16px; }
.loginBoxHeadingTxt {font-size:20px; color:#555555; }

input[type=checkbox].css-checkboxrememberpass { display:none; }
input[type=checkbox].css-checkboxrememberpass + label.css-labelrememberpass {
padding-left:40px; height:31px; display:inline-block; line-height:31px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }
input[type=checkbox].css-checkboxrememberpass:checked + label.css-labelrememberpass { background-position: 0% -31px; }
.css-labelrememberpass { background-image:url(../images/websetting-checkbox-flat.png);}

input[type=checkbox].css-checkboxshowpass { display:none; }

input[type=checkbox].css-checkboxshowpass + label.css-labelshowpass { padding-left:30px; height:25px; display:inline-block; line-height:25px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }

input[type=checkbox].css-checkboxshowpass:checked + label.css-labelshowpass {
background-position: 0% -25px;
}
.css-labelshowpass { background-image:url(../images/checkbox-shwpwd.png);}

.passwordDiv{background:#617284; height:33px; border:1px solid #4a5f72; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.securityDiv{ height:33px; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.member-top-inner {position: fixed; text-align: center; z-index: 99999999; width: 45px; height: 42px; line-height: 35px; right: 30px; bottom: 90px; padding-top: 2px; border-radius: 50%; transition: all 0.5s ease-in-out; background: url(../images/members-area-sticky-icon.png) #258fea no-repeat center !important; cursor:pointer;}

/* The hint to Hide and Show */

.hint { position: absolute; width: 133px; margin-top: 3px; margin-left:-162px;
border: 1px solid #edd5a6; padding: 0px 8px; color:#333; z-index:2; display:none;
background: #ffffda no-repeat -10px 5px; font-weight:normal; font-size: 12px;
font-family: Arial, Helvetica, sans-serif; border-radius:4px; }

/* The pointer image is hadded by using another span */
.hint-pointer { position: absolute; left: 149px; top: 9px; width: 8px;
height: 19px; background: url(cms/images/right-pointer.gif) right top no-repeat; }
.loginBoxBtnNew{font-family: 'Open Sans', sans-serif; font-size:14px !important; background-image:none !important;}

.newdashboardPopUp{margin:auto; max-width:650px; background:#ffffff; overflow:hidden; border-radius:10px;}
.dashboardnew-row-1{background:#ececec; overflow:hidden; padding:5px; font-size:20px; font-weight:normal;}
.dashboardnew-row-2{padding:15px; overflow:hidden; clear:both;}
.dashboardnew-row-3{background:#ececec; overflow:hidden; padding:15px; clear:both;}

@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.member-top-inner {right: 12px;bottom: 205px;  }
}

</style>

<link href='https://fonts.googleapis.com/css?family=Open+Sans|Pontano+Sans' rel='stylesheet' type='text/css'>


<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>

<script type="text/javascript">
var callFooterEfffects=function footerEffects()
{
if($(window).width() > 320){
    $("input:text").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:password").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("textarea").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:button").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );	
	$("input:submit").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:text").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("input:password").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("textarea").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
}
};
$(document).ready(callFooterEfffects);
$(window).resize(callFooterEfffects);

$(function(){
	$(document).on( 'scroll', function(){
		if ($(window).scrollTop() > 100) {
			$('.scroll-top-wrapper').addClass('show');
		} else {
			$('.scroll-top-wrapper').removeClass('show');
		}
	});
	$('.scroll-top-wrapper').on('click', scrollToTop);
});
	
function scrollToTop() {
	verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
	element = $('body');
	offset = element.offset();
	offsetTop = offset.top;
	if((/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i).test(navigator.userAgent || navigator.vendor || window.opera)==true){
		$('html, body').css('overflow-y', 'hidden');
		$('html, body').scrollTop(0);
		$('html, body').css('overflow-y', '');
		//$('html, body').animate({scrollTop: 0}, 500, 'linear');
	}else{
		$('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
	}
}
	
	$("#leftImage").hover(	
	function() {
	$("#leftImagetitle").show();
	}, function() {
	$("#leftImagetitle").hide();
	}
	);
	
	$("#rightImage").hover(	
	function() {
	$("#rightImagetitle").show();
	}, function() {
	$("#rightImagetitle").hide();
	}
	);
	
$( ".member-top-inner" ).click(function() {
 		window.location.href ="members-home.php";
 		//window.location.href ="members-home_id47_v1.php";

});
function fieldhint(id){
	document.getElementById(id+"_hint").style.display = "block";
}
function fieldhint1(id){
	document.getElementById(id+"_hint").style.display = "none";
}	
</script>
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-176053839-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-176053839-1');
</script>

<script type="text/javascript">
$(document).ready(function(){
$('input[name="passwordChk"]').click(function(){
if($(this).is(':checked')== true)
{document.getElementById("password").setAttribute('type', 'text');} 
if($(this).is(':checked')== false)
{document.getElementById("password").setAttribute('type', 'password');}
});
});
</script>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>




<script type="text/javascript" src="//cdn.calltrk.com/companies/566306024/0dc36fd4a782002e285c/12/swap.js"></script> 
<!-- Global site tag (gtag.js) - Google Ads: 600261187 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-600261187"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-600261187');
</script>
<!-- CANDDi https://www.canddi.com/privacy -->
<script async type="text/javascript" src="//cdns.canddi.com/p/44b13b5eeaf66ba606408a64c4ea8e14.js"></script>
<noscript style="display:none;visibility:hidden;"><img src='https://i.canddi.com/i.gif?A=44b13b5eeaf66ba606408a64c4ea8e14'/></noscript>
<!-- /END CANDDi -->
<!-- Clickcease.com tracking-->
<script type='text/javascript'>var script = document.createElement('script');
script.async = true; script.type = 'text/javascript';
var target = 'https://www.clickcease.com/monitor/stat.js';
script.src = target;var elem = document.head;elem.appendChild(script);
</script>
<noscript>
<a href='https://www.clickcease.com' rel='nofollow'><img src='https://monitor.clickcease.com/stats/stats.aspx' alt='ClickCease'/></a>
</noscript>
<!-- Clickcease.com tracking-->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '535512043295157'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=535512043295157&ev=PageView&noscript=1" alt="Facebook Pixel" /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
<script src="../js/jquery.exitintent.js"></script>
<script>
$(function() {
	var user=getCookie("exitintent_popup");
	if (user == "") {
		$.exitIntent('enable');
		$(document).bind('exitintent', function() {
			$("#ballonseffects").show();
		});
	}
	$(document).bind('exitintent', function() {
		var countbutton='';
		if(countbutton=="40506" || countbutton=="405" || countbutton=="506" || countbutton=="406"){
			setTimeout(function() {$("#ballonseffects").remove();}, 13500);
			setCookie("exitintent_popup","test", 1);
			return false;
		  }else{
			setTimeout(function() {$("#ballonseffects").remove();}, 9000);
			setCookie("exitintent_popup","test", 1);
			return false;
		}  
	});
});

function setCookie(cname,cvalue,exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays*60*5000));
	var expires = "expires=" + d.toGMTString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}



</script>
</div>
<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>
<!-- Live Chat Styles Starts Here -->
<style>
.chatCircle{width:58px; height:58px; border-radius:50%; position:fixed; cursor:pointer;z-index:99;top:75%}
.chatCircleIcon{width:58px; height:58px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.chatCircleMob{width:58px; height:58px; border-radius:50%; position:fixed; left:10px; bottom:90px; display:none; z-index:99;}

.chatCircle-v2{width:53px; height:53px; border-radius:50%;  position:fixed; bottom:88px; right:30px; z-index:99;cursor:pointer;}
.chatCircleIcon-v2{width:53px; height:53px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.arrow-downIcn {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #1c80d5;
margin: -5px 0px 0px 26px;cursor:pointer;}
.closeIcnChat{float:right; cursor:pointer; padding:7px; border-radius:50%;}

.liveChatMain { max-width: 390px; width: 100%; position: fixed; background: #ffffff; font-family: 'Open Sans', sans-serif; color: #000000;
font-size: 20px; font-weight: normal; -webkit-border-radius: 4px; -moz-border-radius: 4px;}
.livechatMainRight{right: 53px;bottom: 158px;}
.livechatMainLeft{left: 89px; bottom: 40px;}

.liveChatInn{padding:18px;position:relative;}
.liveChatbox{background:#ececec; font-family:'Open Sans', sans-serif; color:#333; font-size:18px; font-weight:normal; border-radius:4px; 
-webkit-border-radius:4px; -moz-border-radius:4px; text-align:left; border:0; resize:none; padding: 10px; width: 100%; margin:10px auto; 
border: 1px solid #ECECEC; box-sizing: border-box;}
.nextBtn{font-family:'Open Sans', sans-serif; color:#fff; font-size:16px; font-weight:normal; text-align:left; border:0; 
padding: 6px 22px; width: 100%; cursor:pointer;}
.arrow-down {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #ffffff; position:absolute;right:15px;}
.successTxt{font-family:'Open Sans', sans-serif; color:#1E99EE; font-size:24px; font-weight:normal;background:#fff;
text-align:center;clear: both;border-radius: 4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;padding:15px 0px;
margin: 10% auto 10% auto;width: 320px;}
.arrow-left {width: 0; height: 0; border-left: 10px solid transparent; border-right: 11px solid transparent;
border-top: 54px solid #ffffff; -moz-transform: rotate(45deg); -webkit-transform: rotate(45deg); -o-transform: rotate(45deg);
-ms-transform: rotate(45deg); margin: 21px 0px 0px 0px; right: 389px !important; z-index: 9 !important; position:absolute !important;}
.leftShadow{-webkit-box-shadow: -5px -1px 44px 0px rgba(129, 129, 129, 0.5);}

@media only screen and (max-width:767px),
only screen and (max-device-width:767px){
.chatCircle-v2{bottom:130px;right:12px;}

.livechatMainRight, .livechatMainLeft{right: 0px; bottom: 150px; left:0px;}
.liveChatMain { width:98%; margin:auto;}
.arrow-down, .arrow-left{ display:none;}
.successTxt{padding:15px 0px; width:100%;}
}
@media only screen and (max-width:760px),
only screen and (max-device-width:760px){
	.nextBtn{padding:10px 22px !important;}
}
</style>
<!-- Ends here -->
<!-- Social Media Icons -->
 <div style="top:80%; ">
 <div class="chatCircle bgcolorTheme" id="desktop_left" onClick="livechatpopup(1);" style="display:none;cursor:pointer">	
		<div class="chatCircleIcon" ><img src="images/chat-icn-v1.svg"  height="32" width="32" border="0" alt="Live Chat" /></div>
 </div>
</div>
<!-- Ends here -->
<!-- Live Chat Icon Mobile Option v1 -->
<div class="chatCircleMob bgcolorTheme" id="mobile_left"  onClick="livechatpopup(1);" style="display:none;">	
	<div class="chatCircleIcon"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
</div>
<!-- Ends here -->

<!-- Live Chat Icon Option 2 -->
<div class="chatCircle-v2 bgcolorTheme" id="desk_mob_right"  onClick="livechatpopup(1);" style="display:none;cursor:pointer">
	<div class="chatCircleIcon-v2"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
    
</div>
<!-- Ends here -->

<!-- Live Chat Pop Up Starts Here -->
<div class="liveChatMain livechatMainRight" id="livemsg" style="z-index:9999999;display:none;"  role="" >
		<div class="arrow-left" style="display:none;" ></div>
		<div class="liveChatInn" id="livechatdiv" style="display:;  box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -moz-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -webkit-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); display: block;">
			<div class="liveChathead" id="messageme">
				<span>Chat with us now</span>
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(2)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
                </span>
				<textarea name="chatmessage" id="chatmessage" class="liveChatbox" placeholder="Send us a message for a fast response" rows="3" onfocus="this.style.border='';" maxlength="1000" ></textarea>	
				<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" onclick="return livechat_next(1);"  name="next" id="next" value="Next" /></div>
				</div>
			</div>
			<div class="liveChathead" id="liveemail" style="display:none;">
			<span style="display:">Additional details</span> 
			<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(3)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
            </span>
				<input type="text" name="chatemail" id="chatemail" class="liveChatbox" placeholder="Your email address" onfocus="this.style.border='';" style="margin-bottom:5%;" maxlength="80"/>
				<div style="overflow: hidden;margin-bottom: 8%;">
					<div style="float:right;">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="left" valign="middle"><img border="0" id="security_code_capcha" src="captcha/image-livechat.php" alt="captcha" /></td>
							<td align="left" valign="middle"><a href="JavaScript: new_captcha_live();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a></td>
						</tr>
					</table>
					</div>
					<div  style="float:left;width:62%">
					<input name="security_code_lc"  maxlength="5" type="text" id="security_code_lc"  value=""  placeholder="Security Code"class="textboxlogin" onFocus="document.getElementById('security_code_lc').style.borderColor=''" style="background: #ececec; font-family: 'Open Sans', sans-serif; color: #333; font-size: 14.5px; font-weight: normal;width:100%" />	
					</div>					
				</div>
				<div style="display: none;color:red;font-size: 14px;text-align: center;" id="live_secure_issue">Invalid Security Code</div>
				
				
				<div style="font-size:12px;float:left;display:;cursor:pointer;"><a href="javascript:livechat_next(2);" style="text-decoration:none;color:#4B4C4E;"><img src="/images/left-arrow-new.png" style="vertical-align:middle;" border="0" height="15" width="18" alt="Live Chat Back"> <span> Edit message</span></a></div>
			<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" name="savechat" id="savechat" value="Submit" onclick="return submit_livechat();"/>
				<input type="hidden" name="verifyHuman_livechat" id="verifyHuman_livechat" value="shift!&XYZ" />
				<input type="hidden" name="spamRestrict1_livechat" id="spamRestrict1_livechat" value="b3c4eaf3aef3fdcc8861ee54d8539d39" />
				<input type="hidden" name="spamRestrict2_livechat" id="spamRestrict2_livechat" value="93d9358d45ee1688ccdf3fea3fae4c3b" />
				<input type="hidden" name="spamRestrict3_livechat" id="spamRestrict3_livechat" value="" />
				</div>
			</div>
			</div>
			
	<div style="display:none;" id="livethankyou">
		<div class="liveChatInn" style="background:#ededed;">
			<div class="liveChathead">
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(4)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" alt="Live Chat Close" /></a>
                </span>
			</div>
			<div class="successTxt"><span>Message sent successfully.</span><br><span style="font-size:18px;color:#000000;">We'll be in touch.</span></div>
		</div>
	</div>
	</div>
<div class="arrow-down" id="arrow" style=""></div>    
</div>
<!-- Ends here -->
<script type="text/javascript">
//////live chat popup ///////////
function livechatpopup(val){
	if(val==1){
	$("#livemsg").toggle();
	}else{
		$("#livemsg").hide();
	}
}
function livechatpopupclose(){
	$("#livemsg").hide();
}

function livechat_next(id){
	if(id==1) {
		var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
		if(chatmessage==""){
			$('#chatmessage').css('border','1px solid #cc0000');
			return false;
		} else {
			$('#messageme').hide();
			$('#liveemail').show();
		}
	}
	if(id==2) {
		$('#messageme').show();
		$('#liveemail').hide();
	}
} 
function submit_livechat(){
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
	var chatemail = $('#chatemail').val().replace(/^\s+|\s+$/g,'');
	var security_code_lc=$('#security_code_lc').val().replace(/ /g,'');
	var source="Chat Box";
	if(chatemail=="" || reg.test(chatemail)==false || security_code_lc==''||security_code_lc=='Security Code'){
		if(chatemail=="" || reg.test(chatemail)==false){$('#chatemail').css('border','1px solid #cc0000')};
		if( security_code_lc==''||security_code_lc=='Security Code'){$('#security_code_lc').css('border','1px solid #cc0000')};
		return false;
	} else {
		$("#verifyHuman_livechat").val("shift$%123");
		
		var verifyHuman=document.getElementById("verifyHuman_livechat").value;
		var spamRestrict1=document.getElementById("spamRestrict1_livechat").value;
		var spamRestrict2=document.getElementById("spamRestrict2_livechat").value;
		var spamRestrict3=document.getElementById("spamRestrict3_livechat").value;
		
		$.ajax({
			type: "POST",
			url: "livechat-submit.php",
			data:{chatmessage:chatmessage,chatemail:chatemail,source:source,verifyHuman:verifyHuman,spamRestrict1:spamRestrict1,spamRestrict2:spamRestrict2,spamRestrict3:spamRestrict3,security_code_lc:security_code_lc},
			cache: false,
			success: function(html) {
				if(html==1){
                    $('#liveemail').hide();
					$('#livethankyou').show();
				}else{
					$('#live_secure_issue').show();
					setTimeout(function(){ $('#live_secure_issue').hide(); }, 3000);
				}
			}
			
		});
	}	
}
function new_captcha_live(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('security_code_capcha').src = 'captcha/image-livechat.php?x='+ c_miliseconds;
}
</script><script type="text/javascript">
function fixDiv(){
	var $cache = $('#floatDiv');
	var scrollTopVal=$(window).scrollTop();
	var scrollValDiff=$(document).height() -(scrollTopVal+$(window).height());
	if (scrollTopVal>256&&scrollValDiff>730){
		$cache.css({'position': 'fixed', 'top': '50px', 'bottom': ''});
	}else{
		if(scrollTopVal>256&&scrollValDiff<730){
			var scrollValBott=(730-scrollValDiff)+'px';
			$cache.css({'position': 'fixed', 'bottom': scrollValBott, 'top': ''});
		}else{
			$cache.css({'position': 'absolute', 'top': 'auto', 'bottom': ''});
		}
	}
}
// $(window).scroll(fixDiv);
// fixDiv();

$(document).ready(function(){
	$('#writeCmnt').click(function(){
		$("html, body").animate({ scrollTop: $(document).height()-($(window).height()+290) });
	}); 
	$("#charLeft").html(1000-$("#comments").val().length);
	/*$('#writeCmnt').click(function(){
		$('#writeCommentMobi').show();
		$("html, body").animate({ scrollTop: $(document).height()-($(window).height()+290) });
	}); 
	$('#closeWrtCmt').click(function(){
		$('#writeCommentMobi').hide();
	}); */
	$("#blogSideScroll").niceScroll();
	var currentRequest = null;
    $("#searchblogname1").keyup(function(){
	var str=$.trim($(this).val());
	    if(str != ''){
		    $('#srchSugDiv1').show();
			$('#srchSugLoad1').show();
		    var dataString='wrd='+str;
		    currentRequest = $.ajax({
			    url:'get_article_suggestions_ajax.php',
			    type: 'POST',
			    data: dataString,
			    cache: false,
				beforeSend : function()    {           
                    if(currentRequest != null) {
                    currentRequest.abort();
					$('#srchSugLst1').html(" <li style='text-align:center;'><img src='images/ajax-loader.gif'></li> ");
                    }
                },
			    success: function(data){
				$('#srchSugLst1').html(data);
				$('#srchSugLoad1').hide();
			    }
		    });
	    }else{	
	    $('#srchSugDiv1').hide();  
	    }
    });
}); 
</script>
<script type="text/javascript">
function new_captcha(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('captcha').src = 'captcha/image.php?x='+ c_miliseconds;
}
function textCounter(field,cntfield,maxlimit) {
	if ($("#"+field).val().length > 999){ // if too long...trim it!
		$("#"+field).val($("#"+field).val().substring(0, maxlimit));
		// otherwise, update 'characters left' counter
	}else{
		$("#"+cntfield).val(maxlimit - $("#"+field).val().length);
		$("#charLeft").html($("#"+cntfield).val());
	}
}
function validateComment() {
	var name=$("#name").val();
	var email=$("#email").val();
	var comments = $("#comments").val();
	var security_code = $("#security_code").val(); 
	var emailRegEx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

	if(name==""||email==""||!email.match(emailRegEx)||comments==""||security_code==""){
		if(name==""){
			$("#name").css('border-color','#E2230E'); 		
		}else{
			$("#name").css('border-color','#D7D7D7'); 
		}
		if(email==""){
			$("#email").css('border-color','#E2230E'); 		
		}else{
			$("#email").css('border-color','#D7D7D7'); 
		}
		if(!email.match(emailRegEx)){
			$("#email").css('border-color','#E2230E'); 		
		}else{
			$("#email").css('border-color','#D7D7D7'); 
		}
		if(comments==""){
			$("#comments").css('border-color','#E2230E');
			$("#comments").css('border-width','thin');		
		}else{
			$("#comments").css('border-color','#D7D7D7'); 
		}
		if(security_code==""){
			$("#security_code").css('border-color','#E2230E'); 		
		}else{
			$("#security_code").css('border-color','#D7D7D7'); 
		}
		return false;
	}else{
		$("#emailid").val('shift$%123');
		return true; 
	}
}
function childWindowUnloadNotificationBlog(imageId, imageName){
	if(imageId==0){
		$("#uploadedImage").html('');	
		$("#uploadedImage").html('<div class="eventcouponimgbrd" style="background:#ffffff; display:table-cell; vertical-align:middle; text-align:center;"><img src="members/seobusinessboost/blog/'+imageName+'" style="max-width:56px; max-height:56px; " /></div>');
		$("#uploadedImageDiv").show();
		$("#uploadedImageName").val(imageName);
	}else{
		window.location.href='marketing-blog-b1.php?success=Image Updated Successfully.';
	}
}


function searchArticle(num){
	var srchWrd=$.trim($('#searchblogname'+num).val());
	$('#srchSugDiv'+num).hide();
	if(srchWrd != ''){
		$('#srchLoad'+num).show();
		$('#srchRecDiv'+num).show();
		var dataString='wrd='+srchWrd;
		$.ajax({
			url:'get_article_search.php',
			type: 'POST',
			data: dataString,
			cache: false,
			success: function(html){
				$('#srchLst'+num+' li').not('#srchLoad'+num).remove();
				$('#srchLst'+num).append(html);
				$('#srchLoad'+num).hide();
				$("#blogSideScroll").getNiceScroll().resize();
			}
		});
	}else{
		$('#searchblogname'+num).css('border', '1px solid red');
	}
	return false;
}
function newFunction(liobj){
	var newtitle=$(liobj).text();
	$('#searchblogname1').val(newtitle);
	searchArticle(1);
}
</script>
<style>
.blogMenuSideBar li a {padding:8px 0px; font-size: 14px;}
.blogMenuSideBar li a:hover {background:none;color:#222;}
</style>
</body>
</html>