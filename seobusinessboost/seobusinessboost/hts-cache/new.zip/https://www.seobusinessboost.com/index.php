<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="As the best online SEO company, we will give you a plan before diving into SEO work. Our team will also make it easier for your potential customers to avail your services or products. In no time, they will enter the sales funnel, then cha-ching! More sales for your business!." />
<meta name="keywords" content="affordable search engine optimization, best online seo company, best seo company for small business, best seo marketing company, ppc management services, facebook advertising agency" />
<meta name="google-site-verification" content="SpCwAKcxr_T66jV2_ynjIuM6AKYxd0KAaYMtLfm2G0Q" />
 
 
 
 
 
<meta name="msvalidate.01" content="E994A4F881698DACB2EFBB13D4FA7D3B" />
<title>Best Online SEO Company | SEO Business Boost</title>
<meta property="og:title" content="Best Online SEO Company | SEO Business Boost" />
<meta property="og:type" content="Website" />
<meta property="og:url" content="https://www.seobusinessboost.com" />
<meta property="og:image" content="https://www.seobusinessboost.com/change_image_size.php?file=members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" />
<meta property="og:site_name" content="https://www.seobusinessboost.com" />
<meta name="robots" content="INDEX,FOLLOW"/>

<link href="css/main-layout3-new.css" rel="stylesheet" type="text/css" />
<!--<link href="css/main-layout5.0.1.min.css" rel="stylesheet" type="text/css" />
<link href="css/layout5-header.0.1.min.css" rel="stylesheet" type="text/css" />-->
<link href="css/main-theme-1.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/listcarousel-botbox-v1.css" />

<script src="js/jquery-1.8.2.min.js"></script>

<!--[if IE]><link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" /><![endif]-->
<link rel="shortcut icon" href="members/seobusinessboost/favicon/favicon.ico" type="image/x-icon" />
<link rel="canonical" href="https://www.seobusinessboost.com" />
<!-- Animation Effect -->
<link rel="stylesheet" type="text/css" href="visualize.css" />
<!-- Animation Effect ends here -->
<style type="text/css">
.balloononload1{color: #fff;text-align: right;font-size: 58px;cursor: pointer;position: absolute;right: 60px;top: 30px;font-weight: 300;z-index:999;}
.bodyhidden{overflow-x:hidden}
.hideIndex{display:none;}
.socialMediaIcon{width:58px; position:fixed; z-index:15; top:20%; left:0px;}
.socialMediaIcon ul{ margin:0px; padding:0px; list-style:0px;}
.socialMediaIcon ul li{ margin:0px; padding:0px 0px; list-style:0px; cursor:pointer;}
.mobTopMediaIcons{ background:#ffffff; padding:10px 0px; overflow:hidden; clear:both; text-align:center; display:none;}
.mobTopMediaIcons img{ margin:0px 3px; width:54px;}
.sendEmailWidth520{width:540px !important; padding:0px !important;}
.padd20Email{ padding:4%;}
@media only screen and (max-width: 767px) {
.socialMediaIcon{display:none !important;}
.mobTopMediaIcons{display:block !important;}
.mobTopMediaIcons1{display:none !important;}
.sendEmailWidth520{width:98% !important; padding:0px !important; margin:3% auto !important;}
.padd20Email{ padding:2%;}
.balloononload1{right: 12px;top: 12px;}
}
@media only screen and (max-width: 359px) {
.mobTopMediaIcons img{width:48px;}
}
.sample_popup-layout{z-index:1001 !important;}
</style>
<style type="text/css">
	html, body {
		height:100%;
		padding:0px;
		margin:0px;
	}

	.skrollr-desktop body {
		height:100% !important;
	}
	.skrollr-mobile body {
		height:100% !important;
	}

	.parallax-image-wrapper {
		position:fixed;
		left:0;
		width:100%;
		overflow:hidden;
	}

	.parallax-image-wrapper-50 {
		height:50%;
		top:-50%;
	}

	.parallax-image-wrapper-100 {
		height:100%;
		top:-100%;
	}

	.parallax-image {
		display:none;
		position:absolute;
		bottom:0;
		left:0;
		width:100%;
		background-repeat:no-repeat;
		background-position:center;
		background-size:cover;
	}

	.parallax-image-50 {
		height:200%;
		top:-50%;
	}

	.parallax-image-100 {
		height:100%;
		top:0;
	}

	.parallax-image.skrollable-between {
		display:block;
	}

	.no-skrollr .parallax-image-wrapper {
		display:none !important;
	}

	.gap {
		background:transparent center no-repeat;
		background-size:cover;
	}
	
	#skrollr-body {
		height:100%;
		overflow:visible;
		position:relative;
	}
	
	.skrollr .gap {
		background:transparent !important;
	}
	



	.gap-50 {
		height:50%;
	}

	.gap-100 {
		height:100%;
	}

	.content {
		background:#fff;
		-webkit-box-sizing:border-box;
		-moz-box-sizing:border-box;
		box-sizing:border-box;
	}
	.content-full {
		height:100%;
	}
	#item5, #item6, #item7 {
		height:auto;
	}
	.story {
		top:auto !important;
	}
		.sample_popup-layout{z-index:1001 !important;}
	
	@media only screen and (max-width : 639px),
only screen and (max-device-width : 639px){
	.topStickyBarLine {height: 55px;}
}
		</style>

</head>

<body class="bodyhidden">
<!--Load Effets Starts -->
<div id="ballonseffects" class="hideIndex"></div>
<!-- Load Effets End-->
<div id="lay5formthankyou" style="display:none;float: left;position: fixed;width: 100%;left: 0;top: 0;padding: 12px 0;margin: 0px 0px 10px 0px;background-color:rgb(227, 255, 219);z-index: 9999;text-align: center;font-size: 20px; color: #0f580b;"> Thank you for your submission</div>
<div id="spinner" class="spinner" style="display:none;">
    <img id="img-spinner" src="images/spinner.gif" alt="Loading"/>
</div>

<!-- Social Media Icons -->
<div class="socialMediaIcon" style='' >
<ul>
	<li style="text-align: center;list-style: none;padding: 2px 1px 2px 0px;margin-bottom: 5px;display: none;" class="" id="socialarrow" data-value="1"><img src="/images/left-arrow.png" width="25" title="Hide" alt="Hide"></li>
</ul>
</div>
<!-- Ends here -->

    <!--Home Page Layouts-->
	 
<style type="text/css">
.hidedesk{display:none;}
.showdesk{display:block;}
.videoBgBlock {
	right: 0;
	background:#000000;
	background-repeat: no-repeat;
	background-size: cover;
    display: block;
    height: 100%;
    min-width: 100%;
    position: relative;
    top: 0;
    width: auto;
    z-index: -2;
	overflow:hidden;
}
.videoBg {
	right: 0;
    display: block;
    height: auto;
    min-height: 100vh;
    min-width: 100%;
    position: absolute;
    top: 0;
    width: 100%;
    z-index: -2;
	opacity:0.7;
}

/* Layout5 Styles */
.firstFixedSlidevideo{width: 100%;}
 .controls { display: none; }
@media only screen and (max-width : 1180px),
only screen and (max-device-width : 1180px){
	.headerPaddLayout5{width:98%;}
	.topleftLay5, .topRightLay5{ width:50%;}
	.appendFormWidth{width: 89% !important;}
}

@media only screen and (max-width : 1000px),
only screen and (max-device-width : 1000px){
.hideheaderTxtLay5{ display:none !important;}
.borderIconslayout5{border: 1px solid #ffffff !important; text-align: center; margin-top:6px; height: 50px;}
.headerPaddLayout5{padding:10px;}
.logoDivLayout5{width:160px;}
.topleftLay5{ width:auto;}
.topRightLay5{width:auto; margin-right:8px;}
.showMobLay5Ph{ display:block;}
.menuIcnColorLay5{ font-size:30px !important; margin: 0px 4px; padding: 2px 5px; border: 1px solid #ffffff; width: 44px; text-align: center;}
.appendFormWidth{ width:98% !important; }
a.shopNowBtnLayout5{display:block !important;}
.formDivMnLay5{float:none; max-width:360px; margin:auto;}
.leftTxtDivLay5{ display:none;}

}
@media only screen and (max-width : 985px),
only screen and (max-device-width : 985px){
	.hidedesk{display:block;}
	.showdesk{display:none;}
	.menuTxtlayout5{width: 80%;padding: 8px 0px;}
	.accordion-drop{width: 48px;padding: 18px 0px;}
}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
a.readMoreNewBtn {padding: 14px 0px; font-size: 20px;}
.scrollDivMn h3{ font-size: 22px;}
.formDivMnLay5 ul li input {font-size: 20px; padding: 14px 10px;}
.formDivMnLay5 ul li textarea {font-size: 20px !important; padding: 14px 10px; background-color:#fff;}
.formDivMnLay5{float:none !important; max-width:360px; margin:auto;}
.formDivMnLay5 { display:none !important;}

.leftTxtDivLay5{ display: block !important; width: 100% !important;}


.accordionMenuLayout5 ul li a{padding: 16px 0 10px 0; border-top: 1px solid rgba(255,255,255,.1);}
.logoimageTag{max-height:75px;}
.rightBoxAlign{width:auto !important;}
.leftBoxAlign{width:auto !important;}
}

@media only screen and (max-width : 640px),
only screen and (max-device-width : 640px){
	.firstFixedSlidevideo{width: 1350px; margin-left: -40%;}
	.videoBg {height:700px; width: auto;}
}


@media only screen and (max-width : 480px),
only screen and (max-device-width : 480px){
.slideMidBoxMn{width:98%;}
.slideMidBoxPadd{padding:20px; overflow:hidden; text-align:center !important;}
.rightAlignText{text-align:center !important;}
.leftAlignText{text-align:center !important;}
a.shopNowBtnLayout5 div{width:100% !important;}
.formDivMnLay5{width:98%;}
.rightBoxAlign{float:none !important;}
.leftBoxAlign{float:none !important;}
.videoBg{right:0;}
}
@media only screen and (max-width : 359px),
only screen and (max-device-width : 359px){
.margintopSlideBox1 { margin-top: 120px !important;}
.formHdTxtLay5 {font-size: 24px;}
.textBoxBanLay5{padding: 10px; box-sizing: border-box;}
.formDivMnLay5 ul li textarea {font-size: 20px !important;}
.addwidthPhn2{ width:27% !important;}
.topRightLay5{margin-right:4px;}
}
</style>

			    
	<div id="skrollr-body">
    	<div class="content" id="item2">
        	<div class="container" >
			<link href="css/main-layout3-new.css" rel="stylesheet" type="text/css" />
<link href="css/main-layout5.0.1.min.css" rel="stylesheet" type="text/css" />

<link href="css/layout5-header.0.1.min.css" rel="stylesheet" type="text/css" />
<!--<link href="css/.css?ver1.0" rel="stylesheet" type="text/css">-->
<link href="css/svg-fonts-styles.css" rel="stylesheet" type="text/css" />
<style>
.menuOptIcnInnDiv{border: 1px solid #e3e3e3 !important; text-align: center; margin-top:6px; height: 50px;}
.menuOptIcnInnDiv a{ text-decoration:none !important;}
.logoMid {width:60%; position:relative;}
.menuMobNew {
	padding: 2px 4px;
}
.submenuPad .menuMobNew a span{
	width:auto !important;
}
.menuMobNew a span {
	width:auto;
	display:block;
	min-height:80px;
	float:none;
	height:auto !important;
}
.subMenuMain a div{
	min-height:70px;
	height:auto !important;
}
.logo{position:relative;}

.cartToolTip {
	right: -32px;
    position: absolute;
    bottom: 55px;
    z-index: 9;
    background: #dfca80;
    color: #000;
    padding: 13px 15px;
    border-radius: 5px;
    font-size: 20px;
    font-weight: 300;
}
.cartToolTip::after {
	content: "";
    width: 0;
    height: 0px;
    border-left: 12px solid transparent;
    border-right: 12px solid transparent;
    border-top: 15px solid #dfca80;
    position: absolute;
    margin: 36px 38px 18px -54px;
}
.phoneCallTrackNumber a:hover{ text-decoration: none !important; }
</style>

<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
	
	.logoSizeModule {max-width:150px !important; max-height:90px !important;}



}
</style>
<style>
@media only screen and (max-width : 999px),
only screen and (max-device-width : 999px){
.editWebsiteBtn{ display:none !important;}
}
</style>
<style>
.freeEstimateBtn a {
	width:318px;
}
.freeEstimateBtn a:hover {
	width:318px;
}
.container .header {
	width:100%;
	margin:auto;
}
.container .headerOne {
	overflow:hidden;
	display:table;
	max-width:980px;
	margin:auto;
	color:#333333;
}
.containerWithBg .header {
	width:100%;
	margin:auto;
}
.containerWithBg .headerOne {
	overflow:hidden;
	display:table;
	width:980px;
	margin:auto;
	color:#ffffff;
}
.mainMenu {
	margin:auto;
	margin-bottom:5px;
}
.menuBlock {
	padding-right:0px;	
}
.menuBlock ul li {
	width:0%;
}
.menuStyle1 {
	background-color:#f6f6f6;	
}
.menuStyle1 .mainMenu {
	clear:both;
	width:980px;
	margin:auto;
	overflow:hidden;
}
.menuStyle1 .menuBlock {
	float:left;
	width:675px;
	padding-right:0px;
}
.menuStyle1 .menuBlock ul {
	border:none;
	background:none;
	margin:0;
	padding:0;
	border-radius:0;
	display:table;
	width:100%;
	list-style:none;
}
.menuStyle1 .menuBlock ul li {
	display:table-cell;
	list-style:none;
	text-align:center;
	font-family:"Open Sans",sans-serif;	
	font-weight:normal;
		font-size: 13px;
				width:auto !important;
	}
.menuStyle1 .menuBlock ul li a {
	line-height:60px;
	padding:0px;
	background:#f8f8f8;
	color:#666;
	display:block;
	text-decoration:none;
}
.menuStyle1 .menuBlock ul li a:hover {
	color:#666;
	background:#ededed;
	text-decoration:none;
}
.menuStyle1 .menuBlock > ul li:hover a {
	color:#666;
	background:#ededed;
	text-decoration:none;
}

.menuStyle1 .menuBlock ul li ul {
	display:none;
	background:#ffffff;
	border:0px;
	position:absolute;
	z-index:9999;
	margin-top:-0px;
	margin-left:0px;
	padding:0px;
	/* border:1px solid #ffffff; */
	 width:280px;
	-webkit-border-radius: 0px;
	-moz-border-radius: 0px;
	border-radius: 0px;
}
.menuStyle1 .menuBlock ul li:hover ul {
	display:block;
}
.menuStyle1 .menuBlock li ul li {
	display:block;
	border-bottom: 1px solid rgba(0,0,0,0.2);
	border-right:0px;
	float:none;
	margin:0px;
	padding:0px;
	width:280px;
	line-height:20px;
	text-align:left;
	/*word-break: break-all;*/
	word-wrap: break-word;
}
.menuStyle1 .menuBlock li ul li:last-child {
	border-bottom:0px;
}
.menuStyle1 .menuBlock li ul li a {
	border:0px;
	color:#666;
	text-decoration:none;
	background:none !important;
	cursor:pointer;
	border-radius:0px;
	padding:8px 10px;
	line-height:normal;
	text-align:left;
	font-weight:normal;
}
.menuStyle1 .menuBlock li ul li a:hover {
	background:#ededed !important;
}


.menuStyle1 .freeEstimateBtn a {
	width:280px;
	font-family:"Open Sans",sans-serif;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.menuStyle1 .freeEstimateBtn a:hover {
	width:280px;	
	padding:0px 10px;
	display:table-cell;
	vertical-align:middle;
	height:60px;
	text-align:center;
	color:#fff;
	font-size:22px;
	text-decoration:none;
}
.topStickyBarLine { border-bottom: 0px;}

.hidedesk{display:none;}
.contentInnerBody{box-shadow: none; padding: 5px 0px; border: 0px;}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){



}
.sample_popup-layout{z-index:100;}
.footerModule{width: 100%;}
@media only screen and (max-width : 639px),
only screen and (max-device-width : 639px){
	.topStickyBarLine {height: 55px;}
}
/* Layout5 Styles */
@media only screen and (max-width : 1180px),
only screen and (max-device-width : 1180px){
	.headerPaddLayout5{width:98%;}
	.topleftLay5, .topRightLay5{ width:50%;}
	
}

@media only screen and (max-width : 1000px),
only screen and (max-device-width : 1000px){
.hideheaderTxtLay5{ display:none !important;}
.headerPaddLayout5{padding:10px;}
.logoDivLayout5{width:190px;}
.topleftLay5{ width:auto;}
.topRightLay5{width:auto; margin-right:8px;}
.showMobLay5Ph{ display:block;}
.menuIcnColorLay5{ font-size:30px !important; margin: 0px 4px; padding: 2px 5px; border: 1px solid #ffffff; width: 44px; text-align: center;}
}
@media only screen and (max-width : 985px),
only screen and (max-device-width : 985px){
	.hidedesk{display:block;}
	.menuTxtlayout5{width: 80%;padding: 8px 0px;}
	.accordion-drop{width: 48px;padding: 18px 0px;}
}
@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.accordionMenuLayout5 ul li a{padding: 16px 0 10px 0; border-top: 1px solid rgba(255,255,255,.1);}
.logoimageTag{max-height:75px;}
}
@media only screen and (max-width : 359px),
only screen and (max-device-width : 359px){
.topRightLay5{margin-right:4px;}
}



 .menustickystyle{   }
 .menustylelogo{margin-top: 42px !important;}
 @media only screen and (max-width: 768px)
{.menustylelogo{ margin-top: 0px !important; }}
 

@media only screen and (max-width: 768px)
{
	.menuStyle1{ display: none !important; }
	
	


.sample_popup-layout{ top: -42px !important; }
</style>

<!--Top Sticky header start-->
<div class="topStickyBar" id="stickyshowhide" style="display:none;position:relative; z-index:1000;">
    <div class="topStickyBarLine bgcolorTheme">
        <div class="topStickyBarBtn"><a class="" href="form-sticky-header.php">Sticky Header</a> 
		 <a href="form-sticky-header.php" >
		<img src= "members/seobusinessboost/avatar/thumbs/thumbnail_1334808645.png" title="Promo Logo" alt="Promo Logo" border="0" height="35" /></a></div>
    </div>
</div>
<!--Top Sticky header end-->


<div class="headerbackgroung">
<div class="headerlayout5">
<div class="headerPaddLayout5">
	<div class="topleftLay5">
    <a href="index.php" title="SEO Business Boost"><div class="logoDivLayout5" style="position: relative; padding-right: 20px;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" style="max-width:100%;" border="0" class="logoimageTag" alt="SEO Business Boost" /><span class="tradeMarkIcon" style="right:0px; color:#ffffff;"></span></div></a>
	
	<a href="javascript:void(0);" style="text-decoration: none; margin:15px 15px 0px 0px; border: 1px solid #dfca80;display:none;float:right;" onclick="editwebsite();" class="editWebsiteBtn">
        <div style="color: #000000; padding: 10px 24px; font-size: 20px; font-weight: 300; background:#faecbe;">
          <span style="vertical-align:middle; display:inline-block; margin-top: -6px;">
          <img src="images/control-panel-icon-footer-black.svg" alt="Control Panel" border="0" width="23" height="23">
          </span>
          Edit Website
        </div>
    </a>
	
    </div>
    <div class="topRightLay5">
    	<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()" title="Menu" ></span>
		<a href="tel:2514245682" title="Call:2514245682" style="">
        <span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
		</a>
        <div class="shoponlineTxt hideheaderTxtLay5 phoneFloatRight">
				<a href="get-free-quote-9.php"   style="" >
		Get Free Quote</a>
				</div>	
    	<div class="layout5Phnum hideheaderTxtLay5" style="">
        	
            <div style="width:36px; overflow:hidden; float:left;">
            	<span class="icon-phone phoneIcnLayout5"></span> 
            </div>
            <div style="float:left; width:auto; padding:5px 0px 0px 3px;" class="phoneCallTrackNumber"><a href="javascript:void(0);">251-424-5682</a></div>
           
        </div>
    </div>
</div>
</div>
<!--mobile menu option left and right Icons-->
<div style="position: absolute; padding-top:10px; display:none;z-index: 9;width: 100%;" class="headerSecLayout5">
<div style="cursor:pointer; padding:2px; position:absolute; top:10px; left:3px; z-index: 1;">
<a href="tel:2514245682" title="Call:2514245682" style="text-decoration:none;">
<span class="icon-phone iconSizeDiv menuIcnColorLay5 showMobLay5Ph"></span>
</a>
</div>
<div class="logo" style="text-align:center; display:inherit; margin:auto;">
    <a href="index.php" title="SEO Business Boost" style="position: relative;"><img src="https://www.seobusinessboost.com/members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" alt="SEO Business Boost" class="logoSizeModule" border="0">
    <span class="tradeMarkIcon" style="color:#ffffff;"></span>
    </a>
</div>
<div  style="cursor:pointer; padding:2px; position:absolute; top:10px; right:3px;">
<a href="javascript:void();" onclick="showMenu();" style="text-decoration:none;">
<span class="icon-menu iconSizeDiv menuIcnColorLay5" onclick="openNav()"></span>
</a></div>
</div>
<!-- end-->

</div>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <!-- Layout5 Menu  Starts here -->
<div id="accordionmenulayout5">
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="home-10.php"  ><span class="menuTxtlayout5">Home</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="about-us-8.php"  ><span class="menuTxtlayout5">About Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
		<div class="accordion-toggle">
		<a href="email-us-your-request-9.php"  ><span class="menuTxtlayout5">Contact Us</span></a>
		</div>
	</div>
		<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="website-builder-design-s1.php"  ><div class="menuTxtlayout5">Web Design</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="free-website-special-offer-s18.php"    >Free Website Special Offer</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="seo-management-company-s2.php"  ><div class="menuTxtlayout5">SEO Management</div></a>
		<div class="accordion-drop" data-display="1"><span class="accordion-open"></span></div>	</div>
		<div class="accordion-content" style="clear:both;">
    	<div class="accordionMenuLayout5">
        	<ul>
			
				 
            	<li><a href="website-seo-company-s6.php"    >Website SEO Company</a></li>
                        </ul>
        </div>
	</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="google-adwords-s3.php"  ><div class="menuTxtlayout5">Google Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="facebook-ads-s4.php"  ><div class="menuTxtlayout5">Facebook Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="youtube-ads-s5.php"  ><div class="menuTxtlayout5">YouTube Ads</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5">
	<div class="accordion-toggle">
    	<a href="digital-marketing-services-s17.php"  ><div class="menuTxtlayout5">Digital Marketing</div></a>
			</div>
	    </div>
	<div class="borderBtmLay5 hidedesk">
		<div class="accordion-toggle">
		<a href="marketing-blog-26.php"  title="Marketing Blog" ><span class="menuTxtlayout5">Marketing Blog</span></a>
		</div>
	</div>
</div>
<!-- Layout5 Menu  Ends here -->
<script type="text/javascript">
$(document).ready(function($) {
	$('#accordionmenulayout5').find('.accordion-drop').click(function(){
		var span=$(this).find('span');
		var othrspan=$(".accordion-drop > span").not(span);
		//Expand or collapse this panel
		$(this).parent().next().slideToggle('fast');
		//Hide the other panels
		$(".accordion-content").not($(this).parent().next()).slideUp('fast');
		$(".accordion-drop").not($(this)).attr("data-display","1");
		othrspan.removeClass('accordion-close');
		othrspan.addClass('accordion-open');
		othrspan.html('');
		var visible = $(this).attr("data-display");
		if(visible=='1'){
			span.removeClass('accordion-open');
			span.addClass('accordion-close');
			span.html('x');
			$(this).attr("data-display","0");
		}else{
			span.removeClass('accordion-close');
			span.addClass('accordion-open');
			span.html('');
			$(this).attr("data-display","1");
		}
	});	
});
</script>
</div>

<script>window.jQuery || document.write('<script src="js/zepto.js"><\/script>')</script>
<script src="jquery.waterfall.js"></script>
<script type="text/javascript">
function showMenu(){
	var showStatus=$('#menuList').attr('show-status');
	if(showStatus==0){
		$('#menuList').css('top','auto');
		$('#menuList').attr('show-status','1');
		$('#menuList').css('opacity','1');
		$("#menuIcn").attr('class', 'icon-close iconSizeDiv themeColor');
	} else if(showStatus==1){
		$('#menuList').css('top','-1000px');
		$('#menuList').css('opacity','0');
		$('#menuList').attr('show-status','0');
		$("#menuIcn").attr('class', 'icon-menu iconSizeDiv themeColor');
	}	
	// var src = $("#menuIcn").attr('class') == "menucloseIcnBg-menuOpt" ? "menuIcnBg-menuOpt" : "menucloseIcnBg-menuOpt";
	//  $("#menuIcn").attr('class', src);
	/* var src = $("#menuIcn").attr('src') == "images/close-icn-empty-thin.png" ? "images/menu-icn-empty-thin.png" : "images/close-icn-empty-thin.png";
	$("#menuIcn").attr('src', src); */
	
	return false;
		
}
function showSubMenu(id){ 
	if($('#subMenu_'+id).css('display') == 'none'){
		var body = document.body,
		html = document.documentElement;
		var height = Math.max( body.scrollHeight, body.offsetHeight,
		html.clientHeight, html.scrollHeight, html.offsetHeight );
		document.getElementById('subMenu_'+id).style.height=height+'px';
		$('#subMenu_'+id).show();
				$('html, body').animate({scrollTop:0}, 'slow');
	}else{
		$('#subMenu_'+id).hide();
	}
}
function stickyheadershowhidefun(){
var stickydeskStatus= '2';
var stickymobStatus = '1';
var stickyparentdiv= 'container';
if($(window).width() >= 960){
if(stickydeskStatus==2)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
}
else
{
if(stickymobStatus==1)
{
$('#stickyshowhide').css('display','none');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}
else
{
$('#stickyshowhide').css('display','');
$('#stickyshowhide').parent("."+stickyparentdiv).css("padding-top","0px");
$('#stickyshowhide').parent("."+stickyparentdiv).css("background-position","0px 0px");
}

}
}
$(document).ready(function(){
stickyheadershowhidefun();
});
$(window).resize(function () {
stickyheadershowhidefun();
});

function editwebsite(){
	/* var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('controlPanel').style.height=height+'px';
	$('#controlPanel').focus(); */
	$('html, body').animate({
		scrollTop: $("#controlPanel").offset().top
	},1000);
	$("#controlPanel").focus();
	$("#cartToolTip").show();
}
var stickydeskStatus= '2';
var stickymobStatus = '1';
if(stickydeskStatus!=2 || stickymobStatus!=1 )
{
$(document).on( 'scroll', function(){
	if ($(window).scrollTop() > 2) {
		$("#stickyshowhide").css('position','fixed');
		if($(window).width() >= 960){
		//$(".headerbackgroung").css('margin-top','44px');
		}
	} else {	
				$("#stickyshowhide").css('position','relative');
			}
});
}
$(document).ready(function($) {closeNav();});

/* Set the width of the side navigation to 250px */
function openNav() {
   $("#mySidenav").css({'width':"320px",'overflow':''});$('body').css('overflow','hidden');
}
/* Set the width of the side navigation to 0 */
function closeNav() {
    {$("#mySidenav").css({'width':"0",'overflow':'hidden'});$('body').css('overflow','');}
}
</script>
<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="css/if-ie.css" />
<![endif]-->
<link rel="stylesheet" type="text/css" href="css/listcarousel-botbox-v1.css" />
            </div>
			<style>
			@media only screen and (max-width : 480px),only screen and (max-device-width : 480px){.rightAlignText{text-align:center !important;}.leftAlignText{text-align:center !important;}}
			</style>
							<div id="firstFixedSlide" style="background-image:url(members/seobusinessboost/index/Optimized-digital-marketing-agency-Gulf-Shores-Alabama.1--2-.jpg);background-size:cover; background-position:top;height: 100vh;">
			           <div style="height:100%;">
                <div class="story appendFormWidth animation-element slide-up in-view">
								<div class="margintopSlideBox1" >
                    <div class="leftTxtDivLay5" style="border: none; ">
                    	<div class="slideMidBoxPadd" style="text-align:left;">
						                            <h2 class="boxHeadLayout5">SEO Digital Marketing Agency</h2>
						                            <p style="font-size:24px; font-weight:300; line-height:32px; color:#ffffff; padding:10px 0px; margin:0px;">Search Engine Optimization, Pay-Per-Click, Social Media, and Website Design.</p>
                            							<a href="https://www.seobusinessboost.com/get-free-quote-9.php" class="shopNowBtnLayout5"><div>Get Free Quote</div></a>
							                        </div>
                    </div>
										<div class="formDivMnLay5" style="background-color:rgba(0,0,0,0.4)">
                        <div class="formPad20">
                            <div class="formHdTxtLay5" style="text-align:center;color:rgb(255,255,255)">Get Free Quote</div>
                            <ul>
                                <li>
																<input id="lay5formName" name="lay5formName" type="text" class="textBoxBanLay5" placeholder="Name" onfocus="this.style.border=''" maxlength="20"/>
																</li>
                                <li>
																<input id="lay5formEmail" name="lay5formEmail" type="text" placeholder="Email" class="textBoxBanLay5" onfocus="this.style.border=''" maxlength="50"/>
																</li>
                                <li>
																<input id="lay5formPhone1" name="lay5formPhone1" type="tel" placeholder="Phone" style="width:28%" class="textBoxBanLay5" onkeyup="lay5isNumberKey(1);" onKeyPress="return isNumberic(event)" onpaste="return isNumberic(event)" onfocus="this.style.border=''" maxlength="3" />
                                <input id="lay5formPhone2" name="lay5formPhone2" type="tel" style="width:28%" class="textBoxBanLay5 addwidthPhn2" onkeyup="lay5isNumberKey(2);" onKeyPress="return isNumberic(event)" onpaste="return isNumberic(event)" onfocus="this.style.border=''" maxlength="3"/>
                                <input id="lay5formPhone3" name="lay5formPhone3" type="tel" style="width:41.23%" class="textBoxBanLay5" onKeyPress="return isNumberic(event)" onpaste="return isNumberic(event)" onfocus="this.style.border=''" maxlength="4"/>
																</li>
                                <li>
																<textarea id="lay5formMsg" name="lay5formMsg" style="resize:none;" class="textBoxBanLay5" placeholder="Message" onfocus="this.style.border=''" maxlength="100"></textarea>
																</li></ul>
                           <a href="javascript:void(0);" class="shopNowBtnLayout5 bgcolorTheme" onclick="return validatelay5form()"><div style="background:none; color:#ffffff;  max-width:100%;">Click Here</div></a>
						   <input type="hidden" name="lay5verifyHuman" id="lay5verifyHuman" value="shift!&XYZ" />
							<input type="hidden" name="lay5spamRestrict1" id="lay5spamRestrict1" value="2b2ef63e85d69e0292e67ee42e9fa31e" />
							<input type="hidden" name="lay5spamRestrict2" id="lay5spamRestrict2" value="e13af9e24ee76e2920e96d58e36fe2b2" />
							<input type="hidden" name="lay5spamRestrict3" id="lay5spamRestrict3" value="" />
                        </div>
                    </div>
				</div>
								
                <!-- form Box -->
                
				
                    
                    
                                        
                    
                    	
                    
                    <!-- form ends here -->
                    
                 </div> <!--.story-->
            </div>
						
            </div>
			            <div class="contentBlockLayout3" style=""  id="secondsmallbox">
                <div class="contentImgBox contentText">
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tr>
                            <td>
                                <div class="animation-element slide-left in-view"><h2 class="" style="color:#;background-image:none; ">Get Your SEO Business Boost!  </h2>
                                     <span><h2>Choose SEO Business Boost for Your Brand</h2><div>Entering the online advertising space with a handful of experts in the field of digital marketing, SEO, and social media, SEO Business Boost is soon to be your go-to for all online advertising needs pertaining to your business. Our team comes with an array of specialists who have had years of experience in SEO and digital media marketing - doing what they do best.</div><div><br></div><style>.columns{display:flex;flex-flow:row wrap;justify-content:center;margin:5px 0}.column{flex:1;align-self:center}.column h3{margin:0}.column img{width:150px;vertical-align:middle;margin:10px 0}.filter-grey{filter:grayscale(1)}.text-center{text-align:center}.trust-logos-mob{display:none}@media screen and (max-width: 680px){.columns .column{flex-basis:50%;margin:0 0 5px 0}.column img{width:110px !important}.trust-logos-mob{display:block}.trust-logos{display:none}}</style><br><div class="text-center"><h2>We're Experienced in Optimizing the Most Popular eCommerce &amp; CMS Website Platforms</h2> <section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/amazon.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/godaddy.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/squarespace_logo.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/wix.jpg" alt=""></div> </section> <section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/woocommerce.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/shopify.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/drupal.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/wordpress.jpg" alt=""></div> </section></div><br><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center;border-bottom: 2px solid #1c81d5;line-height: 1px;padding-top: 15px;margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><h2>Goal Oriented for Every Business</h2><div>We take the time to learn about your business and understand it’s ways of working so that we can design the best digital media campaigns. Our goal is to see your business through with every ad campaign and ensure successful outcomes every single time.</div><div><br></div><h2>Grow with SEO Business Boost</h2><div>We can assure you stellar growth for your business as we have experts on board who constantly monitor you and your competitors, ready to tweak your campaigns to make sure you stay on top of the game. With maximum reach for your target audience, we will help grow your business and explore insights together.</div><div><br></div><h2>SEO Business Boost will also Boost Revenue</h2><div>We’re beyond just establishing your businesses presence online and managing it’s social media platforms. With our carefully strategized digital media marketing and ad campaigns, we also aim to bring in revenue for your business.</div><div><br></div><div class="text-center"> <section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/shopify.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/fba-logo.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/fb-market.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/etsy.jpg" alt=""></div> </section> <section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/big-commerce.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/ebey.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/square.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/youtube.jpg" alt=""></div> </section> <section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/pinterest.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/insta-shop.jpg" alt="" style="width: 80px !important"></div><div class="column"><img src="../../members/seobusinessboost/index/google-shopping-seo.jpg" alt=""></div> </section></div><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><h2>Win All Your Clientele with Quality SEO</h2><div>Besides making great content and ad campaigns for your business, our SEO team also works tirelessly to keep you on top of the game by identifying your competitors and constantly tweaking your ad campaigns - keeping you number one on search engine results.</div><div><br></div><h2>Get the Best Service with SEO Business Boost</h2><div>We take your business very seriously. That being said, we also see the importance in supporting our clients with everything that they need. Our team is here to help you, constantly available for support, to help you achieve your businesses goals, brainstorm ideas, and more. Give us a call and we’ll be happy to help!</div><div><br></div><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><br><div style="clear:both;" class="text-center trust-logos"><h2>WE ARE ACCREDITED, TRUSTED &amp; 5 STAR RECOMMENDED.</h2> <section class="columns"><div class="column"><a href="https://www.bbb.org/us/al/gulf-shores/profile/pay-per-click-advertising/seo-business-boost-0463-90208283" target="_blank"><img src="../../members/seobusinessboost/mypages/better-business-bureau.jpg" alt="better-business-bureau"></a></div><div class="column"><img src="../../members/seobusinessboost/index/google-5s.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/yelp-5s.jpg" alt=""></div><div class="column"><a target="_blank" href="https://business.mygulfcoastchamber.com/list/member/seo-business-boost-8459"><img style="width: 145px !important;" src="../../members/seobusinessboost/index/chamber_logo.png" alt="chamber_logo"></a></div></section><section class="columns"><div class="column"><img src="../../members/seobusinessboost/index/top-pro-badge-18.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/trustpilot.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/seo-certified-1.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/best-od-small-business.png" alt=""></div></section></div><div style="clear:both;" class="text-center trust-logos-mob"><h2>WE ARE ACCREDITED, TRUSTED &amp; 5 STAR RECOMMENDED.</h2><section class="columns"><div class="column"><a href="https://www.bbb.org/us/al/gulf-shores/profile/seo-services/seo-business-boost-0463-90208283"><img src="../../members/seobusinessboost/mypages/better-business-bureau.jpg" alt="better-business-bureau"></a></div><div class="column"><img src="../../members/seobusinessboost/index/google-5s.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/yelp-5s.jpg" alt=""></div><div class="column"><a target="_blank" href="https://business.mygulfcoastchamber.com/list/member/seo-business-boost-8459"><img style="width: 145px !important;" src="../../members/seobusinessboost/index/chamber_logo.png" alt="chamber_logo"></a></div><div class="column"><img src="../../members/seobusinessboost/index/top-pro-badge-18.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/trustpilot.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/seo-certified-1.png" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/best-od-small-business.png" alt=""></div></section></div><div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2513063616" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-306-3616</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><section class="columns text-center"><div class="column"><img src="../../members/seobusinessboost/index/moz.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/google-search-console.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/hubshout.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/google-analytics.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/semrush.jpg" alt=""></div><div class="column"><img src="../../members/seobusinessboost/index/g-trends.jpg" alt=""></div> </section><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style>

<div style="max-width: 406px;text-align: center;margin: auto;padding-top: 20px;"><a href="get-free-quote-9.php" style="border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 44%;text-align: center;padding: 10px;margin: 5px 0px 5px 0;vertical-align:middle;" class="formBtn responsiveBtn btnFldTxt-edit calltoActionTxtSML"><span style="padding-top:4px;display: inline-block;color:white;">Get Free Quote</span></a> <a href="tel:2514245682" class="formBtn responsiveBtn btnFldTxt-edit" style="font-size:20px;border-radius:0px;-webkit-border-radius:0px;-moz-border-radius:0px;margin:0 auto;white-space:initial;word-wrap:break-word;min-width: 45%;text-align: center;padding: 10px;margin: 5px 0;vertical-align:middle;"><span class="phoneIcnjess"><span class="icon-phone phoneIcnLayout5"></span></span><span style="padding-top:4px;display:inline-block;color:white;">251-424-5682</span></a><div style="text-align: center; border-bottom: 2px solid #1c81d5; line-height: 1px; padding-top: 15px; margin-bottom: 20px;"><span style=" background:#fff; padding:0 10px;">Call or Text</span></div></div><style>.phoneIcnLayout5{ border-radius: 50%; width: 28px; height: 28px; position: relative; border: 2px solid #ffffff; color: #ffffff !important; display: table-cell; vertical-align: middle; text-align: center; padding: 2px; cursor: pointer; }</style> </span>
                                     </div>
                            </td>
							                        </tr>
                    </table>
                </div>
            </div>
			        </div>
		        <div class="content" id="item3">
		        </div>
		        <div class="content" id="item4">
		        </div>
                <div class="content" id="item5">
		        </div>
        		<style>
		.contentText{ padding:20px !important }
		.scrollDivMn{max-width:980px; min-width:300px; margin:auto; overflow:hidden; padding:0px 30px; text-align:center; padding-bottom:20px;}
		.scrollIcnDiv{width:100%;}
		.scrollTxtDiv{padding:5px 0px; overflow:hidden; font-size:20px; color:#333333;}

		.circleImg { height: 210px; margin-left: -50px; }
		.circleImganchor{ display:block; max-width: 210px; margin: auto;border-radius: 50%;overflow: hidden;}
		.squareImg{width:300px;}
		.squareImganchor{ display: block; width: 300px; margin: auto; }

		.content {border-bottom:0px;}
		.miniBoxes h3 { font-family: "Open Sans", sans-serif;  font-weight: normal; }

		.scroll-img { overflow:hidden; }
		.scroll-img ul { max-width: 1200px; min-width: 300px; margin: auto; padding: 1px; }
		.scroll-img ul li { display: inline-table; }
		.btmBoxTitles { width:210px; margin:auto; word-wrap:word-break; padding:10px 0;}
		
				.scroll-img { height:auto; }
		.scroll-img ul { height: auto; }
						.scroll-img ul { text-align: center; }
									.scroll-img ul li {margin: 10px 49px; }
							
		#demo3-forward, #demo3-backward { height: 24px; width: 24px; padding: 15px; border:0px; border-radius: 50%;
		background: transparent url("cms/scripts/owl-carousel/arrow-shade-cms.png") repeat scroll 0% 0%;
		outline: none; }
		
		@media only screen and (max-width : 939px),
		only screen and (max-device-width : 939px){
		.scrollDivMn {min-width: 300px; margin: auto; overflow: hidden; padding: 10px 0px; text-align: center; max-width: 800px; }
		.scroll-img { overflow: hidden; }
		.scroll-img ul { max-width: 1200px; min-width: 300px; margin: auto; padding: 1px; text-align:center; }
				.scroll-img { height:auto; }
		.scroll-img ul { height: auto; }
				}
		
		@media only screen and (max-width : 755px),
		only screen and (max-device-width : 755px){ 
		.scroll-img ul li { display: block !important; margin: 16px 0px;}
		}
		
		@media only screen and (max-width : 670px),
		only screen and (max-device-width : 670px){
			
		.circleImg { height: 100%; margin-left: -20%; width:150% }
		.circleImganchor{ display:block; max-width:300px; margin:auto; border-radius: 50%; overflow: hidden;}
		.squareImg { width: 100%; }
		.squareImganchor { display: block; margin: auto; max-width: 410px; width:100%; }
		.btmBoxTitles { max-width:240px; margin:auto; padding:10px 0; word-wrap:word-break; width:auto;}
		.contentText{ padding:20px 0px !important }
				.scroll-img { height: auto !important; }
		.scroll-img ul { height: auto !important; }
					
		}
		
		@media only screen and (max-width : 480px),
		only screen and (max-device-width : 480px){
		.scroll-img { height: 330px; }
				.circleBoxDiv h3 {width:300px; margin:auto; padding:10px 0px;}
		
		}
		@media only screen and (max-width : 360px),
		only screen and (max-device-width : 360px){
				}

		@media only screen and (max-width : 359px),
		only screen and (max-device-width : 359px){
				}
		</style>
		<div class="content" id="item6">
		<!-- Mini Boxes -->
			<div class="miniBoxes">
				<div class="scrollDivMn">
					<div id="demo3" class="scroll-img circleBoxDiv">
					<ul>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_1"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_1" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Web Design</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_2"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_2" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Search Engine Optimization</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_3"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_3" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Google Ads Management</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_4"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_4" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Facebook Ads Management</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_5"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_5" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">YouTube Ads Management</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_6"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_6" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Digital Marketing Services</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_7"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_7" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Digital Marketing Blog</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_8"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_8" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">People Also Ask - FAQ's</h3>
						</div>
						</li>
											<li class="animation-element slide-zoom in-view">
						<a  class="circleImganchor" id="btmImgBoxesanchor_9"  ><img alt="" border="0" src="images/blank-mini-row-img-large.jpg" id="btmImgBoxes_9" class="circleImg"></a>
						<div style="text-align:center; height:70px; word-wrap:break-word; max-width:100%; margin:auto" >
						<h3 class="btmBoxTitles" style="color:#; font-family: 'Open Sans', sans-serif; font-weight: normal;">Why Hire Us?</h3>
						</div>
						</li>
										</ul>
					</div>
					<div id="demo3-btn" class="text-center" style="display:none">
						<input type="image" id="demo3-backward" src="cms/images/btmbox-down-arrow.png" >
						<input type="image" id="demo3-forward" src="cms/images/btmbox-up-arrow.png" >
					</div>
				</div>
			</div>
		<!-- Mini Boxes end-->
		</div>
		        
        <div class="content" id="item7">
        	<style>
@media only screen and (max-width: 768px) {
		.hideIndex{display:none !important;}
}
</style>
<input type="hidden" id="promotionaltoolText" value="">
<input type="hidden" id="promotionaltoolText1" value="">
<input type="hidden" id="promotionaltoolText2" value="">
<input type="hidden" id="promotionaltoolText3" value="MA==">
<input type="hidden" id="promotionaltoolText4" value="MA==">
<input type="hidden" id="promotionaltoolText5" value="MA==">

<!--Bottom Boxes start-->
<!-- Box Bottom Starts Here new div -->
<!-- Box Bottom Ends Here -->

<!-- Social Media -->
<!--End Social Media -->



<!--Footer start -->
<div class="footerModule" >
    <div class="footerBox" style="position:relative;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td class="footerMenuHeading" align="left" valign="middle">
        <span id="recordSitename"  >SEO Business Boost. SEO, PPC, Social Media and Website Design. </span> 
        
        </td>
        </tr>
        <tr>
        <td><table cellpadding="0" cellspacing="0" align="center" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="top">
          <ul class="footerMenuLinks">
              <li>			<a href="home-10.php"   >
			Home</a>
			</li>
            							<li><a href="website-builder-design-s1.php"   title="Web Design" >Web Design</a>
						</li>
																<li><a href="seo-management-company-s2.php"   title="SEO Management" >SEO Management</a>
						</li>
																<li><a href="google-adwords-s3.php"   title="Google Ads" >Google Ads</a>
						</li>
																<li><a href="facebook-ads-s4.php"   title="Facebook Ads" >Facebook Ads</a>
						</li>
																<li><a href="youtube-ads-s5.php"   title="YouTube Ads" >YouTube Ads</a>
						</li>
																<li><a href="digital-marketing-services-s17.php"   title="Digital Marketing" >Digital Marketing</a>
						</li>
																<li><a href="about-us-8.php"   title="About Us" >About Us</a>
						</li>
																<li><a href="email-us-your-request-9.php"   title="Contact Us" >Contact Us</a>
						</li>
																<li><a href="sitemap-18.php"   title="Sitemap" >Sitemap</a>
						</li>
																<li><a href="marketing-blog-26.php"   title="Marketing Blog" >Marketing Blog</a>
						</li>
																		
									
							

			        </ul>
        </td>
        
        
        <td class="footerPhoneNumber" id="footerphonetd" style="display:;" align="center" height="100" width="400">
        <table cellpadding="5" cellspacing="0" align="center" border="0">
        <tbody><tr>
        <td valign="middle"><img src="images/phone-icon-footer.png" height="50" width="50" alt="call"></td>
        <td valign="middle">251-424-5682</td>
        </tr>
        </tbody></table></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        <tr>
        <td class="footerTopLine">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="left" valign="middle" width="55%" id="allrights_received" >
        <span id="rocID" >1545 Gulf Shores Parkway #146, Gulf Shores, AL 36542</span>
		 <br/>         <span id="AllRReserved" >Powered By <a href="https://www.cloudlgs.com/en/" target="_blank">www.CloudLGS.com</a></span></td>
        <td align="right" valign="top" width="45%">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tbody><tr>
        <td align="right">
				
		</td>
        <td align="right" valign="middle" width="25"  onClick="return sendmailfn()" id="controlPanel" style="cursor:pointer;"><a title="Control Panel" href="javascript:void(0)"><img src="images/control-panel-icon-footer.svg" alt="Control Panel" border="0"></a> <div class="cartToolTip" id="cartToolTip" style="display:none;">Click Here</div></td>
        </tr>
        </tbody></table>
        </td>
        </tr>
        </tbody></table>
        
        </td>
        </tr>
        </tbody></table>
    </div>
</div>
<!--End Footer -->

<!-- Mobile Footer start-->
<div class="stickyFooterPad"></div><div class="footerModuleMobile" id="footerMenu" style="">
    <div>
        <div class="icn-mnu-stp-div">
            <div class="hme-strip-blk1 icnstrp-txt">
            <a href="home-10.php"><img src="images/hme-icn-v2.png" border="0" height="26" width="26" alt="Home"></a><br>
            <a href="home-10.php"   >Home</a>
            </div> 
              
            <div class="hme-strip-blk2 icnstrp-txt">
            <a href="about-us-8.php"><img src="images/abt-us-icn-v2.png" border="0" height="26" width="26" alt="About Us"></a><br>
            <a href="about-us-8.php"   >About Us</a>
            </div> 
             
             
            <div class="hme-strip-blk3 icnstrp-txt">
            <a href="email-us-your-request-9.php"><img src="images/cnt-us-icn-v2.png" border="0" height="26" width="26" alt="Contact Us"></a><br>
            <a href="email-us-your-request-9.php"   >Contact Us</a>
            </div> 
          			<div class="hme-strip-blk4 icnstrp-txt">
	<a href="directions.php"><img src="images/dirt-icn-v2.png" height="26" width="26" border="0" alt="Directions" /></a><br />
			<a href="directions.php">Directions</a>
			</div>  
			          </div>
    </div>

</div>
<!-- Mobile Footer end -->

<!--Login Pop Up Div Start-->
<div class="sample_popup-layout" id="logInDiv" style="display:none;" >
<div class="loginPopUpBlock">
<form  method="post" name="loginform" onSubmit="return validate_form(this);" >
<div class="loginTitleBlock" style="border-bottom:1px solid #ddd;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><div id="logintext">Login</div><div id="forgottext" style="display:none;">Forgot Login Details</div></td>
    <td align="right" valign="middle"><a href="javascript:void(0);" onclick="closeLog();"><img src="images/loginbox-close.png" alt="Close" width="31" height="31" border="0" /></a></td>
  </tr>
</table>
</div>
<div class="loginBodyBlock">
<div id="forgotloading" align="center" class="loginBoxHeadingTxt" style="font-size:12px;"></div>
<div id="loading" align="center"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="45" align="left" valign="middle">
    <div id="usernametr">
	<input name="password" class="loginTxtFldNew" id="username" value="Username" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="text" style="width:96%;">
    </div>
	<div id="forgotusernametr" style="display:none;">
    
    
    <div id="TabbedPanels1" class="TabbedPanels">
  <ul class="TabbedPanelsTabGroup">
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(1)" style="outline:0;" >User</li>
    <li class="TabbedPanelsTab" tabindex="0" onclick="radiobtnactive(2)" style="outline:0;" >Admin</li>
  </ul>
  
  <div class="TabbedPanelsContentGroup" style="background-color: #ededed;">
  
    <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsusername" class="textBoxloginNew" id="lmsusername" value="Enter Your Registered Email" onfocus="if(this.value==this.defaultValue)this.value='';this.style.borderColor='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runPasswordScript(event)" style="width: 96%; " type="text">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
                
   <div class="TabbedPanelsContent">
    	<div class="inncntBlkLoginDiv">
         <input name="lmsadminname" class="textBoxloginNew" id="lmsadminname" value="seo****@gmail.com    " onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" style="width: 96%;" type="text" disabled="disabled">
         <span><strong style="color:#cc0000;">Note :</strong> Above email will receive login credentials.</span>
        </div>
    </div>
  </div>
</div>   
	</div>
	</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="passwordtr">
		<div style="width:229px; float:left;">
		<input name="password" class="loginTxtFldNew" id="password" value="Password" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" type="password" style="width:217px;">
        </div>
        <div class="passwordDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <input type="checkbox" name="passwordChk" id="passwordChk" class="css-checkboxshowpass"/>
                <label for="passwordChk"  class="css-labelshowpass" style="float:left;">Show</label>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr>
    <td height="45" align="left" valign="middle" id="captchatr" style="display:none;">
		<div style="width:185px; float:left;">
		<input type="text" name="login_captcha" id="login_captcha" class="loginTxtFldNew" value="Security Code" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" onkeypress="return runScript(event)" style="width:170px;">
		<input type="hidden" name="logincount" id="logincount" value="0" />
        </div>
        <div class="securityDiv">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="center" valign="middle" style="padding:4px 6px; position:relative;">
                <img border="0" id="logincaptcha" src="captcha/image-login.php" alt="captcha" /></td>
			  <td width="50%" align="left" valign="middle"><a href="javaScript:new_logincaptcha();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a>
              </td>
            </tr>
        </table>
		</div>
		</td>
  </tr>
  <tr >
    <td align="left">
	<div id="checktr" style="font-size:12px; font-family:Arial, Helvetica, sans-serif;" ><input name="loginremembercheck[]" id="loginremembercheck" value="1" onclick="if(this.checked==true) this.value=1; else this.value=0;" class="css-checkboxrememberpass" checked="checked" type="checkbox">
     <label for="loginremembercheck" class="css-labelrememberpass" style="float:left;"></label><span style="padding: 5px 0px; display: block; float:left; font-family: 'Open Sans', sans-serif !important; font-size:14px; ">Remember me</span></div>	</td>
  </tr>
</table>
</div>
<div class="loginTitleBlock" style="border-top:1px solid #ddd;">
<div id="submitbtntr">
<input type="hidden" name="mid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="Submit" class="loginBoxBtnNew" value="Login" type="button" onclick="return logIn()"  style="cursor:pointer;"><input name="clickstatus" type="hidden" value="0" id="clickstatus"></td>
    <td align="right" valign="middle"><input name="forgotpass" id="forgotpass" class="loginBoxBtnNew" value="Need Help?" onclick="return showusertype();" style="cursor:pointer;" type="button"></td>
  </tr>
</table>
</div>
<div id="forgotsubmitbtntr" style="display:none;">
 <input type="hidden" name="forgotmid" value="" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" valign="middle"><input name="ForgotSubmit" class="loginBoxBtnNew" value="Submit" type="button" onClick="return LmsUserforgot();"  style="cursor:pointer;"> 
    <input type="hidden" value="1" id="hiddenactiveval"/>
    <input name="ForgotCancel" id="ForgotCancel" class="loginBoxBtnNew" value="Back" onClick="forgotCancel();" style="cursor:pointer;" type="button"></td>
    <td align="left" valign="middle">&nbsp;</td>
  </tr>
</table>
</div>
</div>
</form>
</div>
</div>

<!--Login Pop Up Div End-->

<!--Dashboard options-->
<div id="dashboardPopup" class="sample_popup-layout" align="center"  style="display:none;"> 

<div class="newdashboardPopUp">
	<!-- Header Starts Here -->
    <div class="dashboardnew-row-1">
    	<table width="98%" border="0" cellspacing="0" cellpadding="5" align="center">
        <tbody>
            <tr>
            <td width="32%" align="left" valign="middle" class="dashboardhdngtxt"><span class="themeColor">Dashboard Options</span></td>
            <td width="60%" align="left" valign="middle"><a href="cms/logout.php?logout=1" >
			<img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out" />
			</a></td>
            <td width="21%" align="right" valign="middle"><a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
        <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
        </a></td>
          </tr>
        </tbody>
        </table>

    </div>
    <!-- Ends here -->
    
    <div class="dashboardnew-row-2">
    
    <div class="dashboardinnDivNew">
    	<div class="dashboardmndiv">
    <ul>
    	<li id="list1" ><a href="cms/" id="InsiteCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="cms">
             Manage your website content and images with inline edit feature             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/edit-website-flat.png" alt="Edit Website" width="110" height="96" border="0" /></div>
               <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Edit Website</span><br />
                    <span class="dashboardblksmllxt">Insite CMS</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list2"><a  href="admin/setting.php" id="displayCmsLink" style="  ">
        	<div class="icnblkdivmnovr" style="display:none;" id="controlpanel">
              Web pages management, Images, SEO, E-Commerce and all other "Under the Hood" Settings
            </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/admin-panel-icon-flat.png" alt="Admin" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Admin</span><br />
                    <span class="dashboardblksmllxt">Website Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
        
        <li id="list3"><a  href="javascript:void(0);" onclick="submitAdminLoginForm();" id="adminControlPanelLink" style="  " >
        	<div class="icnblkdivmnovr" style="display:none;" id="lms">
             CloudLGS account settings like custom domain, payments and account renewals.
             </div>
        	<div class="icnblkdivmn">
            	<div class="icnblktopdiv"><img src="images/dashboard-flat/control-panel-flat.png" alt="Control Panel" width="110" height="96" border="0" /></div>
                <div class="icnblkbtmdiv">
                	<div class="dashboardblkcntdiv">
                    <img src="images/arrow-btm-flat.png" height="12" width="26" border="0" alt="Arrow Bottom" /><br />
                    <span class="dashboardblkhdngtxt">Control Panel</span><br />
                    <span class="dashboardblksmllxt">Account Settings</span>
                    </div>
                </div>
            </div></a>
        </li>
    </ul>
</div>
</div>
    
    
    </div>
    
    
    <div class="dashboardnew-row-3">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td height="40" align="right" valign="middle">
	      <div id="load_icon" align="center" style="display:none;"><img src="../images/loading.gif" alt="Loading...." /></div>
	      <a href="javascript:void(0);" class="buttonNewdash iconNewdash" id="see_more" onClick="openDashBoardMore();">See More Features</a>
      </td>
    </tr>
</table>
<input type="hidden" name="email" id="adminUserEmail" value="" />
<input type="hidden" name="user_pwd" id="adminUserPwd" value="" />
<input type="hidden" name="chg_pwd" id="adminUserChgPwd" value="" />
<input type="hidden" name="adminSessionId" id="adminSessionId" value="" />
    </div>
    
    
</div>
</div>
<!--Dashboard option block end-->


<!-- Dashboard More Features pop up -->
<div id="dashboardMorePopup" class="sample_popup-layout" align="center"  style="display:none;">  
<div style="margin:auto; max-width:768px;">
    <!-- Header Starts here -->
    <div class="headerPopDiv">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="94%" height="38" align="left" valign="middle" class="dashboardhdngtxt" style="font-size:22px; font-weight:normal;">
    <table border="0" cellspacing="0" cellpadding="2">
      <tr>
       <td align="left" valign="middle" class="themeColor">Dashboard Options</td>
        <td align="left" valign="middle">
        <a href="cms/logout.php?logout=1" >
        <img src="images/logout-btn-new-flat.png" width="103" height="39" border="0" title="Log Out" alt="Log Out"/>
        </a>
    </td>
      </tr>
    </table>

    </td>
    <td width="6%" height="30" align="right" valign="middle">
    <a id="logInSessionReload" href="javascript:void(0);" onClick="dashboardPopupClose();">
    <img src="images/closep-popup-icon.png" height="32" width="32" class="right" border="0" alt="Close Popup" />
    </a>
    </td>
  </tr>
</table>
    </div>
    <!-- Header Ends here -->
    <!-- popupContentDiv -->
<div class="popContentDivFeatures">
<div class="featuerDivPopupICN" id="dashboard_options">
</div>  
</div>
<!-- popupContent Ends here -->

<!-- Footer Starts here -->
<div class="bottomDivPopUpfooter">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="355" height="40" align="left" valign="middle">

          
			            <a href="#" class="buttonNewdash" onclick="submitchangeurl();">Change URL</a>
            <a href="#" class="buttonNewdash" onClick="CancelAccount();">Cancel My Account</a>
                  </td>
      <td width="258" height="40" align="right" valign="middle">
      <a href="javascript:void(0);" class="buttonNewdash iconNewdashback" onClick="hideDashBoardMore();">Back</a>
      </td>
    </tr>
</table>
</div>
<!-- Footer Ends here -->
</div>
</div>
<!--Dashboard option block end-->
<!-- Social media script -->
<script src="/SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="/SpryAssets/SpryTabbedPanels2.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.screwdefaultbuttonsV2.min.js" ></script>
<script type="text/javascript">
$(function(){
	$('input:radio').screwDefaultButtons({
		image: 'url("images/radio-btn.png")',
		width: 26,
		height: 26
	});
});

function radiobtnactive(id){
	if(id==2){
		$("#hiddenactiveval").val('2');
	}	
	if(id==1){
		$("#hiddenactiveval").val('1');	}
}
</script>
<script type="text/javascript">
$(document).ready(function() {
	$('#list1').mouseenter(function() {
		$('#cms').fadeIn();
	});
	$('#list1').mouseleave(function() {
		$('#cms').fadeOut();
	});
	$('#list2').mouseenter(function() {
		$('#controlpanel').fadeIn();
	});
	$('#list2').mouseleave(function() {
		$('#controlpanel').fadeOut();
	});
	$('#list3').mouseenter(function() {
		$('#lms').fadeIn();
	});
	$('#list3').mouseleave(function() {
		$('#lms').fadeOut();
	});
});
function sendmailfn() 
{
$('body, html').animate({ scrollTop:0 }, 'slow');
$('body').css("margin-top","0px");
 var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );
document.getElementById('logInDiv').style.height=height+'px';
document.getElementById('logInDiv').style.display='block';
document.getElementById('clickstatus').value=1;
}

function closeLog(){
   document.getElementById('logInDiv').style.display='none';
   document.getElementById('loading').innerHTML='';
   document.getElementById('username').value="Username";
   document.getElementById('password').value="Password";
   forgotCancel();
}
function showusertype(){
	document.getElementById('usernametr').style.display='none';
	document.getElementById('forgottext').style.display='block';
	document.getElementById('logintext').style.display='none';  
	document.getElementById('passwordtr').style.display='none';
	document.getElementById('checktr').style.display='none';
	$('#captchatr').hide();
	
	document.getElementById('forgotusernametr').style.display='block';
	document.getElementById('submitbtntr').style.display='none';
	document.getElementById('forgotsubmitbtntr').style.display='block'; 
	document.getElementById('lmsusername').style.borderColor='';
}
function  forgotCancel(){
	document.getElementById('usernametr').style.display='block';
	document.getElementById('forgottext').style.display='none';
	document.getElementById('logintext').style.display='block';  
	document.getElementById('passwordtr').style.display='block';
	document.getElementById('checktr').style.display='block';
	if($('#logincount').val()==1){$('#captchatr').show();}
	document.getElementById('forgotusernametr').style.display='none';
	document.getElementById('submitbtntr').style.display='block';
	document.getElementById('forgotsubmitbtntr').style.display='none';
	document.getElementById('lmsusername').style.borderColor='';
}
					
function LmsUserforgot(){
	var username=$("#lmsusername").val();
	var activetab=$("#hiddenactiveval").val();
	if(activetab==1){
		sendUserMail();
	} else {
		sendAdminMail();
	}
}

function sendUserMail(){
	var username=$("#lmsusername").val();
	if(username!="" &&  username=="Enter Your Registered Email"){
		$("#lmsusername").css('border-color', '#CC0000'); return false;
	} else if(validateEmail(username)===false){
		$("#lmsusername").css('border-color', '#CC0000');
		var text="<span style='color:#CC0000'>Please enter valid email.</span>";
		$('#forgotloading').show();
		$('#forgotloading').html(text);
		setTimeout(function(){$('#forgotloading').hide();},4000);
		return false;
	} else {
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "../lms/forgotpasswordlmsuser.php",
			data: {username:username,source:'site'},
			cache: false,
			success: function(val){
				document.getElementById('loading').innerHTML='';
				if(val==1) {
					var text="<span style='color:green'>Details has been sent to mail successfully</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
						setTimeout(function(){$('#forgotloading').hide();},4000);
				} else {
					$("#lmsusername").css('border-color', '#CC0000');
					var text="<span style='color:#CC0000'>No user exists with this email.</span>";
					$('#forgotloading').show();
					$('#forgotloading').html(text);
					setTimeout(function(){$('#forgotloading').hide();},4000);
				}
				document.getElementById('lmsusername').value='Enter Your Registered Email';
			}
		});
	}
}

function sendAdminMail(){
	document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
	var username="admin";
	$.ajax({
	type: "POST",
	url: "../lms/forgotpasswordlmsuser.php",
	data: {username:username,source:'site'},
	cache: false,
	success: function(val){
		document.getElementById('loading').innerHTML='';
		if(val==1) {
			var text="<span style='color:green'>Details has been sent to mail successfully</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
			setTimeout(function(){$('#forgotloading').hide();},4000);
		} else {
			var text="<span style='color:#CC0000'>No user exists with this email.</span>";
			$('#forgotloading').show();
			$('#forgotloading').html(text);
		}
		document.getElementById('lmsusername').value='Enter Your Registered Email';
	}
	});	
}

function validateEmail(elementValue){        
    var emailPattern = /^[a-zA-Z0-9._]+[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,4}$/;  
    return emailPattern.test(elementValue);   
  }
  
function logIn(){
	var username= $('#username').val();
	var password = $('#password').val();
	var clickstatus=$('#clickstatus').val();
	var loginremembercheck = $('#loginremembercheck').val();
	var logincount=$('#logincount').val();
	var login_captcha=$('#login_captcha').val();
	var validLogForm=true;
	if(logincount==1){
		$('#captchatr').show();
		if(login_captcha==''||login_captcha=='Security Code'){
			$('#login_captcha').css('border-color','red');
			validLogForm=false;
		}else{
			$('#login_captcha').css('border-color','');
		}
	}else{
		$('#captchatr').hide();
		$('#login_captcha').css('border-color','');
	}
	if(username==''||username=='Username'){
		$('#username').css('border-color','red');
		validLogForm=false;
	}else{
		$('#username').css('border-color','');
	}
	if(password==''||password=='Password'){
		$('#password').css('border-color','red');
		validLogForm=false;
	}else{
		$('#password').css('border-color','');
	}
	if(clickstatus==1&&validLogForm==true){
		document.getElementById('loading').innerHTML='<img src="images/loading.gif" alt="Loading...."/>';
		$.ajax({
			type: "POST",
			url: "login.php",
			data:{username:username,password:password,loginremembercheck:loginremembercheck,login_captcha:login_captcha},
			dataType: "json",
			cache: false,
			success: function(data){
				if(data.message==1){
					document.getElementById('logInDiv').style.display='none';
					document.getElementById('loading').innerHTML='';
					$('#controlPanel').attr('onclick','openDashboard();');
					$('#logInSessionReload').attr('onclick','dashboardPopupClose2();');
					if(data.admin=='Yes'){
						$('#adminUserEmail').val(data.adminUserEmail);
						$('#adminUserPwd').val(data.adminUserPwd);
						$('#adminUserChgPwd').val(data.adminUserChgPwd);
						$('#adminControlPanelLink').css('display','block');
						$('#adminSessionId').val(data.adminSessionId);
					} else {
						$('#adminControlPanelLink').css('display','none');
						$('#adminControlPanelLinkText').css('display','none');
					}
					if(data.editsite=='2'){
						$('#displayCmsLink').css('display','block');
					} else {
						$('#displayCmsLink').css('display','none');
						$('#displayCmsLinkText').css('display','none');
					}
					openDashboard();
				} else if(data.message==2){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Invalid username and password </div>";
					document.getElementById('loading').innerHTML=error;
					if(data.lgsattempt>5){$('#captchatr').show();$('#logincount').val(1);}
				} else if(data.message==3){
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User has no permissions to Edit</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==4) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>This User account is suspended.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==5) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Not authorized from this system.</div>";
					document.getElementById('loading').innerHTML=error;
				} else if(data.message==6) {
					var error= "<div style='color:#FF0000;font-family:Verdana, Arial, Helvetica, sans-serif;font-weight:normal;font-size:12px;paddding-top:10px;'>Please enter security code.</div>";
					document.getElementById('loading').innerHTML=error;
				}
			}
		});
	}
}

function runPasswordScript(e){
	if (e.keyCode == 13) {
        LmsUserforgot();
        return false;
    }
	return true;
}
function runScript(e) {
    if (e.keyCode == 13) {
        logIn();
        return false;
    }
	return true;
}

function openDashboard(){
$('body, html').animate({ scrollTop: 0 }, 'slow');
$('body').css("margin-top","0px");
var body = document.body,
html = document.documentElement;
var height = Math.max( body.scrollHeight, body.offsetHeight,
html.clientHeight, html.scrollHeight, html.offsetHeight );

document.getElementById('dashboardPopup').style.height=height-75+'px';
$('#dashboardPopup').show();
$("#cartToolTip").hide();
}
function dashboardPopupClose()
{
	$('#load_icon').hide();
	$('#see_more').show();
	$('#dashboardPopup').hide();
	$('#dashboardMorePopup').hide();	
}
function dashboardPopupClose2()
{
	$('#dashboardPopup').hide();
}
function openDashBoardMore() {
	$('#load_icon').show();
	$('#see_more').hide();

	var dataString = {id:1};
	$.ajax({
		type: "POST",
		url: "includes/dashboard-options.php",
		cache: false,
		data: dataString,
		success: function(val)
		{
			$('#dashboard_options').html(val);
			$('body, html').animate({ scrollTop: 0 }, 'slow');
			$('body').css("margin-top","0px");
			var body = document.body,
			html = document.documentElement;
			var height = Math.max( body.scrollHeight, body.offsetHeight,
			html.clientHeight, html.scrollHeight, html.offsetHeight );
			document.getElementById('dashboardMorePopup').style.height=height-75+'px';
			$('#dashboardPopup').hide();
			$('#dashboardMorePopup').show();
		}
	});
	
}
function hideDashBoardMore() {
	$('#load_icon').hide();
	$('#see_more').show();
	$('body').css("margin-top","0px");
	$('body, html').animate({ scrollTop: 0 }, 'slow');
	var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('dashboardPopup').style.height=height-75+'px';
	$('#dashboardPopup').show();
	$('#dashboardMorePopup').hide();
}
function submitAdminLoginForm(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function submitchangeurl(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site2.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function trailpayment(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/signin-site3.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function CancelAccount(){
	var adminUserEmail=$("#adminUserEmail").val();
	var adminUserPwd=$("#adminUserPwd").val();
	var adminUserChgPwd=$("#adminUserChgPwd").val();
	var adminSessionId=$("#adminSessionId").val();
	var adminLoginLink="https://"+"www.cloudlgs.com/en/sign-in-canceltest.php?email="+adminUserEmail+"&user_pwd="+adminUserPwd+"&chg_pwd="+adminUserChgPwd+"&userid_session="+adminSessionId;
	window.open(adminLoginLink,'_blank');
}
function new_logincaptcha(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('logincaptcha').src = '/captcha/image-login.php?x='+ c_miliseconds;
}
</script>
<!-- End Social media script -->
<style>
.loginpopinndiv{width:326px; margin:auto;}
.radioBtnLogin{font-family: "Lucida Sans Unicode","Lucida Grande",sans-serif; font-size:16px; color:#333333;}
.inncntBlkLoginDiv{background:#ffffff; padding:10px; }
.textBoxloginNew{border: 1px solid #D7D7D7; padding: 8px 5px; color: #666; font-size: 14px;}
.inncntBlkLoginDiv span{color:#666666; font-size:12px; font-family:Helvetica, Arial, sans-serif; padding:10px 5px; display:block;
background:#f5f5f5; margin:5px 0px 0px 0px;}

#AllRReserved a{
	text-decoration:underline;
}

.loginPopUpBlock {
	max-width:350px;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
	overflow:hidden;
	margin:auto;
	margin-top:60px;
	background-color:#FFF;
	-webkit-box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	-moz-box-shadow:    0px 0px 15px 0px rgba(0, 0, 0, 0.75);
	box-shadow:         0px 0px 15px 0px rgba(0, 0, 0, 0.75);
}
.loginTitleBlock { background:#f7f7f7; padding:10px 25px; font-size:18px; font-weight:normal !important; overflow:hidden; }
.loginBodyBlock { padding:10px 16px; }
.loginBoxHeadingTxt {font-size:20px; color:#555555; }

input[type=checkbox].css-checkboxrememberpass { display:none; }
input[type=checkbox].css-checkboxrememberpass + label.css-labelrememberpass {
padding-left:40px; height:31px; display:inline-block; line-height:31px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }
input[type=checkbox].css-checkboxrememberpass:checked + label.css-labelrememberpass { background-position: 0% -31px; }
.css-labelrememberpass { background-image:url(../images/websetting-checkbox-flat.png);}

input[type=checkbox].css-checkboxshowpass { display:none; }

input[type=checkbox].css-checkboxshowpass + label.css-labelshowpass { padding-left:30px; height:25px; display:inline-block; line-height:25px; background-repeat:no-repeat; vertical-align:middle; cursor:pointer; }

input[type=checkbox].css-checkboxshowpass:checked + label.css-labelshowpass {
background-position: 0% -25px;
}
.css-labelshowpass { background-image:url(../images/checkbox-shwpwd.png);}

.passwordDiv{background:#617284; height:33px; border:1px solid #4a5f72; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.securityDiv{ height:33px; width:86px; float:left; font-size:14px; color:#ffffff; font-weight:normal !important;}
.member-top-inner {position: fixed; text-align: center; z-index: 99999999; width: 45px; height: 42px; line-height: 35px; right: 30px; bottom: 90px; padding-top: 2px; border-radius: 50%; transition: all 0.5s ease-in-out; background: url(../images/members-area-sticky-icon.png) #258fea no-repeat center !important; cursor:pointer;}

/* The hint to Hide and Show */

.hint { position: absolute; width: 133px; margin-top: 3px; margin-left:-162px;
border: 1px solid #edd5a6; padding: 0px 8px; color:#333; z-index:2; display:none;
background: #ffffda no-repeat -10px 5px; font-weight:normal; font-size: 12px;
font-family: Arial, Helvetica, sans-serif; border-radius:4px; }

/* The pointer image is hadded by using another span */
.hint-pointer { position: absolute; left: 149px; top: 9px; width: 8px;
height: 19px; background: url(cms/images/right-pointer.gif) right top no-repeat; }
.loginBoxBtnNew{font-family: 'Open Sans', sans-serif; font-size:14px !important; background-image:none !important;}

.newdashboardPopUp{margin:auto; max-width:650px; background:#ffffff; overflow:hidden; border-radius:10px;}
.dashboardnew-row-1{background:#ececec; overflow:hidden; padding:5px; font-size:20px; font-weight:normal;}
.dashboardnew-row-2{padding:15px; overflow:hidden; clear:both;}
.dashboardnew-row-3{background:#ececec; overflow:hidden; padding:15px; clear:both;}

@media only screen and (max-width : 760px),
only screen and (max-device-width : 760px){
.member-top-inner {right: 12px;bottom: 205px;  }
}

</style>

<link href='https://fonts.googleapis.com/css?family=Open+Sans|Pontano+Sans' rel='stylesheet' type='text/css'>


<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>

<script type="text/javascript">
var callFooterEfffects=function footerEffects()
{
if($(window).width() > 320){
    $("input:text").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:password").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("textarea").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:button").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );	
	$("input:submit").focus(function() { $('#footerMenu').css('position','relative'); $('.stickyFooterPad').css('display', 'none'); } );
	$("input:text").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("input:password").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
	$("textarea").blur(function() { $('#footerMenu').css('position','fixed'); $('.stickyFooterPad').css('display', 'block'); } );
}
};
$(document).ready(callFooterEfffects);
$(window).resize(callFooterEfffects);

$(function(){
	$(document).on( 'scroll', function(){
		if ($(window).scrollTop() > 100) {
			$('.scroll-top-wrapper').addClass('show');
		} else {
			$('.scroll-top-wrapper').removeClass('show');
		}
	});
	$('.scroll-top-wrapper').on('click', scrollToTop);
});
	
function scrollToTop() {
	verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
	element = $('body');
	offset = element.offset();
	offsetTop = offset.top;
	if((/Android|iPhone|iPad|iPod|BlackBerry|Windows Phone/i).test(navigator.userAgent || navigator.vendor || window.opera)==true){
		$('html, body').css('overflow-y', 'hidden');
		$('html, body').scrollTop(0);
		$('html, body').css('overflow-y', '');
		//$('html, body').animate({scrollTop: 0}, 500, 'linear');
	}else{
		$('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
	}
}
	
	$("#leftImage").hover(	
	function() {
	$("#leftImagetitle").show();
	}, function() {
	$("#leftImagetitle").hide();
	}
	);
	
	$("#rightImage").hover(	
	function() {
	$("#rightImagetitle").show();
	}, function() {
	$("#rightImagetitle").hide();
	}
	);
	
$( ".member-top-inner" ).click(function() {
 		window.location.href ="members-home.php";
 		//window.location.href ="members-home_id47_v1.php";

});
function fieldhint(id){
	document.getElementById(id+"_hint").style.display = "block";
}
function fieldhint1(id){
	document.getElementById(id+"_hint").style.display = "none";
}	
</script>
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-176053839-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-176053839-1');
</script>

<script type="text/javascript">
$(document).ready(function(){
$('input[name="passwordChk"]').click(function(){
if($(this).is(':checked')== true)
{document.getElementById("password").setAttribute('type', 'text');} 
if($(this).is(':checked')== false)
{document.getElementById("password").setAttribute('type', 'password');}
});
});
</script>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>




<script type="text/javascript" src="//cdn.calltrk.com/companies/566306024/0dc36fd4a782002e285c/12/swap.js"></script> 
<!-- Global site tag (gtag.js) - Google Ads: 600261187 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-600261187"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'AW-600261187');
</script>
<!-- CANDDi https://www.canddi.com/privacy -->
<script async type="text/javascript" src="//cdns.canddi.com/p/44b13b5eeaf66ba606408a64c4ea8e14.js"></script>
<noscript style="display:none;visibility:hidden;"><img src='https://i.canddi.com/i.gif?A=44b13b5eeaf66ba606408a64c4ea8e14'/></noscript>
<!-- /END CANDDi -->
<!-- Clickcease.com tracking-->
<script type='text/javascript'>var script = document.createElement('script');
script.async = true; script.type = 'text/javascript';
var target = 'https://www.clickcease.com/monitor/stat.js';
script.src = target;var elem = document.head;elem.appendChild(script);
</script>
<noscript>
<a href='https://www.clickcease.com' rel='nofollow'><img src='https://monitor.clickcease.com/stats/stats.aspx' alt='ClickCease'/></a>
</noscript>
<!-- Clickcease.com tracking-->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '535512043295157'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=535512043295157&ev=PageView&noscript=1" alt="Facebook Pixel" /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
<script src="../js/jquery.exitintent.js"></script>
<script>
$(function() {
	var user=getCookie("exitintent_popup");
	if (user == "") {
		$.exitIntent('enable');
		$(document).bind('exitintent', function() {
			$("#ballonseffects").show();
		});
	}
	$(document).bind('exitintent', function() {
		var countbutton='';
		if(countbutton=="40506" || countbutton=="405" || countbutton=="506" || countbutton=="406"){
			setTimeout(function() {$("#ballonseffects").remove();}, 13500);
			setCookie("exitintent_popup","test", 1);
			return false;
		  }else{
			setTimeout(function() {$("#ballonseffects").remove();}, 9000);
			setCookie("exitintent_popup","test", 1);
			return false;
		}  
	});
});

function setCookie(cname,cvalue,exdays) {
	var d = new Date();
	d.setTime(d.getTime() + (exdays*60*5000));
	var expires = "expires=" + d.toGMTString();
	document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}



</script>
        </div>
    </div>
<script type="text/javascript">
function validatelay5form(){
	var fnameVal = 2;  var email1Val =2; var phone1Val =2; var phone2Val = 2; var phone3Val = 2; var phone4Val = 2;
	var commentVal = 2; var securityval = 2;
		var fname=$('#lay5formName').val();
	var fnameValid=fname.replace(/ /g,'');
	if(fnameValid==""){
		var fnameVal = 1;
	}
							
	var email=$('#lay5formEmail').val();
	var email1Valid=email.replace(/^\s+|\s+$/g, '');
	if(email1Valid==""){
		var email1Val = 1;
	}
	var emailRegEx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	email = $('#lay5formEmail').val().replace(/^\s+|\s+$/g, '');
	if(!email.match(emailRegEx)){
		var email1Val = 1;
	}
		
	var phone1=$('#lay5formPhone1').val(); 
	var phone1Valid=phone1.replace(/ /g,'');	
	if(phone1Valid==""){
		var phone1Val = 1;
	}		
	var phoneRegEx1 = /^\(?([0-9]{3})\)?/;
	phone1 = $('#lay5formPhone1').val();
	if(phone1.length<3 || !phone1.match(phoneRegEx1)){
		var phone1Val = 1;
	}
	var phone2=$('#lay5formPhone2').val(); 
	var phone2Valid=phone2.replace(/ /g,'');		
	if(phone2Valid==""){
		var phone2Val = 1;
	}
	var phoneRegEx2 = /^\(?([0-9]{3})\)?/;
	phone2 = $('#lay5formPhone2').val();
	if(phone2.length<3 || !phone2.match(phoneRegEx2)){
		var phone2Val = 1;
	}
	var phone3=$('#lay5formPhone3').val();
	var phone3Valid=phone3.replace(/ /g,'');		
	if(phone3Valid==""){
		var phone3Val = 1;
	}		
	var phoneRegEx3 = /^\(?([0-9]{4})\)?/;
	phone3 = $('#lay5formPhone3').val();
	if(phone3.length<4 || !phone3.match(phoneRegEx3)){
		var phone3Val = 1;
	}
	var phonelength=phone1.length+phone2.length+phone3.length;
	if(phonelength<10)
		phone4Val = 1;
			
	var service=$('#lay5formMsg').val();
	var serviceValid=service.replace(/ /g,'');
	if(serviceValid==""){
		var commentVal = 1;
	}	
	
	if(fnameVal==1 || email1Val==1 || phone1Val==1 || phone2Val==1 || phone3Val==1 || phone4Val==1 || commentVal==1){
 		if(fnameVal==1){
			$('#lay5formName').css("border","1px solid red");
 		}else{
			$('#lay5formName').css("border","");
		}
		if(email1Val==1){
			$('#lay5formEmail').css("border","1px solid red");			
		}else{
		    $('#lay5formEmail').css("border","");		
		}
		if(phone1Val==1){
			$('#lay5formPhone1').css("border","1px solid red");	
		}else{
			$('#lay5formPhone1').css("border","");
		}
		if(phone2Val==1){
			$('#lay5formPhone2').css("border","1px solid red");	
		}else{
		     $('#lay5formPhone2').css("border","");
		}
		if(phone3Val==1){
			$('#lay5formPhone3').css("border","1px solid red");	
		}else{
		    $('#lay5formPhone3').css("border","");
		}
		if(phone4Val==1){
			$('#lay5formPhone1').css("border","1px solid red");
			$('#lay5formPhone2').css("border","1px solid red");
			$('#lay5formPhone3').css("border","1px solid red");	
		}
		if(commentVal==1){
		    $('#lay5formMsg').css("border","1px solid red");
		}else{
		   $('#lay5formMsg').css("border","1px solid  #d7d7d7");
		}
		return false;
	}
	$("#lay5verifyHuman").val("shift$%123");
	showPleasewait();
	lay5formsave();
}
function lay5formsave(){
	var fname=document.getElementById("lay5formName").value;
	var phone1=document.getElementById("lay5formPhone1").value
	var phone2=document.getElementById("lay5formPhone2").value;
	var phone3=document.getElementById("lay5formPhone3").value;
	var email=document.getElementById("lay5formEmail").value;
	email= email.trim();
	var comments=document.getElementById("lay5formMsg").value;
	var verifyHuman=document.getElementById("lay5verifyHuman").value;
	var spamRestrict1=document.getElementById("lay5spamRestrict1").value;
	var spamRestrict2=document.getElementById("lay5spamRestrict2").value;
	var spamRestrict3=document.getElementById("lay5spamRestrict3").value;
	$.ajax({
		type: "POST",
		url: "lay5-form-submit.php",
		data: {fname:fname,phone1:phone1,phone2:phone2,phone3:phone3,email:email,comments:comments,verifyHuman:verifyHuman,spamRestrict1:spamRestrict1,spamRestrict2:spamRestrict2,spamRestrict3:spamRestrict3},
		cache: false,
		success: function(html){	
			if(html==1){
				hidePleasewait();
				//$("#lay5formthankyou").show();
				$("#lay5formName").val('');
				$("#lay5formEmail").val('');
				$("#lay5formPhone1").val('');
				$("#lay5formPhone2").val('');
				$("#lay5formPhone3").val('');
				$("#lay5formMsg").val('');
				//setTimeout(function(){ $("#lay5formthankyou").hide(); 
											window.location.href='estimatethankyou.php';
									//}, 5000);
			}else{
				hidePleasewait();
				//$("#popupthankyou").show();
				//$("#popupthankyou").html('Please enter valid security code').css('color','red');
			}
		}
	});
}
function lay5isNumberKey(fld){	
	if(fld == 1){
		var phone1=$("#lay5formPhone1").val();
		if(phone1.length==3){
			$("#lay5formPhone2").focus();
			return true; }	
	}
	if(fld == 2){
		var phone2=$("#lay5formPhone2").val();
		if(phone2.length==3){
			$("#lay5formPhone3").focus();
			return true; }	
	}
	return true;
}
</script> 
<!-- Animation Effetct -->
<script src="visualize.js" type="text/javascript" ></script>
<!-- Animation Effetct Ends here -->
    <!--Home Page Layouts End-->
<!--home popup starts here-->
<style type="text/css">
.popupBoxDiv {background:#f1f1f1;border-radius:4px;padding:2%;max-width:550px;margin:0px auto;text-align:center;position:relative;}
a.popupClsBtn {background: #ff0000; border: 1px solid #f00; color: #fff;border-radius:50%;position:absolute;top:-3%;right:-3%;text-decoration:none;font-size:32px;line-height:32px;width:38px;height:38px;}
.sampleText {font-family:"Open Sans",sans-serif;font-size:35px;font-weight:300;padding:0px 0px 20px 0px;margin:auto;clear:both;overflow:hidden;}
.sampleTexttag {font-family:"Open Sans",sans-serif;font-size:35px;font-weight:300;padding:0px 0px 20px 0px;margin:auto;clear:both;overflow:hidden;}
.popupFormBlock {overflow:hidden;padding:0px 20px;}
.leftBlckImgVideo {float:left;max-width:360px;width:100%;text-align:center;}
.leftBlckImgVideo img{max-width:360px; max-height:360px; width:100%; height:100%;}
.rightBlckForm {float:right;overflow:hidden;max-width:420px;width:100%;text-align:left;}
.txtFldDiv {position:relative;}
.txtFldPopupNew{background:#fff; border:1px solid #d7d7d7; padding:8px 8px !important; color:#333 !important; max-width:420px; width:100%; font-family:"Open Sans",sans-serif; font-size: 18px !important; margin-bottom:5px; box-sizing:border-box;}
.layoutBtn {font-family:"Open Sans",sans-serif;font-size:24px;margin:5px auto;color:#FFFFFF;display:inline-block;text-decoration:none;width:100%;padding:16px 3%;border:none;cursor:pointer;}
.spinner { position: fixed; top: 50%; left: 50%; margin-left: -50px; margin-top: -50px;
text-align:center; z-index:99999; overflow: hidden; }
.captchaCodeImg {
   float: left;
   margin: 2% 4px 2% 5px;
   height: auto;
}
.btmMar {margin-bottom:8px;}
.followus-SocialMedia{padding:15px 10px; text-align:center; overflow:hidden; background:#ffffff; border-radius:6px; width:auto; margin:auto;
display:inline-block;}
.twitterToolTip{text-align: center; margin:0px auto 8px auto; overflow: visible; width: 48px; height: 30px; position: relative; background: #fff;
border: 1px solid #ccc; -moz-border-radius: 2px; border-radius: 2px; }
.twitterToolTip::after, .twitterToolTip::before {top: 100%; left: 50%; border: solid transparent; content: " "; height: 0; width: 0; position: absolute; pointer-events: none;}
.twitterToolTip::after {  border-color: rgba(255,255,255,0); border-top-color: #fff; border-width: 4px; margin-left: -4px;}
.twitterToolTip::before {border-color: rgba(192,192,192,0);border-top-color: #ccc;border-width: 5px; margin-left: -5px;}
.socicnDivHe{width: 48px; height: 30px; display: table-cell; vertical-align: middle;}
/*.social-col-xs5{width: ;text-align:center; float:left;}*/

.social-col-xs5{width:75px; text-align:center; float:left;}

@media only screen and (max-width:900px),
only screen and (max-device-width:900px){
.leftBlckImgVideo{float:none;margin:auto;}
.rightBlckForm{float:none;margin:20px auto 0px;}
.popupBoxDiv{margin:9% 5%;}
a.popupClsBtn {top:-1%;right:-2%;}
.layoutBtn {width: 100% !important}
}
@media only screen and (max-width:768px),
only screen and (max-device-width:768px){
	.sampleText{font-size:32px;line-height:40px; padding:10px;}
	.sampleTexttag{font-size:20px;line-height:20px; padding:10px;}
	.popupFormBlock {overflow:hidden;padding:0px;}
		.popupBoxDiv{margin:9% 3%;}
	}
@media only screen and (max-width:639px),
only screen and (max-device-width:639px){
	.captchaCodeImg {
	   float: left;
	   margin: 3% 4px 3% 5px;
	   height: auto;
	}
}
@media only screen and (max-width:479px),
only screen and (max-device-width:479px){
	.popupBoxDiv{margin:9% 3%;}	
	.followus-SocialMedia{padding:10px 5px;}
}
@media only screen and (max-width:359px),
only screen and (max-device-width:359px){
	.captchaCodeImg {
	   float: left;
	   margin: 4% 4px 4% 5px;
	   height: auto;
	}
.social-col-xs5{padding-bottom: 10px;}
.followus-SocialMedia{padding: 15px 25px;}
}
</style>
<!--home popup ends here-->
<div class="sample_popup-layout" id="sendEmailPopup" style="display:none; position: fixed; bottom: 0px; padding-top: 10%; height:100%; position:absolute;">
<div class="popupBoxDiv sendEmailWidth520">
	<div class="padd20Email">
	<a href="javascript:void(0)" class="popupClsBtn" onclick="closeSendEmail()">x</a>
	<div class="sampleText themeColor">
		<span>Send Email</span>
	</div>
	<div style="padding: 0px; font-size:18px;">
    <input type="text" class="txtFldPopupNew" placeholder="To*" id="emailTo" name="emailTo" style="max-width:100%;" onfocus="this.style.border=''">
	<div style="font-size:14px; text-align:left; padding:0px 0px 15px 0px;">Please use a "Comma" to separate multiple email address<br>Example: sample@example.com,sample1@example.com</div>
    <input type="text" class="txtFldPopupNew btmMar" placeholder="Subject*" id="emailSubject" name="emailSubject" style="max-width:100%;" onfocus="this.style.border=''" maxlength="200">
	<textarea class="txtFldPopupNew btmMar" placeholder="Message" id="emailMessage" name="emailMessage" style="resize:none;max-width:100%;" onfocus="this.style.border=''" maxlength="1000"></textarea>
    <div style="margin:0px 0px 0px 0px; overflow:hidden;">
    	<div style="border:1px solid #CCC; background:#FFF;">
			<div style="text-align:center; background:#f5f5f5"><img src="https://www.seobusinessboost.com/change_image_size.php?file=members/seobusinessboost/avatar/thumbs/thumbnail_1352370005.png" style="max-width:100%;max-height:360px;" border="0" alt="Logo" /></div>
			<div style="padding:10px;text-align: left;line-height: 24px; background:#f8f8f8;">
				<div style="font-size:16px; color:#1c81d4;">Best Online SEO Company | SEO Business Boost</div>
				<div style="color:#aaaaaa;font-size: 16px;">https://www.seobusinessboost.com</div>
				<div style="color:#666666;font-size: 16px;">As the best online SEO company, we will give you a plan before diving into SEO work. Our team will also make it easier for your potential customers to avail your services or products. In no time, they will enter the sales funnel, then cha-ching! More sales for your business!.</div>
			</div>
		</div>
    </div>
    </div>
	<div style="font-size: 20px; padding: 0px 0px 20px; text-align: center; display:none; color:green;" id="emailThanku">Mali Sent Successfully</div>
	<div style="text-align:center;padding-top:10px;"><input type="button" onclick="sendEmailValidate()" value="Send Email" id="" style="width: auto; font-size: 35px; font-weight: 300;" class="layoutBtn bgcolorTheme"></div>
    </div>
</div>
</div>
<div class="scroll-top-wrapper">
    <span class="scroll-top-inner">
        <i class="fa fa-2x fa-arrow-circle-up"></i>
    </span>
</div>
<!-- Live Chat Styles Starts Here -->
<style>
.chatCircle{width:58px; height:58px; border-radius:50%; position:fixed; cursor:pointer;z-index:99;top:75%}
.chatCircleIcon{width:58px; height:58px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.chatCircleMob{width:58px; height:58px; border-radius:50%; position:fixed; left:10px; bottom:90px; display:none; z-index:99;}

.chatCircle-v2{width:53px; height:53px; border-radius:50%;  position:fixed; bottom:88px; right:30px; z-index:99;cursor:pointer;}
.chatCircleIcon-v2{width:53px; height:53px; display:table-cell; text-align:center; vertical-align:middle;cursor:pointer;}
.arrow-downIcn {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #1c80d5;
margin: -5px 0px 0px 26px;cursor:pointer;}
.closeIcnChat{float:right; cursor:pointer; padding:7px; border-radius:50%;}

.liveChatMain { max-width: 390px; width: 100%; position: fixed; background: #ffffff; font-family: 'Open Sans', sans-serif; color: #000000;
font-size: 20px; font-weight: normal; -webkit-border-radius: 4px; -moz-border-radius: 4px;}
.livechatMainRight{right: 53px;bottom: 158px;}
.livechatMainLeft{left: 89px; bottom: 40px;}

.liveChatInn{padding:18px;position:relative;}
.liveChatbox{background:#ececec; font-family:'Open Sans', sans-serif; color:#333; font-size:18px; font-weight:normal; border-radius:4px; 
-webkit-border-radius:4px; -moz-border-radius:4px; text-align:left; border:0; resize:none; padding: 10px; width: 100%; margin:10px auto; 
border: 1px solid #ECECEC; box-sizing: border-box;}
.nextBtn{font-family:'Open Sans', sans-serif; color:#fff; font-size:16px; font-weight:normal; text-align:left; border:0; 
padding: 6px 22px; width: 100%; cursor:pointer;}
.arrow-down {width: 0; height: 0; border-left: 13px solid transparent; border-right: 1px solid transparent; border-top: 12px solid #ffffff; position:absolute;right:15px;}
.successTxt{font-family:'Open Sans', sans-serif; color:#1E99EE; font-size:24px; font-weight:normal;background:#fff;
text-align:center;clear: both;border-radius: 4px;-webkit-border-radius: 4px;-moz-border-radius: 4px;padding:15px 0px;
margin: 10% auto 10% auto;width: 320px;}
.arrow-left {width: 0; height: 0; border-left: 10px solid transparent; border-right: 11px solid transparent;
border-top: 54px solid #ffffff; -moz-transform: rotate(45deg); -webkit-transform: rotate(45deg); -o-transform: rotate(45deg);
-ms-transform: rotate(45deg); margin: 21px 0px 0px 0px; right: 389px !important; z-index: 9 !important; position:absolute !important;}
.leftShadow{-webkit-box-shadow: -5px -1px 44px 0px rgba(129, 129, 129, 0.5);}

@media only screen and (max-width:767px),
only screen and (max-device-width:767px){
.chatCircle-v2{bottom:130px;right:12px;}

.livechatMainRight, .livechatMainLeft{right: 0px; bottom: 150px; left:0px;}
.liveChatMain { width:98%; margin:auto;}
.arrow-down, .arrow-left{ display:none;}
.successTxt{padding:15px 0px; width:100%;}
}
@media only screen and (max-width:760px),
only screen and (max-device-width:760px){
	.nextBtn{padding:10px 22px !important;}
}
</style>
<!-- Ends here -->
<!-- Social Media Icons -->
 <div style="top:80%; ">
 <div class="chatCircle bgcolorTheme" id="desktop_left" onClick="livechatpopup(1);" style="display:none;cursor:pointer">	
		<div class="chatCircleIcon" ><img src="images/chat-icn-v1.svg"  height="32" width="32" border="0" alt="Live Chat" /></div>
 </div>
</div>
<!-- Ends here -->
<!-- Live Chat Icon Mobile Option v1 -->
<div class="chatCircleMob bgcolorTheme" id="mobile_left"  onClick="livechatpopup(1);" style="display:none;">	
	<div class="chatCircleIcon"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
</div>
<!-- Ends here -->

<!-- Live Chat Icon Option 2 -->
<div class="chatCircle-v2 bgcolorTheme" id="desk_mob_right"  onClick="livechatpopup(1);" style="display:none;cursor:pointer">
	<div class="chatCircleIcon-v2"><img src="images/chat-icn-v1.svg" height="32" width="32" border="0" alt="Live Chat" /></div>
    
</div>
<!-- Ends here -->

<!-- Live Chat Pop Up Starts Here -->
<div class="liveChatMain livechatMainRight" id="livemsg" style="z-index:9999999;display:none;"  role="" >
		<div class="arrow-left" style="display:none;" ></div>
		<div class="liveChatInn" id="livechatdiv" style="display:;  box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -moz-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); -webkit-box-shadow:2px 6px 20px 0px rgba(129, 129, 129, 0.5); display: block;">
			<div class="liveChathead" id="messageme">
				<span>Chat with us now</span>
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(2)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
                </span>
				<textarea name="chatmessage" id="chatmessage" class="liveChatbox" placeholder="Send us a message for a fast response" rows="3" onfocus="this.style.border='';" maxlength="1000" ></textarea>	
				<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" onclick="return livechat_next(1);"  name="next" id="next" value="Next" /></div>
				</div>
			</div>
			<div class="liveChathead" id="liveemail" style="display:none;">
			<span style="display:">Additional details</span> 
			<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(3)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" onClick="livechatpopupclose();" alt="Live Chat Close" /></a>
            </span>
				<input type="text" name="chatemail" id="chatemail" class="liveChatbox" placeholder="Your email address" onfocus="this.style.border='';" style="margin-bottom:5%;" maxlength="80"/>
				<div style="overflow: hidden;margin-bottom: 8%;">
					<div style="float:right;">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td align="left" valign="middle"><img border="0" id="security_code_capcha" src="captcha/image-livechat.php" alt="captcha" /></td>
							<td align="left" valign="middle"><a href="JavaScript: new_captcha_live();" ><img border="0" alt="" width="24" height="24" src="captcha/refresh2.png" align="bottom" style="padding-left:5px;" /></a></td>
						</tr>
					</table>
					</div>
					<div  style="float:left;width:62%">
					<input name="security_code_lc"  maxlength="5" type="text" id="security_code_lc"  value=""  placeholder="Security Code"class="textboxlogin" onFocus="document.getElementById('security_code_lc').style.borderColor=''" style="background: #ececec; font-family: 'Open Sans', sans-serif; color: #333; font-size: 14.5px; font-weight: normal;width:100%" />	
					</div>					
				</div>
				<div style="display: none;color:red;font-size: 14px;text-align: center;" id="live_secure_issue">Invalid Security Code</div>
				
				
				<div style="font-size:12px;float:left;display:;cursor:pointer;"><a href="javascript:livechat_next(2);" style="text-decoration:none;color:#4B4C4E;"><img src="/images/left-arrow-new.png" style="vertical-align:middle;" border="0" height="15" width="18" alt="Live Chat Back"> <span> Edit message</span></a></div>
			<div style="overflow:hidden;">
				<div style="float:right;"><input type="button" class="nextBtn bgcolorTheme" name="savechat" id="savechat" value="Submit" onclick="return submit_livechat();"/>
				<input type="hidden" name="verifyHuman_livechat" id="verifyHuman_livechat" value="shift!&XYZ" />
				<input type="hidden" name="spamRestrict1_livechat" id="spamRestrict1_livechat" value="9a1f0c86dc0f747b0636c9945a30f392" />
				<input type="hidden" name="spamRestrict2_livechat" id="spamRestrict2_livechat" value="293f03a5499c6360b747f0cd68c0f1a9" />
				<input type="hidden" name="spamRestrict3_livechat" id="spamRestrict3_livechat" value="" />
				</div>
			</div>
			</div>
			
	<div style="display:none;" id="livethankyou">
		<div class="liveChatInn" style="background:#ededed;">
			<div class="liveChathead">
				<span class="closeIcnChat bgcolorTheme" onClick="livechatpopupclose();"><a href="javascript:void(0);" onclick="livechatpopup(4)">
                	<img src="images/chat-icn-close.svg" border="0" width="12" height="12" alt="Live Chat Close" /></a>
                </span>
			</div>
			<div class="successTxt"><span>Message sent successfully.</span><br><span style="font-size:18px;color:#000000;">We'll be in touch.</span></div>
		</div>
	</div>
	</div>
<div class="arrow-down" id="arrow" style=""></div>    
</div>
<!-- Ends here -->
<script type="text/javascript">
//////live chat popup ///////////
function livechatpopup(val){
	if(val==1){
	$("#livemsg").toggle();
	}else{
		$("#livemsg").hide();
	}
}
function livechatpopupclose(){
	$("#livemsg").hide();
}

function livechat_next(id){
	if(id==1) {
		var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
		if(chatmessage==""){
			$('#chatmessage').css('border','1px solid #cc0000');
			return false;
		} else {
			$('#messageme').hide();
			$('#liveemail').show();
		}
	}
	if(id==2) {
		$('#messageme').show();
		$('#liveemail').hide();
	}
} 
function submit_livechat(){
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var chatmessage = $('#chatmessage').val().replace(/^\s+|\s+$/g,'');
	var chatemail = $('#chatemail').val().replace(/^\s+|\s+$/g,'');
	var security_code_lc=$('#security_code_lc').val().replace(/ /g,'');
	var source="Chat Box";
	if(chatemail=="" || reg.test(chatemail)==false || security_code_lc==''||security_code_lc=='Security Code'){
		if(chatemail=="" || reg.test(chatemail)==false){$('#chatemail').css('border','1px solid #cc0000')};
		if( security_code_lc==''||security_code_lc=='Security Code'){$('#security_code_lc').css('border','1px solid #cc0000')};
		return false;
	} else {
		$("#verifyHuman_livechat").val("shift$%123");
		
		var verifyHuman=document.getElementById("verifyHuman_livechat").value;
		var spamRestrict1=document.getElementById("spamRestrict1_livechat").value;
		var spamRestrict2=document.getElementById("spamRestrict2_livechat").value;
		var spamRestrict3=document.getElementById("spamRestrict3_livechat").value;
		
		$.ajax({
			type: "POST",
			url: "livechat-submit.php",
			data:{chatmessage:chatmessage,chatemail:chatemail,source:source,verifyHuman:verifyHuman,spamRestrict1:spamRestrict1,spamRestrict2:spamRestrict2,spamRestrict3:spamRestrict3,security_code_lc:security_code_lc},
			cache: false,
			success: function(html) {
				if(html==1){
                    $('#liveemail').hide();
					$('#livethankyou').show();
				}else{
					$('#live_secure_issue').show();
					setTimeout(function(){ $('#live_secure_issue').hide(); }, 3000);
				}
			}
			
		});
	}	
}
function new_captcha_live(){
	var c_currentTime = new Date();
	var c_miliseconds = c_currentTime.getTime();
	document.getElementById('security_code_capcha').src = 'captcha/image-livechat.php?x='+ c_miliseconds;
}
</script>
<script type="text/javascript" src="dist/skrollr.js"></script>
<script type="text/javascript">
window.onload = function() {
	var firstFixedSlide = $( window ).height();
		$('#firstFixedSlide').css('height', firstFixedSlide + 'px');
		//Calling it twice doesn't hurt.
	if((/MSIE 7|MSIE 8|MSIE 9/i).test(navigator.userAgent || navigator.vendor || window.opera)==false){
		skrollr.init({
			smoothScrolling: false,
			duration:1000,
			mobileDeceleration: 0.004
		});
	}
};
$(window).resize(function(){
	var firstFixedSlide = $( window ).height();
		if((/MSIE 7|MSIE 8|MSIE 9/i).test(navigator.userAgent || navigator.vendor || window.opera)==false){
		skrollr.init({
			smoothScrolling: false,
			duration:1000,
			mobileDeceleration: 0.004
		});
	}
}); 
</script>
<script type="text/javascript">
function shareonFacebook(){
	window.open('https://www.facebook.com/sharer/sharer.php?u=https://www.seobusinessboost.com', 'facebookwindow', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
function openTwitterShare(){
	window.open('https://twitter.com/share?url=https://www.seobusinessboost.com', 'twitterwindow', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
/* function openGooglePlusShare(){
	window.open('https://plus.google.com/share?url=https://www.seobusinessboost.com', 'googlepluswindow', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
} */
function openPinterestShare(){
	window.open('https://www.pinterest.com/pin/create/button/?url=https%3A%2F%2Fwww.seobusinessboost.com&media=https%3A%2F%2Fwww.seobusinessboost.com%2Fchange_image_size.php%3Ffile%3Dmembers%2Fseobusinessboost%2Favatar%2Fthumbs%2Fthumbnail_1352370005.png', 'pinterest', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
function shareonothers(url){
	window.open(''+url,'others', 'height=450, width=550, top='+($(window).height()/2 - 225) +', left='+$(window).width()/2 +', toolbar=0, location=0, menubar=0, directories=0, scrollbars=0');
}
function openSendEmail(){
	var body = document.body,
	html = document.documentElement;
	var height = Math.max( body.scrollHeight, body.offsetHeight,
	html.clientHeight, html.scrollHeight, html.offsetHeight );
	document.getElementById('sendEmailPopup').style.height=height+'px';
	$('#sendEmailPopup').show();
	$('body, html').animate({ scrollTop: 0 }, 'slow');
}
function closeSendEmail(){
	$('#sendEmailPopup').hide();
}
function sendEmailValidate(){
	var emailRegEx = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var emailTo = $('#emailTo').val()
	var result = emailTo.split(","); 
	var flag=true;
	for(var i = 0;i < result.length;i++){
		var email = $.trim(result[i]);
		if(!email.match(emailRegEx)){
			flag=false;
		}
	}
	var subject = $.trim($('#emailSubject').val());
	var message = $('#emailMessage').val();
	if(flag==false ||subject==''){
		if(flag==false){
			$('#emailTo').css("border","1px solid red");}
		if(subject==''){
			$('#emailSubject').css("border","1px solid red");}
	}else{
		showPleasewait();
		$.ajax({
			type: "POST",
			url: "send_popup_email.php",
			data: {email:emailTo,subject:subject,message:message},
			cache: false,
			success: function(html){	
				hidePleasewait();
				$('#emailThanku').show();
				setTimeout(function(){
					closeSendEmail();
					$('#emailThanku').hide();
				}, 5000);
				$('#emailTo, #emailSubject, #emailMessage').val('');
			}
		});
	}
}
$(document).ready(function(){
	$("#socialarrow").click( function() {
		var value=$(this).attr("data-value");
		if (value=="1") {
			$(".socialMediaIcon ul li").not($(this)).animate({
				marginLeft: "-60px"
			}, 1000 );
			$(this).attr("data-value","0");
			$(this).find('img').attr('src', '/images/right-arrow.png');
			$(this).find('img').attr('title', 'Show');
		} else {
			$(".socialMediaIcon ul li").not($(this)).animate({
				marginLeft: "0px"
			}, 1000 );
			$(this).attr("data-value","1");
			$(this).find('img').attr('src', '/images/left-arrow.png');
			$(this).find('img').attr('title', 'Hide');
		}
	});
});
</script>
<script type="text/javascript">
function showPleasewait(){
	$('#spinner').show();
	$(function() {
		var docHeight = $(document).height();
		$("body").append("<div id='overlay'></div>");
		$("#overlay")
			.height(docHeight)
			.css({
			 'display' : 'block',
			 'opacity' : 0.5,
			 'position': 'absolute',
			 'top': 0,
			 'left': 0,
			 'background-color': 'black',
			 'width': '100%',
			 'z-index': 5000
			});
	});
}
function hidePleasewait(){
	$('#spinner').hide();
	$('#overlay').hide();
}
function isNumberic(evt){
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	if(key!=9 && key!=8){
		key = String.fromCharCode( key );
		var regex = /[0-9]|\./;
		if( !regex.test(key) ) {
			theEvent.returnValue = false;
			if(theEvent.preventDefault) theEvent.preventDefault();
		}
	}
}
</script>
</body>
</html>